@echo off
setlocal
cd /d "%~dp0"
echo ===============================================
echo LTC Music Studio V0.7.1 - Build APK DEBUG
echo ===============================================
call npx cap sync android
if errorlevel 1 goto :error
cd android
call gradlew.bat assembleDebug
if errorlevel 1 goto :error
cd ..
if not exist "BUILD" mkdir "BUILD"
copy /Y "android\app\build\outputs\apk\debug\app-debug.apk" "BUILD\LTC_Music_Studio_V0.7.1-debug.apk" >nul
echo.
echo APK cree :
echo %cd%\BUILD\LTC_Music_Studio_V0.7.1-debug.apk
pause
exit /b 0
:error
echo.
echo ECHEC DU BUILD. Ouvre Android Studio et fais Sync Project with Gradle Files.
pause
exit /b 1
