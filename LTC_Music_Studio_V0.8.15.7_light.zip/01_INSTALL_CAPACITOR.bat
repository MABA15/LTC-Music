@echo off
setlocal
cd /d "%~dp0"
echo ===============================================
echo LTC Music Studio V0.7.1 - Installation Capacitor
echo ===============================================
echo.
echo Verification de Node.js...
node --version || goto :node_error
npm --version || goto :node_error
echo.
echo Installation des dependances Capacitor 8...
call npm install
if errorlevel 1 goto :error
echo.
echo OK. Passe maintenant a 02_CREATE_OR_SYNC_ANDROID.bat
pause
exit /b 0
:node_error
echo.
echo ERREUR : Node.js 22+ doit etre installe et accessible dans PATH.
pause
exit /b 1
:error
echo.
echo ERREUR pendant npm install.
pause
exit /b 1
