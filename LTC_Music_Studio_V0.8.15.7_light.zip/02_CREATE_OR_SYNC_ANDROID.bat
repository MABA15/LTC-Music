@echo off
setlocal
cd /d "%~dp0"
echo ===============================================
echo LTC Music Studio V0.7.1 - Android Capacitor
echo ===============================================
echo.
if exist "android\settings.gradle" goto :sync
if exist "android\settings.gradle.kts" goto :sync
echo Creation du projet Android...
call npx cap add android
if errorlevel 1 goto :error
:sync
echo Synchronisation de www + plugins vers Android...
call npx cap sync android
if errorlevel 1 goto :error
echo.
echo OK. Le dossier android est pret.
echo Lance 03_OPEN_ANDROID_STUDIO.bat
pause
exit /b 0
:error
echo.
echo ERREUR Capacitor. Verifie npm install et Android SDK.
pause
exit /b 1
