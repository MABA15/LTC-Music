@echo off
setlocal
cd /d "%~dp0"
echo Synchronisation avant ouverture...
call npx cap sync android
if errorlevel 1 goto :error
echo Ouverture dans Android Studio...
call npx cap open android
if errorlevel 1 goto :error
exit /b 0
:error
echo.
echo ERREUR. Tu peux aussi ouvrir manuellement le dossier android dans Android Studio.
pause
exit /b 1
