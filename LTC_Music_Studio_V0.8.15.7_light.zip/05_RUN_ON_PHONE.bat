@echo off
setlocal
cd /d "%~dp0"
echo Branche ton Samsung en USB et active le debogage USB si tu veux lancer directement l'app.
echo Capacitor va te demander de choisir un appareil si plusieurs sont disponibles.
call npx cap run android
pause
