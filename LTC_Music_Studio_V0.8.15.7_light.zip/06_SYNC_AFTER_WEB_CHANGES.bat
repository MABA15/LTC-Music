@echo off
setlocal
cd /d "%~dp0"
echo Copie/synchronise les fichiers www vers le projet Android existant.
call npx cap sync android
if errorlevel 1 goto :error
echo OK. Retourne ensuite dans Android Studio pour relancer/build.
pause
exit /b 0
:error
echo ERREUR pendant cap sync.
pause
exit /b 1
