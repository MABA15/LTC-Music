LTC MUSIC STUDIO V0.6.6 — CAPACITOR + ANDROID

OBJECTIF
Cloturer l’arrangeur avec un raccord de boucle fin -> debut, tout en conservant le workflow Android de V0.6.5.

NOUVEAUTES
- section BOUCLE FINALE dans ARRANGEMENT ;
- analyse du raccord et score 0-100 ;
- AUTO / LIER / NOTE-PONT / FONDU / AUCUNE ;
- crossfade de pre-ecoute 0 / 0,5 / 1 / 2 s ;
- ecoute directe Fin -> Debut ;
- Rendre la boucle invisible ;
- Placer INTRO / OUTRO ;
- sauvegarde des reglages de boucle dans les projets.

COMPILATION ANDROID
1. 01_INSTALL_CAPACITOR.bat
2. 02_CREATE_OR_SYNC_ANDROID.bat
3. 03_OPEN_ANDROID_STUDIO.bat
Puis Android Studio : Build > Build APK(s).

Ou directement : 04_BUILD_DEBUG_APK.bat
Resultat : BUILD\LTC_Music_Studio_V0.6.6-debug.apk

COMMANDES MANUELLES
npm install
npx cap add android   (premiere fois seulement)
npx cap sync android
npx cap open android

Apres modification du web : 06_SYNC_AFTER_WEB_CHANGES.bat
