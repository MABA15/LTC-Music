LTC MUSIC STUDIO V0.7.0 — AUTOMATION DE VOLUME

Cette release conserve toute la V0.6.6 et ajoute une vraie automation de volume par piste.

NOUVEAU
- Mode AUTOMATION dans l’éditeur.
- Courbe de volume 0–100 % sur toute la durée du morceau.
- Ajout d’un point par simple toucher.
- Déplacement tactile des points.
- Lissage DOUX ou LINEAIRE.
- Presets Fade in / Fade out / Montée / Descente / Plat.
- Lecture et exports audio utilisent réellement la courbe.
- Automation sauvegardée dans autosave, bibliothèque et .ltcmusic.
- Compatible avec tous les projets précédents.

ANDROID / CAPACITOR
1. 01_INSTALL_CAPACITOR.bat
2. 02_CREATE_OR_SYNC_ANDROID.bat
3. 03_OPEN_ANDROID_STUDIO.bat
4. Build > Build APK(s) dans Android Studio, ou 04_BUILD_DEBUG_APK.bat

APK debug attendu : BUILD\LTC_Music_Studio_V0.7.0-debug.apk
