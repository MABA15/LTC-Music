LTC MUSIC STUDIO V0.7.1 — AUTOMATIONS FILTRE + REVERB — LIGHT GITHUB

V0.7.1 ajoute :
- automation de filtre par piste ;
- automation de reverb par piste ;
- presets simples Ouvrir/Fermer/Respirer et Apparition/Disparition/Vague ;
- rendu identique en lecture et exports ;
- migration transparente des projets V0.7.0 ;
- package LIGHT : banques instrumentales OGG HQ au lieu de WAV ;
- workflow GitHub Actions inclus pour construire automatiquement l'APK depuis un depot.

Workflow telephone recommande :
1. Uploader LTC_Music_Studio_V0.7.1_light.zip dans le depot.
2. Garder .github/workflows/build-apk.yml dans le depot (a installer une seule fois).
3. GitHub Actions construit l'APK et cree/met a jour la Release v0.7.1.

Workflow local Capacitor toujours disponible :
  npm install
  npx cap add android
  npx cap sync android
  npx cap open android
