LTC MUSIC STUDIO V0.7.10 — LIGHT

Cette release clôture la branche V0.7.x Automation.

Règle principale : aucune automation n'est obligatoire.
- Tout OFF = comportement statique normal.
- Anti-coupures n'agit que sur les courbes actives.
- Les courbes ne sont jamais supprimées lorsque tu désactives les automations.

Nouveautés : anti-coupures 80/150/300 ms, diagnostic, réparation/normalisation, migration et stabilisation Fold/mobile.
