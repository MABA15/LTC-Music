LTC MUSIC STUDIO V0.7.3 — LIGHT / ANDROID / GITHUB

Version light : banques audio OGG HQ, aucun WAV.
Nouveauté V0.7.3 : automation globale du tempo/BPM avec courbe tactile et presets.

Workflow téléphone :
1. Upload LTC_Music_Studio_V0.7.3_light.zip à la racine du dépôt GitHub.
2. Le workflow .github/workflows/build-apk.yml compile l'APK sur GitHub Actions.
3. Récupérer l'APK dans Actions > Artifacts ou Releases si la publication passe.

Les projets V0.7.2 restent compatibles ; l'automation tempo est désactivée par défaut lors de la migration.
