LTC Music Studio V0.7.5

Cette release clôt la branche Automations V0.7.x.
RÈGLE PRINCIPALE : les automations sont facultatives. Si tout est OFF, le moteur utilise uniquement les valeurs fixes du Mixer, des instruments, du rythme et du BPM.

Dans AUTOMATION :
1. Choisir éventuellement une portée de preset.
2. Appuyer sur un preset seulement si souhaité.
3. Modifier les courbes à la main si nécessaire.
4. TOUT DÉSACTIVER pour revenir immédiatement au comportement statique.

Le ZIP light est destiné au workflow GitHub Actions / Capacitor Android depuis téléphone.
