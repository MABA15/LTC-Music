LTC Music Studio V0.7.7 — Groupes/Master + éditeur tactile

Les automations restent entièrement optionnelles.
1. AUTOMATION > + Nouveau groupe pour regrouper des pistes.
2. Choisir groupe ou MASTER puis Volume / Filtre / Reverb.
3. Activer seulement la courbe voulue.
4. Utiliser Zoom / Snap / boutons de précision au doigt.
5. TOUT DÉSACTIVER remet immédiatement le son statique sans effacer les courbes.

Compilation téléphone : uploader ce ZIP light dans le dépôt GitHub configuré avec build-apk.yml.
