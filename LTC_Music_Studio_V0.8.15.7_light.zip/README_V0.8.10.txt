LTC MUSIC STUDIO V0.8.10 — AUDIO PROPRE + LISIBILITÉ

- Boucle de lecture préprogrammée avant la fin du tour précédent.
- Crossfade court à la jonction pour éviter les clics/grésillements.
- Préchargement audio effectué avant la première lecture, sans rechargement à chaque loop.
- Impulsion de reverb mise en cache pendant la session.
- Limiteur master léger contre les pics simultanés.
- Attaque anti-clic ajoutée aux percussions de secours.
- MUTE + SOLO visibles sur chaque piste.
- Couleur de piste renforcée dans la liste, le piano-roll et le mixer.
- Piano-roll : SÉLECTIONNÉE / SÉLECTIONNÉE + FANTÔMES / TOUTES.
- Les pistes non sélectionnées restent non éditables dans le piano-roll.
- Accord : Progression / Écouter accord / Insérer sur la piste.
- Compatibilité projets antérieurs conservée.
- Format light OGG conservé pour GitHub mobile.
