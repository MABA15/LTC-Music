LTC MUSIC STUDIO V0.8.15.6 — PACKAGE LIGHT POUR GITHUB ACTIONS

Ce ZIP est prévu pour le workflow existant :
1. npm install
2. npx cap add android
3. npx cap sync android
4. ./gradlew assembleDebug

Aucune couche Android précompilée n'est incluse.
Le code Android d'export se trouve dans plugins/ltc-native-save/ et sera compilé par Gradle lors du build.

CORRECTIF BUILD 0.8.15.6
- Déclare explicitement androidx.activity:activity pour le plugin local.
- Corrige l'erreur de compilation V0.8.15.5 : package androidx.activity.result does not exist.

FONCTION EXPORT
- Ouvrir Exporter audio.
- Choisir le contenu.
- Choisir WAV / M4A / MP3 / OGG-Opus (selon support encodeur du WebView).
- Choisir qualité, normalisation et fade.
- Appuyer sur Exporter.
- Android ouvre ACTION_CREATE_DOCUMENT pour choisir nom + dossier.
- Le fichier est écrit à l'URI sélectionnée.

STEMS
- Format WAV imposé.
- Sur Android, une fenêtre Enregistrer sous s'ouvre pour chaque stem.

VERSION ANDROID
Le hook Capacitor scripts/patch-android.js est exécuté après cap sync et fixe :
- versionName 0.8.15.6
- versionCode 8156

IMPORTANT
Le ZIP ne contient aucune modification DEX bricolée. MainActivity est générée normalement par Capacitor/Gradle.
