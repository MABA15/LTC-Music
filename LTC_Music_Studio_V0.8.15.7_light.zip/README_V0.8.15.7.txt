LTC MUSIC STUDIO V0.8.15.7 — PACKAGE LIGHT POUR GITHUB ACTIONS

Ce ZIP est prévu pour le workflow existant :
1. npm install
2. npx cap add android
3. npx cap sync android
4. ./gradlew assembleDebug

Aucune couche Android précompilée n'est incluse.
Le plugin d'export Android se trouve dans plugins/ltc-native-save/ et sera compilé normalement par Gradle.

DUPLIQUER UN MOTIF DE PLUSIEURS MESURES
1. Sélectionner la piste concernée.
2. Dans NOTES, toucher « SÉL. MESURES ».
3. Toucher puis glisser horizontalement sur le piano-roll pour couvrir 1 ou plusieurs mesures.
4. Choisir :
   - COPIER, puis COLLER À LA SUITE ; ou
   - DUPLIQUER pour faire les deux en une action.
5. Le collage démarre à la première mesure située après le dernier contenu de la piste active.
6. Répéter « COLLER À LA SUITE » pour répéter le motif autant de fois que nécessaire.

Le bloc copié ne contient que la piste active. Les autres pistes ne sont jamais modifiées.

QUALITÉ AUDIO V0.8.15.7
- Micro-fade minimum 4 ms à l’entrée des samples.
- Micro-fade minimum 6 ms à la sortie.
- Protection appliquée aussi aux sons personnels.
- Aucun changement des mélodies : notes, accords, timing, durées musicales et instruments restent identiques.

EXPORT
- Ouvrir Exporter audio.
- Choisir contenu, format, qualité, normalisation et fade.
- Appuyer sur Exporter.
- Android ouvre ACTION_CREATE_DOCUMENT pour choisir nom + dossier.

VERSION ANDROID
Le hook scripts/patch-android.js fixe après cap sync :
- versionName 0.8.15.7
- versionCode 8157
