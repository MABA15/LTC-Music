LTC Music Studio V0.8.2 — MODE LTC

Le MODE LTC est optionnel et OFF par défaut.

Utilisation rapide :
1. Sauvegarde tes 6 boucles d'une tranche avec le tag horaire correspondant.
2. Dans MODE LTC, choisis une heure simulée.
3. Utilise « Charger une autre boucle » pour tester la rotation de la famille.
4. Sélectionne chaque piste et assigne-la à BASE, ETAT, SUPRA, etc.
5. Mets Etats = 1 pour entendre la couche ETAT ; Supra = 1 pour entendre SUPRA.
6. « TESTER LE MIX LTC » lance la lecture avec ces règles.

V0.8.2 n'automatise pas encore Civilisation / Guerre / Commerce. Ces couches sont déjà structurées pour la suite.
