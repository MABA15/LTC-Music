LTC Music Studio V0.8.4 — MODE LTC

Cette release ajoute Civilisation, Guerre, Commerce et Ambiance aux règles du simulateur musical LTC.

Civilisation
- Choisir 0–100 %.
- Choisir une réponse musicale : Linéaire, Douce, Précoce ou Tardive.
- Le pilotage de la piste CIVILISATION et celui des percussions sont deux options séparées.

Contextes
- GUERRE : cocher « Pilotage auto » pour que la couche suive l’état Guerre ON/OFF.
- COMMERCE : cocher le pilotage puis régler 0–100 %.
- AMBIANCE : idem.
- Sans pilotage auto, ces couches restent libres/manuelles.

Le Mode LTC reste OFF par défaut.
