LTC Music Studio V0.8.7 — MODE LTC COMPLET

Le Mode LTC peut maintenant servir de banc de test avant intégration dans le jeu.

MOTEUR DE RÈGLES
- Active/désactive le moteur indépendamment du Mode LTC.
- Stabilité évite les ON/OFF rapides.
- Hystérésis évite les oscillations autour d’un seuil.
- Ajoute des règles simples depuis l’interface, sans code.

SIMULATEUR
- Utilise les scénarios rapides ou règle les valeurs manuellement.
- Le tableau montre le gain réellement appliqué à chaque couche.

CONFIGURATION
- Export .ltcconfig.json : léger, lisible et destiné à l’intégration future dans Little To Civilisation.
- Il n’embarque ni samples ni audio personnel.
