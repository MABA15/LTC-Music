LTC Music Studio V0.8.8

Release ergonomie mobile/Fold. Le moteur musical et le Mode LTC de V0.8.7 sont conservés.

Navigation :
- PISTES / MIX : affiche ou masque les volets latéraux.
- Sur Fold/mobile, les volets deviennent des tiroirs et ne réduisent plus la zone de composition.
- − / + : zoom de la vue courante.
- 100 % : zoom normal.
- AJUSTER : fait tenir le contenu principal dans la largeur lorsque c'est pertinent.
- CENTRER : recentre la zone.
- ↺ VUE : remet zoom et position à zéro.
- Deux doigts : déplacement + pincement pour zoomer dans les grandes surfaces d'édition.
- Un doigt reste réservé à l'édition des notes/rythmes.

Android/GitHub : package light OGG, compatible workflow GitHub Actions.
