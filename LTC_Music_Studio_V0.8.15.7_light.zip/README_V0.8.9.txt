LTC Music Studio V0.8.9 — hotfix tactile

- Une note tactile n'est plus créée au pointerdown : elle n'est validée qu'au relâchement d'un tap simple.
- Dès qu'un deuxième doigt apparaît, toute édition de note en cours est annulée/restaurée avant le pinch/pan.
- Verrou global de navigation multi-touch + fenêtre anti-click de 500 ms après le geste.
- Les clics synthétiques après pinch sont bloqués dans NOTES/RYTHME/MIXER/ARRANGEMENT/AUTOMATION/MODE LTC.
- Suivi automatique du playhead OFF par défaut et bouton SUIVI ON/OFF.
- Toute navigation à deux doigts coupe automatiquement le suivi playhead.
- Boutons ANNULER / RÉTABLIR / supprimer NOTE directement dans la barre de vue.
- Le moteur musical reste inchangé.
