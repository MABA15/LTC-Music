package com.ltc.musicstudio.save;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.util.Base64;

import androidx.activity.result.ActivityResult;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.IOException;
import java.io.OutputStream;

@CapacitorPlugin(name = "LTCNativeSave")
public class LTCNativeSavePlugin extends Plugin {
    private OutputStream currentStream;
    private Uri currentUri;
    private long bytesWritten;

    @PluginMethod
    public void beginSave(PluginCall call) {
        closeCurrentQuietly();

        String name = call.getString("name", "LTC_Music_Export.wav");
        String mime = call.getString("mime", "application/octet-stream");

        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(mime);
        intent.putExtra(Intent.EXTRA_TITLE, name);
        startActivityForResult(call, intent, "handleCreateDocument");
    }

    @ActivityCallback
    private void handleCreateDocument(PluginCall call, ActivityResult result) {
        if (call == null) {
            return;
        }

        Intent data = result.getData();
        if (result.getResultCode() != Activity.RESULT_OK || data == null || data.getData() == null) {
            JSObject ret = new JSObject();
            ret.put("cancelled", true);
            call.resolve(ret);
            return;
        }

        currentUri = data.getData();
        try {
            currentStream = getContext().getContentResolver().openOutputStream(currentUri, "w");
            if (currentStream == null) {
                currentUri = null;
                call.reject("Impossible d'ouvrir le fichier sélectionné.");
                return;
            }
            bytesWritten = 0;
            JSObject ret = new JSObject();
            ret.put("cancelled", false);
            ret.put("uri", currentUri.toString());
            call.resolve(ret);
        } catch (Exception ex) {
            closeCurrentQuietly();
            call.reject("Impossible de créer le fichier : " + ex.getMessage());
        }
    }

    @PluginMethod
    public void appendChunk(PluginCall call) {
        if (currentStream == null) {
            call.reject("Aucun fichier d'export n'est ouvert.");
            return;
        }
        String encoded = call.getString("data");
        if (encoded == null) {
            call.reject("Chunk audio manquant.");
            return;
        }

        try {
            byte[] bytes = Base64.decode(encoded, Base64.NO_WRAP);
            currentStream.write(bytes);
            bytesWritten += bytes.length;
            JSObject ret = new JSObject();
            ret.put("written", bytes.length);
            ret.put("totalWritten", bytesWritten);
            call.resolve(ret);
        } catch (Exception ex) {
            call.reject("Erreur d'écriture : " + ex.getMessage());
        }
    }

    @PluginMethod
    public void finishSave(PluginCall call) {
        if (currentStream == null) {
            call.reject("Aucun fichier d'export n'est ouvert.");
            return;
        }
        try {
            currentStream.flush();
            currentStream.close();
            currentStream = null;
            currentUri = null;
            JSObject ret = new JSObject();
            ret.put("saved", true);
            ret.put("bytes", bytesWritten);
            bytesWritten = 0;
            call.resolve(ret);
        } catch (IOException ex) {
            closeCurrentQuietly();
            call.reject("Impossible de finaliser le fichier : " + ex.getMessage());
        }
    }

    @PluginMethod
    public void abortSave(PluginCall call) {
        closeCurrentQuietly();
        JSObject ret = new JSObject();
        ret.put("aborted", true);
        call.resolve(ret);
    }

    @Override
    protected void handleOnDestroy() {
        closeCurrentQuietly();
        super.handleOnDestroy();
    }

    private void closeCurrentQuietly() {
        if (currentStream != null) {
            try {
                currentStream.close();
            } catch (IOException ignored) {
            }
        }
        currentStream = null;
        currentUri = null;
        bytesWritten = 0;
    }
}
