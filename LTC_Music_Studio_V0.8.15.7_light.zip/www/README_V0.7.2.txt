LTC MUSIC STUDIO V0.7.2 — LIGHT / ANDROID / GITHUB

Cette release ajoute l’automation globale des percussions : intensité et densité.
Le preset Civilisation 0→100 % reproduit la montée progressive du “cœur” rythmique imaginé pour LTC.

PACKAGE LIGHT
- Audio en OGG HQ.
- ZIP prévu pour rester sous 25 Mo et être envoyé sur GitHub depuis le téléphone.

GITHUB ACTIONS
- build-apk.yml inclus.
- Le workflow installe Node 22, Java 21, Android SDK 36, Capacitor 8, puis compile l’APK.
- L’APK est publié en Artifact et en GitHub Release.
