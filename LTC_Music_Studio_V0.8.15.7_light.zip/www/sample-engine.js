(() => {
'use strict';

const BASE = './sample-packs/';
const packUrls = new Map([
 ['classical-guitar-hq', BASE+'classical-guitar-hq/manifest.json'],['nylon-guitar-hq', BASE+'nylon-guitar-hq/manifest.json'],
 ['dry-piano-hq', BASE+'dry-piano-hq/manifest.json'],['felt-piano-hq', BASE+'felt-piano-hq/manifest.json'],['rhodes-hq', BASE+'rhodes-hq/manifest.json'],
 ['marimba-hq', BASE+'marimba-hq/manifest.json'],['kalimba-hq', BASE+'kalimba-hq/manifest.json'],['mandolin-hq', BASE+'mandolin-hq/manifest.json'],
 ['pizzicato-hq', BASE+'pizzicato-hq/manifest.json'],['harp-hq', BASE+'harp-hq/manifest.json'],['hand-drum-hq', BASE+'hand-drum-hq/manifest.json'],
 ['wood-perc-hq', BASE+'wood-perc-hq/manifest.json'],['shaker-hq', BASE+'shaker-hq/manifest.json'],['triangle-hq', BASE+'triangle-hq/manifest.json'],
 ['round-bass-hq', BASE+'round-bass-hq/manifest.json'],['diagnostic-pluck', BASE+'diagnostic/manifest.json']
]);
const manifests = new Map();
const rawCache = new Map();
const bufferCache = new Map();
const rrCounters = new Map();
const errors = new Map();
let stats = {fetches:0, decodes:0, hits:0, scheduled:0, fallbacks:0, partialPreloads:0, fullPreloads:0, evictions:0};
const MICRO_FADE_IN_SEC_V08157=.004;
const MICRO_FADE_OUT_SEC_V08157=.006;

function dbToGain(db){ return Math.pow(10,(db||0)/20); }
function absUrl(rel, manifestUrl){ return new URL(rel, new URL(manifestUrl, location.href)).href; }
function bufferBytes(buf){ return (buf?.length||0)*(buf?.numberOfChannels||1)*4; }
function cacheKey(packId, rel){ return packId+'|'+rel; }

async function fetchJson(url){
  const embedded = window.LTC_EMBEDDED_SAMPLE_PACKS;
  if(embedded){
    const hit = Object.values(embedded).find(p => p.manifestUrl === url || p.id === url);
    if(hit) return hit.manifest;
  }
  const r = await fetch(url);
  if(!r.ok) throw new Error(`HTTP ${r.status} — ${url}`);
  return r.json();
}

async function loadManifest(packId){
  if(manifests.has(packId)) return manifests.get(packId);
  const embedded = window.LTC_EMBEDDED_SAMPLE_PACKS?.[packId];
  if(embedded){ manifests.set(packId,{manifest:embedded.manifest,url:embedded.manifestUrl||('embedded:'+packId)}); return manifests.get(packId); }
  const url = packUrls.get(packId);
  if(!url) throw new Error('Pack inconnu : '+packId);
  try{
    const manifest = await fetchJson(url);
    if(manifest.schema !== 'ltc-multisample-1') throw new Error('Schéma de pack non pris en charge');
    manifests.set(packId,{manifest,url});
    return manifests.get(packId);
  }catch(e){ errors.set(packId,String(e.message||e)); throw e; }
}

function itemFor(packId, loaded, rel){
  const embedded = window.LTC_EMBEDDED_SAMPLE_PACKS?.[packId]?.files?.[rel];
  return {rel,url:embedded || absUrl(rel,loaded.url)};
}
function sampleUrls(packId, loaded){
  const out=[];
  for(const region of loaded.manifest.regions||[]) for(const rel of region.roundRobin||[]) out.push(itemFor(packId,loaded,rel));
  return out;
}

async function fetchArrayBuffer(packId, item){
  const key=cacheKey(packId,item.rel);
  if(rawCache.has(key)){ stats.hits++; return rawCache.get(key).slice(0); }
  let ab;
  if(item.url.startsWith('data:')){
    const r=await fetch(item.url); ab=await r.arrayBuffer();
  }else{
    const r=await fetch(item.url); if(!r.ok)throw new Error(`Sample manquant ${item.rel} (HTTP ${r.status})`); ab=await r.arrayBuffer(); stats.fetches++;
  }
  // Raw bytes are held only until decode. Persistent offline cache is handled by the service worker.
  rawCache.set(key,ab.slice(0));
  return ab;
}

async function decodeItem(packId, item, ctx){
  const key=cacheKey(packId,item.rel);
  if(bufferCache.has(key)){ stats.hits++; return bufferCache.get(key); }
  const ab=await fetchArrayBuffer(packId,item);
  try{
    const buf=await ctx.decodeAudioData(ab.slice(0));
    bufferCache.set(key,buf); stats.decodes++;
    return buf;
  } finally {
    // V0.4.10: do not keep a second copy of every decoded sample in RAM.
    rawCache.delete(key);
  }
}

function chooseRegion(manifest,midi,velocity){
  const regs=manifest.regions||[];
  const vel=Number.isFinite(velocity)?velocity:.72;
  let candidates=regs.filter(r=>vel >= (r.velocityMin ?? 0) && vel < (r.velocityMax ?? 1.001));
  if(!candidates.length)candidates=regs;
  candidates.sort((a,b)=>Math.abs(a.rootMidi-midi)-Math.abs(b.rootMidi-midi));
  const max=(manifest.defaults?.maxPitchSemitones ?? 12);
  return candidates.find(r=>Math.abs(r.rootMidi-midi)<= (r.maxPitchSemitones ?? max)) || candidates[0] || null;
}
function regionSignature(r){ return `${r.rootMidi}|${r.velocityMin??0}|${r.velocityMax??1}`; }

async function preloadItems(packId, loaded, items, ctx, onProgress){
  let done=0;
  for(const item of items){
    const key=cacheKey(packId,item.rel);
    if(!bufferCache.has(key)){
      try{ await decodeItem(packId,item,ctx); }
      catch(e){ errors.set(key,String(e.message||e)); }
    } else stats.hits++;
    done++; onProgress?.(done,items.length,item.rel);
  }
  return getPackStatus(packId);
}

async function preloadPack(packId, ctx, onProgress){
  const loaded=await loadManifest(packId); stats.fullPreloads++;
  return preloadItems(packId,loaded,sampleUrls(packId,loaded),ctx,onProgress);
}

function wantedRelsForUsage(loaded,usage=[]){
  const wanted=new Map();
  for(const u of usage){const r=chooseRegion(loaded.manifest,Number(u.midi),Number.isFinite(u.velocity)?Number(u.velocity):.72);if(r)wanted.set(regionSignature(r),r);}
  const rels=new Set();for(const r of wanted.values())for(const rel of r.roundRobin||[])rels.add(rel);return rels;
}
function trimPackToUsage(packId,usage=[]){
  const loaded=manifests.get(packId);if(!loaded)return 0;const keep=wantedRelsForUsage(loaded,usage);let freed=0;
  for(const [k,b] of [...bufferCache.entries()])if(k.startsWith(packId+'|')){const rel=k.slice(packId.length+1);if(!keep.has(rel)){freed+=bufferBytes(b);bufferCache.delete(k);stats.evictions++;}}
  for(const k of [...rawCache.keys()])if(k.startsWith(packId+'|')){const rel=k.slice(packId.length+1);if(!keep.has(rel))rawCache.delete(k);}
  return freed;
}

// V0.4.10: load only regions actually used by the current composition.
async function preloadUsage(packId, ctx, usage=[], onProgress){
  const loaded=await loadManifest(packId);
  const rels=wantedRelsForUsage(loaded,usage);
  if(!rels.size) return getPackStatus(packId);
  const items=[...rels].map(rel=>itemFor(packId,loaded,rel));
  stats.partialPreloads++;
  return preloadItems(packId,loaded,items,ctx,onProgress);
}

function nextRoundRobin(packId,region){
  const arr=region.roundRobin||[];
  if(!arr.length)return null;
  const k=packId+'|'+regionSignature(region);
  const i=rrCounters.get(k)||0; rrCounters.set(k,i+1);
  return arr[i%arr.length];
}

function schedule(packId,ctx,dest,start,dur,midi,velocity,track,nodes){
  const loaded=manifests.get(packId);
  if(!loaded){stats.fallbacks++; return false;}
  const {manifest}=loaded;
  const region=chooseRegion(manifest,midi,velocity);
  if(!region){stats.fallbacks++; return false;}
  const rel=nextRoundRobin(packId,region);
  const buffer=bufferCache.get(cacheKey(packId,rel));
  if(!buffer){stats.fallbacks++; return false;}

  const source=ctx.createBufferSource(); source.buffer=buffer;
  const semis=midi-region.rootMidi; source.playbackRate.value=Math.pow(2,semis/12);
  const filter=ctx.createBiquadFilter();filter.type='lowpass';filter.frequency.value=track.filter||manifest.defaults?.filter||14000;
  const gain=ctx.createGain(); source.connect(gain); gain.connect(filter); filter.connect(dest);
  const a=Math.max(MICRO_FADE_IN_SEC_V08157, track.attack ?? manifest.defaults?.attack ?? .005);
  const r=Math.max(MICRO_FADE_OUT_SEC_V08157, .03, track.release ?? manifest.defaults?.release ?? .5);
  const regGain=dbToGain((manifest.defaults?.gainDb||0)+(region.gainDb||0));
  const peak=Math.max(.0002,velocity*.72*regGain);
  gain.gain.setValueAtTime(.0001,start);
  gain.gain.exponentialRampToValueAtTime(peak,start+a);

  const rate=source.playbackRate.value;
  const natural=buffer.duration/Math.max(.01,rate);
  const mode=region.mode||manifest.defaults?.mode||'oneShot';
  let stopAt;
  if(mode==='loop' && region.loopStart != null && region.loopEnd != null){
    source.loop=true;source.loopStart=region.loopStart;source.loopEnd=region.loopEnd;
    gain.gain.setValueAtTime(Math.max(.0002,peak*.92),start+Math.max(a,dur));
    gain.gain.exponentialRampToValueAtTime(.0001,start+dur+r);
    stopAt=start+dur+r+.04;
  }else if(mode==='gate'){
    gain.gain.setValueAtTime(Math.max(.0002,peak*.80),start+Math.min(dur,Math.max(a+.05,natural*.65)));
    gain.gain.exponentialRampToValueAtTime(.0001,start+dur+r);
    stopAt=start+Math.max(dur+r,natural)+.04;
  }else{
    const tail=Math.min(natural,Math.max(a+.08,dur+r));
    gain.gain.exponentialRampToValueAtTime(.0001,start+Math.max(a+.05,tail));
    stopAt=start+natural+.03;
  }
  source.start(start); source.stop(stopAt); nodes?.push(source); stats.scheduled++;
  return true;
}

function getPackStatus(packId){
  const loaded=manifests.get(packId), manifest=loaded?.manifest;
  if(!manifest)return {id:packId,loaded:false,ready:false,error:errors.get(packId)||null,samples:0,decoded:0,decodedBytes:0};
  let samples=0,decoded=0,decodedBytes=0;
  for(const r of manifest.regions||[])for(const rel of r.roundRobin||[]){
    samples++; const b=bufferCache.get(cacheKey(packId,rel)); if(b){decoded++;decodedBytes+=bufferBytes(b);}
  }
  return {id:packId,name:manifest.name,version:manifest.version,description:manifest.description,loaded:true,ready:samples>0&&decoded===samples,samples,decoded,decodedBytes,error:errors.get(packId)||null};
}

function clearCache(packId){
  let freed=0;
  for(const [k,b] of [...bufferCache.entries()]) if(!packId||k.startsWith(packId+'|')){freed+=bufferBytes(b);bufferCache.delete(k);stats.evictions++;}
  for(const k of [...rawCache.keys()]) if(!packId||k.startsWith(packId+'|')) rawCache.delete(k);
  if(!packId)rrCounters.clear();
  return freed;
}
function retainPacks(packIds=[]){
  const keep=new Set(packIds); let freed=0;
  for(const [k,b] of [...bufferCache.entries()]){
    const pack=k.split('|',1)[0]; if(!keep.has(pack)){freed+=bufferBytes(b);bufferCache.delete(k);stats.evictions++;}
  }
  for(const k of [...rawCache.keys()]){const pack=k.split('|',1)[0];if(!keep.has(pack))rawCache.delete(k);}
  return freed;
}

async function clearPersistentSampleCache(){
  if(!('caches' in window)) return 0;
  let deleted=0;
  for(const name of await caches.keys()){
    if(!name.startsWith('ltc-music-studio-')) continue;
    const c=await caches.open(name);
    for(const req of await c.keys()){
      const u=new URL(req.url);
      if(u.pathname.includes('/sample-packs/') && !/manifest\.json$|index\.json$/.test(u.pathname)){
        if(await c.delete(req)) deleted++;
      }
    }
  }
  return deleted;
}

function registerPack(packId,manifestUrl){packUrls.set(packId,manifestUrl);}
function listKnownPacks(){return [...packUrls.keys()].map(getPackStatus);}
function getStats(){
  let decodedBytes=0; for(const b of bufferCache.values()) decodedBytes+=bufferBytes(b);
  let rawBytes=0; for(const ab of rawCache.values()) rawBytes+=ab.byteLength||0;
  return {...stats,buffers:bufferCache.size,raw:rawCache.size,decodedBytes,rawBytes,decodedMB:decodedBytes/1048576,rawMB:rawBytes/1048576,errors:errors.size};
}

window.LTCSampleEngine={
  version:'0.4.10', registerPack, loadManifest, preloadPack, preloadUsage, schedule,
  getPackStatus, listKnownPacks, clearCache, retainPacks, trimPackToUsage, clearPersistentSampleCache, getStats
};
})();
