LTC MUSIC STUDIO V0.8.15.8 — PACKAGE LIGHT POUR GITHUB ACTIONS

BASE
- Reprend V0.8.15.7 sans régression volontaire.
- Export Android natif LTCNativeSave conservé.
- Sélection / duplication de mesures conservée.
- Micro-fades audio V0.8.15.7 conservés.

NOUVEAU — ACCORDS DEPUIS MIXTE
- L'insertion d'un accord vise maintenant la prochaine mesure vide de la piste active.
- Piste vide : mesure 1.
- Sinon : première mesure située après la dernière mesure réellement occupée par une note de la piste.
- Si une note déborde sur la mesure suivante, cette mesure est considérée occupée.
- Le morceau s'agrandit automatiquement si l'accord doit être ajouté après la dernière mesure existante.
- Accord inséré sur 4 temps, notes/voicing/instrument inchangés.

ANDROID
- versionName 0.8.15.8
- versionCode 8158
- Le hook capacitor:sync:after applique ces valeurs après cap sync.

BUILD GITHUB
Déposer LTC_Music_Studio_V0.8.15.8_light.zip à la racine du dépôt.
Le workflow existant peut faire npm install -> cap add android -> cap sync android -> gradlew assembleDebug.
