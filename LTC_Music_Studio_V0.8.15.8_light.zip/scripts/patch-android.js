const fs = require('fs');
const path = require('path');

if (process.env.CAPACITOR_PLATFORM_NAME && process.env.CAPACITOR_PLATFORM_NAME !== 'android') process.exit(0);

const gradlePath = path.join(__dirname, '..', 'android', 'app', 'build.gradle');
if (!fs.existsSync(gradlePath)) {
  console.error('[LTC] android/app/build.gradle absent après cap sync');
  process.exit(1);
}

let text = fs.readFileSync(gradlePath, 'utf8');
const versionCode = 8158;
const versionName = '0.8.15.8';

if (!/versionCode\s+\d+/.test(text) || !/versionName\s+["'][^"']+["']/.test(text)) {
  console.error('[LTC] versionCode/versionName introuvables dans build.gradle');
  process.exit(1);
}
text = text.replace(/versionCode\s+\d+/, `versionCode ${versionCode}`);
text = text.replace(/versionName\s+["'][^"']+["']/, `versionName "${versionName}"`);
fs.writeFileSync(gradlePath, text);
console.log(`[LTC] Android version patched: ${versionName} (${versionCode})`);
