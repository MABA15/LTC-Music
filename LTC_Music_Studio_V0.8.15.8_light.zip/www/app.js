(() => {
'use strict';

const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const clamp = (v,a,b) => Math.max(a, Math.min(b,v));
const uid = () => Math.random().toString(36).slice(2,9);
const NOTE_NAMES = ['C','C#','D','D#','E','F','F#','G','G#','A','A#','B'];
const COLORS = ['#7ee787','#56b6c2','#d7ba7d','#c586c0','#9cdcfe','#ce9178','#b5cea8','#d16969'];
const SCALE_MAJOR = [0,2,4,5,7,9,11];
const MOTIF_SCALES = {
  major:[0,2,4,5,7,9,11], minor:[0,2,3,5,7,8,10],
  pentaMajor:[0,2,4,7,9], pentaMinor:[0,3,5,7,10]
};
const CHORD_INTERVALS = {maj7:[0,4,7,11],min7:[0,3,7,10],sus2:[0,2,7],maj:[0,4,7],min:[0,3,7]};
let motifCandidate=[], motifSource=[], motifSourceMeta=null, motifPreviewTimer=null, motifCandidateMode='new';
let arrangementPreviewTimer=null;
const keyNames = ['C','C#','D','D#','E','F','F#','G','G#','A','A#','B'];
const PERF_KEY='ltc-studio-v0.8.7-performance';
const perfPrefs=(()=>{try{const p=JSON.parse(localStorage.getItem(PERF_KEY)||'{}');return {mobileMemory:p.mobileMemory!==false};}catch{return {mobileMemory:true};}})();
let responsiveRAF=0,lastPlayheadPaint=0;
const UX10_KEY='ltc-studio-v0.8.10-ui';
const uxPrefsV0810=(()=>{try{const p=JSON.parse(localStorage.getItem(UX10_KEY)||'{}');return {rollMode:['current','ghosts','all'].includes(p.rollMode)?p.rollMode:'ghosts'};}catch{return {rollMode:'ghosts'};}})();
function saveUxPrefsV0810(){try{localStorage.setItem(UX10_KEY,JSON.stringify(uxPrefsV0810));}catch{}}
const cachedImpulsesV0810=new WeakMap();
const liveAudioV0810={ctx:null,master:null,limiter:null,ceiling:null,dcFilter:null,cycleTimer:null,cycleSec:0,scheduledCycle:0,crossfade:.28};
const PLAYHEAD_PAINT_MS_V0813=100;
const LIVE_MASTER_GAIN_V0813=.64;
let audioCeilingCurveV0813=null;
function audioSoftCeilingCurveV0813(){if(audioCeilingCurveV0813)return audioCeilingCurveV0813;const n=16384,c=new Float32Array(n),knee=.78,top=.975,span=top-knee;for(let i=0;i<n;i++){const x=-4+8*i/(n-1),a=Math.abs(x);let y=a<=knee?a:knee+span*(1-Math.exp(-(a-knee)/Math.max(.0001,span)));y=Math.min(top,y);c[i]=Math.sign(x)*y;}audioCeilingCurveV0813=c;return c;}
function connectSafePreviewV0813(ctx,input){const pre=ctx.createGain(),comp=ctx.createDynamicsCompressor(),ceil=ctx.createWaveShaper();pre.gain.value=.72;comp.threshold.value=-9;comp.knee.value=8;comp.ratio.value=8;comp.attack.value=.004;comp.release.value=.16;ceil.curve=audioSoftCeilingCurveV0813();try{ceil.oversample='2x';}catch{}input.connect(pre);pre.connect(comp);comp.connect(ceil);ceil.connect(ctx.destination);return {pre,comp,ceil};}
const AUDIO_EDGE_FADE_V0811=.012;
const AUDIO_MICRO_FADE_IN_V08157=.004;
const AUDIO_MICRO_FADE_OUT_V08157=.006;
const measureEditV08157={active:false,startBar:null,endBar:null,dragging:false,pointerId:null,anchorBar:null,clipboard:null};
function savePerfPrefs(){try{localStorage.setItem(PERF_KEY,JSON.stringify(perfPrefs));}catch{}}
function scheduleResponsiveRender(){if(responsiveRAF)return;responsiveRAF=requestAnimationFrame(()=>{responsiveRAF=0;renderKeyboard();renderRoll();});}

const PRESETS = {
  'Guitare classique sèche': {kind:'pluck',wave:'triangle',partials:[[1,1],[2,.20],[3,.05]],attack:.008,release:1.15,filter:9000},
  '🎸 Guitare classique sèche HQ': {engine:'multisample',packId:'classical-guitar-hq',kind:'pluck',wave:'triangle',partials:[[1,1],[2,.20],[3,.05]],attack:.003,release:.22,filter:12500,hq:true},
  '🎸 Guitare nylon douce HQ': {engine:'multisample',packId:'nylon-guitar-hq',kind:'pluck',wave:'triangle',partials:[[1,1],[2,.14],[3,.035]],attack:.006,release:.55,filter:9000,hq:true},
  'Guitare nylon douce': {kind:'pluck',wave:'triangle',partials:[[1,1],[2,.16],[3,.04]],attack:.012,release:1.7,filter:7000},
  '🎹 Piano feutré HQ': {engine:'multisample',packId:'felt-piano-hq',kind:'key',wave:'sine',partials:[[1,1],[2,.16],[3,.04]],attack:.007,release:1.25,filter:6200,hq:true},
  '🎹 Piano sec HQ': {engine:'multisample',packId:'dry-piano-hq',kind:'key',wave:'sine',partials:[[1,1],[2,.23],[3,.07]],attack:.003,release:.72,filter:12500,hq:true},
  'Piano feutré': {kind:'key',wave:'sine',partials:[[1,1],[2,.18],[3,.05]],attack:.025,release:2.7,filter:6500},
  'Piano sec': {kind:'key',wave:'sine',partials:[[1,1],[2,.25],[3,.08]],attack:.008,release:1.15,filter:9000},
  '🎹 Rhodes HQ': {engine:'multisample',packId:'rhodes-hq',kind:'key',wave:'sine',partials:[[1,1],[2,.12],[4,.025]],attack:.004,release:1.45,filter:9800,hq:true},
  'Rhodes': {kind:'key',wave:'sine',partials:[[1,1],[2,.12],[4,.025]],attack:.02,release:2.2,filter:8500},
  '🪕 Kalimba douce HQ': {engine:'multisample',packId:'kalimba-hq',kind:'pluck',wave:'sine',partials:[[1,1],[2,.07],[3,.015]],attack:.002,release:.78,filter:11500,hq:true},
  'Kalimba': {kind:'pluck',wave:'sine',partials:[[1,1],[2,.07],[3,.015]],attack:.004,release:1.15,filter:10000},
  '🪵 Marimba bois HQ': {engine:'multisample',packId:'marimba-hq',kind:'pluck',wave:'sine',partials:[[1,1],[2,.035]],attack:.002,release:.62,filter:10500,hq:true},
  'Marimba': {kind:'pluck',wave:'sine',partials:[[1,1],[2,.035]],attack:.006,release:1.0,filter:7200},
  '🪕 Mandoline douce HQ': {engine:'multisample',packId:'mandolin-hq',kind:'pluck',wave:'triangle',partials:[[1,1],[2,.08],[3,.015]],attack:.002,release:.52,filter:11000,hq:true},
  'Mandoline douce': {kind:'pluck',wave:'triangle',partials:[[1,1],[2,.08],[3,.015]],attack:.004,release:1.1,filter:9000},
  'Harpe': {kind:'pluck',wave:'triangle',partials:[[1,1],[2,.08],[3,.02]],attack:.006,release:2.0,filter:10500},
  '🎻 Cordes pizzicato HQ': {engine:'multisample',packId:'pizzicato-hq',kind:'pluck',wave:'triangle',partials:[[1,1],[2,.06]],attack:.002,release:.45,filter:9200,hq:true},
  '🪉 Harpe douce HQ': {engine:'multisample',packId:'harp-hq',kind:'pluck',wave:'sine',partials:[[1,1],[2,.18],[3,.06]],attack:.004,release:1.15,filter:10500,hq:true},
  'Pizzicato': {kind:'pluck',wave:'triangle',partials:[[1,1],[2,.06]],attack:.005,release:.65,filter:8200},
  '🎸 Basse ronde HQ': {engine:'multisample',packId:'round-bass-hq',kind:'key',wave:'sine',partials:[[1,1],[2,.12]],attack:.008,release:1.6,filter:4200,hq:true},
  'Basse ronde': {kind:'key',wave:'sine',partials:[[1,1],[2,.10]],attack:.02,release:1.5,filter:2600},
  '🌫 Pad chaud HQ': {mixTrim:.84,engine:'pad-hq',kind:'pad',attack:.55,release:4.8,filter:5600,hq:true,padVoices:[[-7,1,'sine'],[7,.95,'sine'],[-2,.28,'triangle'],[3,.22,'triangle']],lfoRate:.075,lfoDepth:.055,filterDrift:340},
  '☁️ Pad aérien HQ': {mixTrim:.80,engine:'pad-hq',kind:'pad',attack:.85,release:5.6,filter:8200,hq:true,padVoices:[[-9,.78,'sine'],[9,.76,'sine'],[-3,.24,'sine'],[5,.18,'triangle']],lfoRate:.055,lfoDepth:.075,filterDrift:520},
  '🌑 Pad sombre HQ': {mixTrim:.86,engine:'pad-hq',kind:'pad',attack:.70,release:5.2,filter:3600,hq:true,padVoices:[[-5,1,'sine'],[5,.90,'sine'],[-12,.20,'triangle'],[12,.12,'sine']],lfoRate:.045,lfoDepth:.045,filterDrift:220},
  'Pad chaud': {kind:'pad',wave:'sine',partials:[[1,1],[2,.08],[3,.02]],attack:.35,release:3.8,filter:5200},
  'Pad aérien': {kind:'pad',wave:'sine',partials:[[1,1],[2,.04]],attack:.65,release:4.5,filter:7000},
  '🔺 Triangle doux HQ': {engine:'multisample',packId:'triangle-hq',kind:'pluck',wave:'sine',partials:[[1,1],[2,.03]],attack:.002,release:1.2,filter:15500,hq:true,percussionMidi:84,percussionFallback:'triangle'},
  '🥁 Hand drum HQ': {engine:'multisample',packId:'hand-drum-hq',percussion:'sample',percussionMidi:36,percussionFallback:'drum',attack:.002,release:.35,filter:5200,hq:true},
  '🪵 Percussion bois HQ': {engine:'multisample',packId:'wood-perc-hq',percussion:'sample',percussionMidi:60,percussionFallback:'wood',attack:.001,release:.22,filter:9000,hq:true},
  '✨ Shaker doux HQ': {engine:'multisample',packId:'shaker-hq',percussion:'sample',percussionMidi:72,percussionFallback:'shaker',attack:.001,release:.12,filter:15000,hq:true},
  'Triangle doux': {kind:'pluck',wave:'sine',partials:[[1,1],[2,.03]],attack:.01,release:2.0,filter:12000},
  'Percussion bois': {percussion:'wood',attack:.002,release:.25,filter:5500},
  'Hand drum': {percussion:'drum',attack:.002,release:.35,filter:2500},
  'Shaker doux': {percussion:'shaker',attack:.001,release:.12,filter:12000},
  '🧪 Multisample diagnostic': {engine:'multisample',packId:'diagnostic-pluck',kind:'sample',attack:.004,release:.9,filter:12000,diagnostic:true}
 };

function customInstrumentKey(id){return 'custom:'+id;}
function ensureCustomPreset(sample){
  if(!sample?.id)return null;const key=customInstrumentKey(sample.id);
  PRESETS[key]=PRESETS[key]||{engine:'custom-sample',sampleId:sample.id,kind:'sample',attack:.01,release:.12,filter:18000,custom:true};
  PRESETS[key].sampleId=sample.id;PRESETS[key].customName=sample.name||'Son personnel';
  if(els?.instrument && ![...els.instrument.options].some(o=>o.value===key))els.instrument.add(new Option('🎙 '+PRESETS[key].customName,key));
  else if(els?.instrument){const o=[...els.instrument.options].find(o=>o.value===key);if(o)o.textContent='🎙 '+PRESETS[key].customName;}
  return key;
}
function ensureCustomPlaceholder(key){if(!String(key||'').startsWith('custom:'))return;const id=String(key).slice(7);ensureCustomPreset({id,name:'Son personnel'});}
async function syncCustomPresets(){if(!window.LTCCustomSamples)return;const rows=await window.LTCCustomSamples.refreshMetadata(),keep=new Set(rows.map(r=>customInstrumentKey(r.id)));state.tracks.forEach(t=>{if(String(t.instrument||'').startsWith('custom:'))keep.add(t.instrument);});if(els?.instrument){[...els.instrument.options].filter(o=>String(o.value).startsWith('custom:')&&!keep.has(o.value)).forEach(o=>o.remove());}rows.forEach(ensureCustomPreset);renderInspector();}
function customSampleIdsInProject(){return [...new Set(state.tracks.map(t=>window.LTCCustomSamples?.customIdFromInstrument(t.instrument)).filter(Boolean))];}
function addCustomSampleToProject(sample){
  if(!sample?.id)return;if(state.tracks.length>=12)return toast('Maximum 12 pistes en V0.8.15.8');
  const key=ensureCustomPreset(sample),i=state.tracks.length,t=mkTrack(sample.name||'Ambiance perso',key,i);t.volume=.72;t.reverb=.05;t.filter=18000;t.attack=.01;t.release=.12;
  const sec=Math.max(.05,((sample.trimEnd??sample.duration)-(sample.trimStart||0))/(sample.speed||1));const beats=sample.loop?totalBeats():Math.min(totalBeats(),sec*state.bpm/60);
  t.notes=[{id:uid(),beat:0,dur:Math.max(state.grid,beats),midi:60,velocity:.85}];mutate(()=>{state.tracks.push(t);state.selectedTrackId=t.id;state.selectedNoteId=t.notes[0].id;});renderAll();toast(sample.loop?'Son ajouté en boucle':'Segment ajouté au morceau');
}

const defaultTracks = [
  mkTrack('Guitare','🎸 Guitare classique sèche HQ',0),
  mkTrack('Rhodes','🎹 Rhodes HQ',1),
  mkTrack('Pad','🌫 Pad chaud HQ',2),
  mkTrack('Basse','🎸 Basse ronde HQ',3)
];
function mkTrack(name,instrument,colorIndex){
  const p = PRESETS[instrument];
  return {id:uid(),name,instrument,color:COLORS[colorIndex%COLORS.length],volume:.75,pan:0,attack:p.attack,release:p.release,reverb:.15,filter:p.filter,mute:false,solo:false,ltcLayer:'BASE',notes:[]};
}

const state = {
  bpm:76, key:0, bars:10, duration:(10*4*60/76), grid:.5, zoom:58, loop:true,
  projectId:null, projectName:'Nouvelle composition', projectTag:'Autre', dirty:false,
  tracks:defaultTracks, selectedTrackId:defaultTracks[0].id, selectedNoteId:null,
  chords:[], arrangements:{}, drums:{'🥁 Hand drum HQ':new Set([0,8]),'🪵 Percussion bois HQ':new Set([4,12]),'✨ Shaker doux HQ':new Set([2,6,10,14]),'🔺 Triangle doux HQ':new Set()},
  rhythmIntensityAutomation:{enabled:false,curve:'soft',points:[{sec:0,value:1},{sec:(10*4*60/76),value:1}]},
  rhythmDensityAutomation:{enabled:false,curve:'soft',points:[{sec:0,value:1},{sec:(10*4*60/76),value:1}]},
  tempoAutomation:{enabled:false,curve:'soft',points:[{sec:0,bpm:76},{sec:(10*4*60/76),bpm:76}]},
  automationGroups:[],
  masterBusAutomation:{volumeAutomation:{enabled:false,curve:'soft',points:[{sec:0,value:1},{sec:(10*4*60/76),value:1}]},filterAutomation:{enabled:false,curve:'soft',points:[{sec:0,value:1},{sec:(10*4*60/76),value:1}]},reverbAutomation:{enabled:false,curve:'soft',points:[{sec:0,value:0},{sec:(10*4*60/76),value:0}]}},
  automationEditor:{zoom:1,snap:1},
  automationSafety:{enabled:true,smoothingMs:150},
  ltcMode:{enabled:false,simTime:'14:00',colonies:1,states:0,supras:0,civilisation:100,civilisationAuto:true,civilisationDrums:true,civilisationCurve:'soft',war:false,warAuto:false,commerce:0,commerceAuto:false,ambiance:100,ambianceAuto:false,transitionSec:2,autoFamily:true,lastSlot:'12-18'},
  history:[], future:[], humanize:.25,
  playing:false, startAudioTime:0, playTimer:null, playheadRAF:null, audioCtx:null, nodes:[]
};

const els = {
  bpm:$('#bpm'), key:$('#keySelect'), durationBars:$('#durationBarsLabel'), durationSeconds:$('#durationSecondsLabel'), durationMinus:$('#durationMinusBtn'), durationPlus:$('#durationPlusBtn'), grid:$('#gridSelect'), zoom:$('#zoomSlider'),
  tracks:$('#tracks'), roll:$('#rollCanvas'), rollScroller:$('#rollScroller'), keyboard:$('#keyboard'),
  instrument:$('#instrumentSelect'), volume:$('#volume'), pan:$('#pan'), attack:$('#attack'), release:$('#release'), reverb:$('#reverb'), filter:$('#filter'), velocity:$('#velocity'),
  play:$('#playBtn'), stop:$('#stopBtn'), loop:$('#loopBtn'), humanize:$('#humanizeBtn'), chordRoot:$('#chordRoot'), chordType:$('#chordType'), chords:$('#chordsList'),
  drums:$('#drumGrid'), mixer:$('#mixer'), workspace:$('.workspace'), fileInput:$('#fileInput'),
  projectName:$('#projectName'), projectTag:$('#projectTag'), autosaveStatus:$('#autosaveStatus'), libraryModal:$('#libraryModal'), libraryList:$('#libraryList'), librarySearch:$('#librarySearch'), libraryFilter:$('#libraryFilter'), virtualPiano:$('#virtualPiano'), pianoOctave:$('#pianoOctave'),
  exportModal:$('#exportModal'), exportScope:$('#exportScope'), exportQuality:$('#exportQuality'), exportNormalize:$('#exportNormalize'), exportFade:$('#exportFade'), exportProgress:$('#exportProgress'), exportProgressBar:$('#exportProgressBar'), exportProgressText:$('#exportProgressText'), loopCheckResult:$('#loopCheckResult'),
  bankModal:$('#bankModal'), bankStatus:$('#sampleStatus'), bankPackList:$('#bankPackList'), bankStats:$('#bankStats')
};

async function init(){
  for (let i=0;i<12;i++){ els.key.add(new Option(keyNames[i]+' majeur',i)); els.chordRoot.add(new Option(keyNames[i],i)); }
  Object.keys(PRESETS).forEach(n=>els.instrument.add(new Option(n,n)));
  const __ltcNativeCapacitor = !!(window.Capacitor && typeof window.Capacitor.isNativePlatform==='function' && window.Capacitor.isNativePlatform());
  document.documentElement.classList.toggle('ltc-native',__ltcNativeCapacitor);
  if (__ltcNativeCapacitor) {
    // Hotfix 0.8.13: un ancien Service Worker ne doit jamais servir une UI obsolète dans l'APK natif.
    if ('serviceWorker' in navigator) navigator.serviceWorker.getRegistrations?.().then(rs=>Promise.all(rs.map(r=>r.unregister()))).catch(()=>{});
    if (window.caches?.keys) caches.keys().then(keys=>Promise.all(keys.filter(k=>String(k).startsWith('ltc-music-studio-')).map(k=>caches.delete(k)))).catch(()=>{});
  } else if ('serviceWorker' in navigator) navigator.serviceWorker.register('./sw.js').catch(()=>{});
  bindUI();
  const mm=$('#mobileMemoryToggle');if(mm)mm.checked=perfPrefs.mobileMemory;
  if(window.LTCCustomSamples){await window.LTCCustomSamples.init();await syncCustomPresets();window.addEventListener('ltc-custom-samples-changed',syncCustomPresets);window.addEventListener('ltc-add-custom-sample',e=>addCustomSampleToProject(e.detail?.sample));}
  restoreAutosave();
  renderAll();
  renderVirtualPiano();
  renderBank();
  initV055UX();
  initArrangementV061();
  initLtcModeV082();
  Promise.allSettled([window.LTCSampleEngine?.loadManifest('classical-guitar-hq'),window.LTCSampleEngine?.loadManifest('nylon-guitar-hq'),window.LTCSampleEngine?.loadManifest('dry-piano-hq'),window.LTCSampleEngine?.loadManifest('felt-piano-hq'),window.LTCSampleEngine?.loadManifest('rhodes-hq'),window.LTCSampleEngine?.loadManifest('marimba-hq'),window.LTCSampleEngine?.loadManifest('kalimba-hq'),window.LTCSampleEngine?.loadManifest('mandolin-hq'),window.LTCSampleEngine?.loadManifest('pizzicato-hq'),window.LTCSampleEngine?.loadManifest('harp-hq'),window.LTCSampleEngine?.loadManifest('hand-drum-hq'),window.LTCSampleEngine?.loadManifest('wood-perc-hq'),window.LTCSampleEngine?.loadManifest('shaker-hq'),window.LTCSampleEngine?.loadManifest('triangle-hq'),window.LTCSampleEngine?.loadManifest('round-bass-hq'),window.LTCSampleEngine?.loadManifest('diagnostic-pluck')]).then(()=>renderBank());
  setInterval(autosave,6000);
}

function barsToSecondsV0811(bars,bpm=state.bpm){return Math.max(1,+bars||1)*4*60/Math.max(1,+bpm||76);}
function inferredBarsV0811(duration=state.duration,bpm=state.bpm){return clamp(Math.max(1,Math.round((+duration||0)*(+bpm||76)/240)||10),1,512);}
function updateDurationUiV0811(){if(els.durationBars)els.durationBars.textContent=state.bars+' mesure'+(state.bars>1?'s':'');if(els.durationSeconds){const s=state.duration;els.durationSeconds.textContent=(s<60?s.toFixed(1):s.toFixed(0))+' s';}}
function normalizeDurationDependentsV0811(){normalizeAllVolumeAutomationV070();normalizeAllEffectAutomationV071();normalizeRhythmAutomationV072();normalizeTempoAutomationV073();invalidateTempoMapV073();}
function setBarsV0811(nextBars,history=true){const apply=()=>{state.bars=clamp(Math.round(+nextBars||1),1,512);state.duration=barsToSecondsV0811(state.bars);};if(history)mutate(apply);else apply();normalizeDurationDependentsV0811();updateDurationUiV0811();renderRoll();renderVolumeAutomationV070();renderEffectAutomationV071();renderRhythmAutomationV072();renderTempoAutomationV073();}
function setBpmPreserveBarsV0811(next){const oldDuration=state.duration;mutate(()=>{state.bpm=next;state.bars=state.bars||inferredBarsV0811(oldDuration,next);state.duration=barsToSecondsV0811(state.bars,next);const a=ensureTempoAutomationV073();if(!a.enabled)a.points=[{sec:0,bpm:next},{sec:state.duration,bpm:next}];});normalizeDurationDependentsV0811();updateDurationUiV0811();renderTempoAutomationV073();renderRoll();}

function bindUI(){
  els.bpm.onchange = () => { const next=clamp(+els.bpm.value||76,40,160); setBpmPreserveBarsV0811(next); };
  els.key.onchange = () => { state.key=+els.key.value; markDirty(); renderRoll(); };
  els.durationMinus.onclick=()=>setBarsV0811(state.bars-1); els.durationPlus.onclick=()=>setBarsV0811(state.bars+1);
  els.grid.onchange = () => {state.grid=+els.grid.value;markDirty();};
  els.zoom.oninput = () => { state.zoom=+els.zoom.value; renderRoll(); };
  bindTrackAddButtonsV08121();
  $('#closeNewTrackBtn').onclick=closeNewTrackModalV0812; $('#cancelNewTrackBtn').onclick=closeNewTrackModalV0812; $('#newTrackForm').onsubmit=createTrackFromModalV0812;
  $('#newTrackName').oninput=updateNewTrackPreviewV0812; $('#newTrackInstrument').onchange=updateNewTrackPreviewV0812; $('#newTrackColor').oninput=()=>{syncNewTrackSwatchesV0812();updateNewTrackPreviewV0812();};
  $('#newTrackModal').addEventListener('click',e=>{if(e.target.id==='newTrackModal')closeNewTrackModalV0812();});
  $('#clearBtn').onclick=()=>{ if(confirm('Effacer toutes les notes et le pattern rythmique ?')){ mutate(()=>{state.tracks.forEach(t=>t.notes=[]); Object.values(state.drums).forEach(s=>s.clear());}); renderAll(); }};
  els.play.onclick=play;
  els.stop.onclick=stop;
  els.loop.onclick=()=>{state.loop=!state.loop; els.loop.classList.toggle('active',state.loop)};
  $('#undoBtn').onclick=()=>{undo();updateV055HistoryUI();updateV055TrackHealth();}; $('#redoBtn').onclick=()=>{redo();updateV055HistoryUI();updateV055TrackHealth();};
  els.humanize.onclick=()=>{ state.humanize=state.humanize===.25?.4:state.humanize===.4?.1:.25;markDirty(); els.humanize.textContent='Humaniser '+Math.round(state.humanize*100)+'%'; };
  $('#motifBtn').onclick=openMotifGenerator; $('#closeMotifBtn').onclick=closeMotifGenerator; $('#generateMotifBtn').onclick=generateMotifCandidate; $('#previewMotifBtn').onclick=previewMotifCandidate; $('#insertMotifBtn').onclick=insertMotifCandidate; $('#sourceFromTrackBtn').onclick=captureMotifSourceFromTrack; $('#sourceFromCandidateBtn').onclick=useCandidateAsVariationSource; $('#variationPrimeBtn').onclick=()=>generateMotifVariation('prime'); $('#variationDoublePrimeBtn').onclick=()=>generateMotifVariation('double'); $('#continueMotifBtn').onclick=()=>generateMotifContinuation('continue'); $('#responseMotifBtn').onclick=()=>generateMotifContinuation('response'); $('#calmMotifBtn').onclick=()=>generateMotifTransform('calm'); $('#densifyMotifBtn').onclick=()=>generateMotifTransform('densify'); $('#simplifyMotifBtn').onclick=()=>generateMotifTransform('simplify'); $('#linkMotifBtn').onclick=()=>generateMotifNaturalize('link'); $('#extendMotifBtn').onclick=()=>generateMotifNaturalize('extend'); $('#smartHumanizeBtn').onclick=()=>generateMotifNaturalize('humanize');
  $('#saveBtn').onclick=saveToLibrary; $('#newBtn').onclick=newComposition; $('#libraryBtn').onclick=openLibrary;
  $('#closeLibraryBtn').onclick=closeLibrary; $('#libraryNewBtn').onclick=()=>{closeLibrary();newComposition();}; $('#librarySaveCopyBtn').onclick=saveCopyToLibrary;
  els.librarySearch.oninput=renderLibrary; els.libraryFilter.onchange=renderLibrary;
  $('#quickHelpBtn').onclick=()=>$('#helpModal').classList.remove('hidden'); $('#closeHelpBtn').onclick=()=>$('#helpModal').classList.add('hidden');
  $('#bankBtn').onclick=openBank; $('#bankInspectorBtn').onclick=openBank; $('#closeBankBtn').onclick=closeBank; $('#preloadGuitarBtn').onclick=preloadGuitarPack; $('#preloadNylonBtn').onclick=preloadNylonPack; $('#preloadDryPianoBtn').onclick=preloadDryPianoPack; $('#preloadFeltPianoBtn').onclick=preloadFeltPianoPack; $('#preloadRhodesBtn').onclick=preloadRhodesPack; $('#preloadMarimbaBtn').onclick=preloadMarimbaPack; $('#preloadKalimbaBtn').onclick=preloadKalimbaPack; $('#preloadMandolinBtn').onclick=preloadMandolinPack; $('#preloadPizzicatoBtn').onclick=preloadPizzicatoPack; $('#preloadHarpBtn').onclick=preloadHarpPack; $('#preloadHandDrumBtn').onclick=preloadHandDrumPack; $('#preloadWoodPercBtn').onclick=preloadWoodPercPack; $('#preloadShakerBtn').onclick=preloadShakerPack; $('#preloadTriangleBtn').onclick=preloadTrianglePack; $('#preloadBassBtn').onclick=preloadBassPack; $('#preloadDiagnosticBtn').onclick=preloadDiagnosticPack; $('#clearSampleCacheBtn').onclick=()=>{window.LTCSampleEngine?.clearCache();renderBank();renderInspector();toast('Cache multisample vidé');}; const mm=$('#mobileMemoryToggle');if(mm)mm.onchange=()=>{perfPrefs.mobileMemory=mm.checked;savePerfPrefs();renderBank();toast(mm.checked?'Mémoire mobile automatique activée':'Mémoire mobile automatique désactivée');}; const om=$('#optimizeMemoryBtn');if(om)om.onclick=optimizeMemoryNow; const cd=$('#clearDownloadedSamplesBtn');if(cd)cd.onclick=clearDownloadedSamples;
  els.projectName.oninput=()=>{state.projectName=els.projectName.value||'Sans titre';markDirty();}; els.projectTag.onchange=()=>{state.projectTag=els.projectTag.value;markDirty();};
  els.pianoOctave.onchange=renderVirtualPiano;
  $('#exportProjectBtn').onclick=exportProject; $('#importProjectBtn').onclick=()=>els.fileInput.click(); els.fileInput.onchange=importProject;
  $('#exportAudioBtn').onclick=openExport; $('#closeExportBtn').onclick=closeExport; $('#cancelExportBtn').onclick=closeExport;
  $('#exportConfirmBtn').onclick=runSelectedExportV08155; $('#loopCheckBtn').onclick=checkLoopSeam;
  els.exportScope.onchange=syncExportUiV08155; $$('input[name="exportFormat"]').forEach(r=>r.onchange=syncExportUiV08155);
  $('#duplicateNoteBtn').onclick=duplicateSelectedNote; $('#deleteNoteBtn').onclick=deleteSelectedNote;
  els.instrument.onchange=()=>updateTrackProp('instrument',els.instrument.value,true);
  ['volume','pan','attack','release','reverb','filter'].forEach(k=>els[k].oninput=()=>updateTrackProp(k,+els[k].value,false));
  $('#addChordBtn').onclick=()=>{ mutate(()=>state.chords.push({id:uid(),beat:0,root:+els.chordRoot.value,type:els.chordType.value})); renderChords(); };
  $('#previewChordBtn').onclick=previewChordV0810; $('#insertChordBtn').onclick=insertChordV0810; const rvm=$('#rollViewModeSelect');if(rvm){rvm.value=uxPrefsV0810.rollMode;rvm.onchange=()=>{uxPrefsV0810.rollMode=rvm.value;saveUxPrefsV0810();renderRoll();};}
  $('#measureSelectModeBtn').onclick=toggleMeasureSelectionModeV08157; $('#measureCopyBtn').onclick=copySelectedMeasuresV08157; $('#measurePasteBtn').onclick=pasteMeasuresAfterContentV08157; $('#measureDuplicateBtn').onclick=duplicateSelectedMeasuresV08157;
  $$('.mode').forEach(b=>b.onclick=()=>switchMode(b.dataset.mode));
  $$('.mobile-tabs button').forEach(b=>b.onclick=()=>switchMobile(b.dataset.mobile,b));
  window.addEventListener('resize',scheduleResponsiveRender);
  window.visualViewport?.addEventListener('resize',scheduleResponsiveRender);
  document.addEventListener('visibilitychange',()=>{if(document.hidden&&!state.playing&&state.audioCtx?.state==='running')state.audioCtx.suspend().catch(()=>{});});
  bindRollPointer();
  els.rollScroller.addEventListener('scroll',()=>{ els.keyboard.scrollTop=els.rollScroller.scrollTop; });
  bindVolumeAutomationV070();
  bindEffectAutomationV071();
  bindRhythmAutomationV072();
  bindTempoAutomationV073();
  bindAutomationHubV075();
  bindAutomationGroupsV077();
  bindAutomationPrecisionV077();
  bindAutomationStabilityV0710();
  window.addEventListener('beforeunload',autosave);
}

function snapshot(){
  return JSON.stringify({version:'0.8.15.8',projectId:state.projectId,projectName:state.projectName,projectTag:state.projectTag,bpm:state.bpm,key:state.key,bars:state.bars,duration:state.duration,grid:state.grid,zoom:state.zoom,tracks:state.tracks,chords:state.chords,arrangements:state.arrangements||{},rhythmIntensityAutomation:state.rhythmIntensityAutomation,rhythmDensityAutomation:state.rhythmDensityAutomation,tempoAutomation:state.tempoAutomation,automationGroups:state.automationGroups||[],masterBusAutomation:state.masterBusAutomation,automationEditor:state.automationEditor,automationSafety:state.automationSafety,ltcMode:state.ltcMode,drums:Object.fromEntries(Object.entries(state.drums).map(([k,v])=>[k,[...v]]))});
}
function restore(s){
  const p=typeof s==='string'?JSON.parse(s):s;
  state.projectId=p.projectId||null; state.projectName=p.projectName||'Nouvelle composition'; state.projectTag=p.projectTag||'Autre';
  state.bpm=p.bpm||76; state.key=p.key||0; state.bars=clamp(Math.round(+p.bars||inferredBarsV0811(p.duration||90,state.bpm)),1,512); state.duration=barsToSecondsV0811(state.bars,state.bpm); state.grid=p.grid||.5; state.zoom=p.zoom||58;
  state.tracks=(p.tracks||[]).map(t=>({...t,id:t.id||uid(),solo:!!t.solo,ltcLayer:normalizeLtcLayerV082(t.ltcLayer),notes:(t.notes||[]).map(n=>({...n,id:n.id||uid()}))}));
  state.tracks.forEach(t=>ensureCustomPlaceholder(t.instrument)); normalizeAllVolumeAutomationV070(); normalizeAllEffectAutomationV071();
  state.selectedTrackId=state.tracks[0]?.id||null; state.selectedNoteId=null; measureEditV08157.active=false;measureEditV08157.startBar=null;measureEditV08157.endBar=null;measureEditV08157.dragging=false;measureEditV08157.pointerId=null;measureEditV08157.clipboard=null; state.chords=p.chords||[]; state.arrangements=p.arrangements||{};
  state.rhythmIntensityAutomation=p.rhythmIntensityAutomation||{enabled:false,curve:'soft',points:[{sec:0,value:1},{sec:state.duration,value:1}]};
  state.rhythmDensityAutomation=p.rhythmDensityAutomation||{enabled:false,curve:'soft',points:[{sec:0,value:1},{sec:state.duration,value:1}]};
  state.tempoAutomation=p.tempoAutomation||{enabled:false,curve:'soft',points:[{sec:0,bpm:state.bpm},{sec:state.duration,bpm:state.bpm}]};
  state.automationGroups=Array.isArray(p.automationGroups)?p.automationGroups:[];
  state.masterBusAutomation=p.masterBusAutomation||{volumeAutomation:{enabled:false,curve:'soft',points:[{sec:0,value:1},{sec:state.duration,value:1}]},filterAutomation:{enabled:false,curve:'soft',points:[{sec:0,value:1},{sec:state.duration,value:1}]},reverbAutomation:{enabled:false,curve:'soft',points:[{sec:0,value:0},{sec:state.duration,value:0}]}};
  state.automationEditor=p.automationEditor||{zoom:1,snap:1};
  state.automationSafety=(p.automationSafety&&typeof p.automationSafety==='object')?p.automationSafety:{enabled:true,smoothingMs:150};
  state.automationSafety.enabled=state.automationSafety.enabled!==false;state.automationSafety.smoothingMs=[80,150,300].includes(+state.automationSafety.smoothingMs)?+state.automationSafety.smoothingMs:150;
  state.ltcMode=normalizeLtcModeV082(p.ltcMode);
  normalizeAutomationGroupsV077(); normalizeRhythmAutomationV072(); normalizeTempoAutomationV073(); invalidateTempoMapV073();
  state.drums=Object.fromEntries(Object.entries(p.drums||{}).map(([k,v])=>[k,new Set(v)]));
  const drumMigration=[['Hand drum','🥁 Hand drum HQ'],['Percussion bois','🪵 Percussion bois HQ'],['Shaker doux','✨ Shaker doux HQ']];
  drumMigration.forEach(([oldName,newName])=>{if(state.drums[oldName]&&!state.drums[newName])state.drums[newName]=state.drums[oldName];delete state.drums[oldName];});
  ['🥁 Hand drum HQ','🪵 Percussion bois HQ','✨ Shaker doux HQ','🔺 Triangle doux HQ'].forEach(k=>state.drums[k]||(state.drums[k]=new Set()));
  els.bpm.value=state.bpm; els.key.value=state.key; updateDurationUiV0811(); els.grid.value=state.grid; els.zoom.value=state.zoom; els.projectName.value=state.projectName; els.projectTag.value=state.projectTag; state.dirty=false; updateAutosaveStatus('Chargé'); renderAll();
}
function mutate(fn){ state.history.push(snapshot()); if(state.history.length>60) state.history.shift(); state.future=[]; fn(); markDirty(); }
function undo(){ if(!state.history.length)return; state.future.push(snapshot()); restore(state.history.pop()); }
function redo(){ if(!state.future.length)return; state.history.push(snapshot()); restore(state.future.pop()); }

function currentTrack(){ return state.tracks.find(t=>t.id===state.selectedTrackId); }
function currentNote(){ const t=currentTrack(); return t?.notes.find(n=>n.id===state.selectedNoteId); }
function updateTrackProp(k,v,rerender){ const t=currentTrack(); if(!t)return; t[k]=v; markDirty(); if(k==='instrument'){const p=PRESETS[v]; t.attack=p.attack;t.release=p.release;t.filter=p.filter;} if(rerender)renderAll(); else {renderTracks();renderMixer();if(k==='filter'||k==='reverb')renderEffectAutomationV071();} }

function populateNewTrackInstrumentV0812(){
  const sel=$('#newTrackInstrument');if(!sel)return;const previous=sel.value;sel.innerHTML='';
  Object.keys(PRESETS).filter(n=>!PRESETS[n]?.percussion&&!PRESETS[n]?.diagnostic).forEach(n=>sel.add(new Option(PRESETS[n]?.custom?'🎙 '+(PRESETS[n].customName||n):n,n)));
  const preferred=previous&&PRESETS[previous]&&!PRESETS[previous].percussion?previous:'🎹 Piano feutré HQ';
  if([...sel.options].some(o=>o.value===preferred))sel.value=preferred;
}
function syncNewTrackSwatchesV0812(){const value=($('#newTrackColor')?.value||'').toLowerCase();$$('#newTrackColorSwatches .new-track-swatch-btn').forEach(b=>b.classList.toggle('active',b.dataset.color.toLowerCase()===value));}
function updateNewTrackPreviewV0812(){const name=($('#newTrackName')?.value||'').trim()||'Nouvelle piste',inst=$('#newTrackInstrument')?.value||'🎹 Piano feutré HQ',color=$('#newTrackColor')?.value||COLORS[0];const ps=$('#newTrackPreviewSwatch'),pn=$('#newTrackPreviewName'),pi=$('#newTrackPreviewInstrument');if(ps)ps.style.background=color;if(pn)pn.textContent=name;if(pi)pi.textContent=inst;}
function ensureNewTrackSwatchesV0812(){const box=$('#newTrackColorSwatches');if(!box||box.childElementCount)return;COLORS.forEach(color=>{const b=document.createElement('button');b.type='button';b.className='new-track-swatch-btn';b.dataset.color=color;b.style.setProperty('--swatch',color);b.title=color;b.onclick=()=>{$('#newTrackColor').value=color;syncNewTrackSwatchesV0812();updateNewTrackPreviewV0812();};box.appendChild(b);});}
function bindTrackAddButtonV08121(btn){
  if(!btn||btn.dataset.trackAddBound==='1')return;
  btn.dataset.trackAddBound='1';
  btn.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();openNewTrackModalV0812();},false);
}
function bindTrackAddButtonsV08121(){bindTrackAddButtonV08121($('#addTrackBtn'));bindTrackAddButtonV08121($('#addTrackListBtn'));}

function openNewTrackModalV0812(){
  if(state.tracks.length>=12)return toast('Maximum 12 pistes en V0.8.15.8');
  populateNewTrackInstrumentV0812();ensureNewTrackSwatchesV0812();const i=state.tracks.length,n=$('#newTrackName'),c=$('#newTrackColor');if(n)n.value='Piste '+(i+1);if(c)c.value=COLORS[i%COLORS.length];syncNewTrackSwatchesV0812();updateNewTrackPreviewV0812();
  $('#newTrackModal')?.classList.remove('hidden');setTimeout(()=>{n?.focus();n?.select();},40);
}
function closeNewTrackModalV0812(){$('#newTrackModal')?.classList.add('hidden');}
function scrollSelectedTrackIntoViewV0812(){requestAnimationFrame(()=>{const node=els.tracks?.querySelector(`[data-track-id="${state.selectedTrackId}"]`);node?.scrollIntoView({block:'nearest',behavior:'smooth'});});}
function createTrackFromModalV0812(e){
  e?.preventDefault();if(state.tracks.length>=12){closeNewTrackModalV0812();return toast('Maximum 12 pistes en V0.8.15.8');}
  const name=($('#newTrackName')?.value||'').trim();if(!name){$('#newTrackName')?.focus();return toast('Donne un nom à la piste');}
  const instrument=$('#newTrackInstrument')?.value||'🎹 Piano feutré HQ';if(!PRESETS[instrument])return toast('Instrument indisponible');const color=$('#newTrackColor')?.value||COLORS[state.tracks.length%COLORS.length];
  let created=null;mutate(()=>{const t=mkTrack(name,instrument,state.tracks.length);t.color=color;state.tracks.push(t);state.selectedTrackId=t.id;state.selectedNoteId=null;created=t;});
  closeNewTrackModalV0812();renderAll();scrollSelectedTrackIntoViewV0812();toast(`Piste « ${created.name} » créée`);
}

function renderAll(){ updateDurationUiV0811(); renderTracks(); renderKeyboard(); renderRoll(); renderMeasureCopyUiV08157(); renderInspector(); renderDrums(); renderMixer(); renderChords(); renderVirtualPiano(); renderArrangementV061(); renderVolumeAutomationV070(); renderEffectAutomationV071(); renderRhythmAutomationV072(); renderTempoAutomationV073(); renderAutomationHubV075(); renderAutomationGroupsV077(); renderAutomationPrecisionV077(); renderAutomationStabilityV0710(); renderLtcModeV082(); updateV055HistoryUI(); updateV055TrackHealth(); }
function renderTracks(){
  els.tracks.innerHTML='';
  state.tracks.forEach((t,i)=>{
    const d=document.createElement('div'); d.className='track'+(t.id===state.selectedTrackId?' active':'');
    d.dataset.trackId=t.id;
    d.style.setProperty('--track-color',t.color);
    d.innerHTML=`<span class="swatch" style="background:${t.color}"></span><div class="track-name"><strong>${esc(t.name)}</strong><small>${esc(t.instrument)}</small></div><div class="track-quick"><button class="mute ${t.mute?'active':''}" title="Muet">M</button><button class="solo ${t.solo?'active':''}" title="Solo">S</button></div>`;
    d.onclick=e=>{
      const b=e.target.closest?.('button');
      if(b){e.stopPropagation();if(b.classList.contains('mute'))t.mute=!t.mute;else if(b.classList.contains('solo'))t.solo=!t.solo;markDirty();renderAll();return;}
      state.selectedTrackId=t.id;state.selectedNoteId=null;renderAll();
    };
    d.querySelector('strong').ondblclick=e=>{e.stopPropagation(); const n=prompt('Nom de la piste',t.name); if(n){t.name=n;markDirty();renderTracks();renderMixer();}};
    els.tracks.appendChild(d);
  });
}
function renderInspector(){
  const t=currentTrack(); if(!t)return;
  els.instrument.value=t.instrument; els.volume.value=t.volume; els.pan.value=t.pan; els.attack.value=t.attack; els.release.value=t.release; els.reverb.value=t.reverb; els.filter.value=t.filter;
  renderSampleStatus(t);
  const n=currentNote(); if(n) els.velocity.value=n.velocity;
  els.velocity.oninput=()=>{const n=currentNote();if(n){n.velocity=+els.velocity.value;markDirty();renderRoll();}};
}
function renderKeyboard(){
  els.keyboard.innerHTML='';
  for(let midi=83;midi>=48;midi--){ const d=document.createElement('div'); d.className='key'+([1,3,6,8,10].includes(midi%12)?' black':''); d.textContent=NOTE_NAMES[midi%12]+(Math.floor(midi/12)-1); els.keyboard.appendChild(d); }
}

function beatWidth(){return state.zoom;}
function totalBeats(){return state.duration*state.bpm/60;}
function renderRoll(){
  const c=els.roll, ctx=c.getContext('2d'); const bw=beatWidth(); const w=Math.max(els.rollScroller.clientWidth,totalBeats()*bw); const h=36*28;
  c.width=Math.ceil(w*devicePixelRatio); c.height=Math.ceil(h*devicePixelRatio); c.style.width=w+'px';c.style.height=h+'px';ctx.scale(devicePixelRatio,devicePixelRatio);
  ctx.fillStyle='#10141a';ctx.fillRect(0,0,w,h);
  const keyRoot=state.key; for(let r=0;r<36;r++){const midi=83-r; const inScale=SCALE_MAJOR.includes((midi-keyRoot+120)%12);ctx.fillStyle=inScale?'#141b20':'#101419';ctx.fillRect(0,r*28,w,28);ctx.strokeStyle='#252c35';ctx.beginPath();ctx.moveTo(0,(r+1)*28+.5);ctx.lineTo(w,(r+1)*28+.5);ctx.stroke();}
  if(measureEditV08157.startBar!=null&&measureEditV08157.endBar!=null){const lo=Math.min(measureEditV08157.startBar,measureEditV08157.endBar),hi=Math.max(measureEditV08157.startBar,measureEditV08157.endBar),x=lo*4*bw,ww=(hi-lo+1)*4*bw;ctx.fillStyle=measureEditV08157.active?'rgba(126,231,135,.13)':'rgba(86,182,194,.10)';ctx.fillRect(x,0,ww,h);ctx.fillStyle=measureEditV08157.active?'rgba(126,231,135,.24)':'rgba(86,182,194,.18)';ctx.fillRect(x,0,ww,18);}
  for(let b=0;b<=Math.ceil(totalBeats());b++){const x=b*bw+.5;ctx.strokeStyle=b%4===0?'#46505f':'#29313b';ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,h);ctx.stroke(); if(b%4===0){ctx.fillStyle='#778395';ctx.font='10px sans-serif';ctx.fillText(String(Math.floor(b/4)+1),x+4,11);}}
  const selected=currentTrack(),mode=uxPrefsV0810.rollMode;
  const others=state.tracks.filter(t=>t.id!==state.selectedTrackId);
  if(mode!=='current'){
    for(const t of others){const alpha=mode==='ghosts'?.17:(t.mute?.22:.72);for(const n of t.notes)drawNote(ctx,n,t,w,alpha,false);}
  }
  if(selected){for(const n of selected.notes)drawNote(ctx,n,selected,w,selected.mute?.42:.96,true);}
  if(state.playing){ const x=currentPlayBeat()*bw;ctx.strokeStyle='#7ee787';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,h);ctx.stroke(); }
}
function drawNote(ctx,n,t,w,alpha=.92,editable=true){ const bw=beatWidth(); const x=n.beat*bw; const y=(83-n.midi)*28+3; const ww=Math.max(8,n.dur*bw-3); const hh=22; ctx.fillStyle=(editable&&n.id===state.selectedNoteId)?'#ffffff':t.color;ctx.globalAlpha=alpha;roundRect(ctx,x+1,y,ww,hh,5,true);ctx.globalAlpha=1;if(editable){ctx.fillStyle='#0d1215';ctx.fillRect(x+ww-5,y+3,3,hh-6);} }
function roundRect(ctx,x,y,w,h,r,fill){ctx.beginPath();ctx.roundRect(x,y,w,h,r);if(fill)ctx.fill();}

function selectedMeasureRangeV08157(){
  if(measureEditV08157.startBar==null||measureEditV08157.endBar==null)return null;
  const startBar=Math.min(measureEditV08157.startBar,measureEditV08157.endBar),endBar=Math.max(measureEditV08157.startBar,measureEditV08157.endBar);
  return {startBar,endBar,startBeat:startBar*4,endBeat:(endBar+1)*4,bars:endBar-startBar+1};
}
function renderMeasureCopyUiV08157(){
  const mode=$('#measureSelectModeBtn'),label=$('#measureSelectionLabel'),copy=$('#measureCopyBtn'),paste=$('#measurePasteBtn'),dup=$('#measureDuplicateBtn'),range=selectedMeasureRangeV08157(),t=currentTrack(),clip=measureEditV08157.clipboard;
  mode?.classList.toggle('active',measureEditV08157.active);
  if(mode)mode.textContent=measureEditV08157.active?'✓ SÉLECTION MESURES':'▦ SÉL. MESURES';
  if(label){label.classList.toggle('ready',!!range);label.textContent=range?`Mesure${range.bars>1?'s':''} ${range.startBar+1}${range.endBar!==range.startBar?` → ${range.endBar+1}`:''} • ${t?.name||'—'}`:'Aucune mesure sélectionnée';}
  if(copy)copy.disabled=!range||!t;
  if(dup)dup.disabled=!range||!t;
  if(paste){paste.disabled=!clip||!t||clip.trackId!==t.id;paste.title=clip&&t&&clip.trackId!==t.id?`Bloc copié depuis « ${clip.trackName} »`:(clip?`${clip.bars} mesure${clip.bars>1?'s':''} copiée${clip.bars>1?'s':''}`:'Aucun bloc copié');}
}
function toggleMeasureSelectionModeV08157(){
  measureEditV08157.active=!measureEditV08157.active;measureEditV08157.dragging=false;measureEditV08157.pointerId=null;state.selectedNoteId=null;renderMeasureCopyUiV08157();renderRoll();
  toast(measureEditV08157.active?'Glisse horizontalement sur le piano-roll pour sélectionner les mesures':'Sélection de mesures terminée');
}
function measureBarAtX_V08157(x){return clamp(Math.floor(Math.max(0,x)/(beatWidth()*4)),0,Math.max(0,state.bars-1));}
function copySelectedMeasuresV08157(showToast=true){
  const t=currentTrack(),range=selectedMeasureRangeV08157();if(!t||!range)return false;
  const notes=t.notes.filter(n=>n.beat>=range.startBeat-1e-7&&n.beat<range.endBeat-1e-7).map(n=>{const q={...n};delete q.id;q.beat=n.beat-range.startBeat;return q;});
  if(!notes.length){if(showToast)toast('Aucune note de cette piste dans les mesures sélectionnées');return false;}
  measureEditV08157.clipboard={trackId:t.id,trackName:t.name,bars:range.bars,notes,sourceStartBar:range.startBar,sourceEndBar:range.endBar};
  renderMeasureCopyUiV08157();if(showToast)toast(`${range.bars} mesure${range.bars>1?'s':''} copiée${range.bars>1?'s':''} • ${notes.length} note${notes.length>1?'s':''}`);return true;
}
function pasteMeasuresAfterContentV08157(showToast=true){
  const t=currentTrack(),clip=measureEditV08157.clipboard;if(!t||!clip)return false;
  if(clip.trackId!==t.id){if(showToast)toast(`Reviens sur la piste « ${clip.trackName} » pour coller ce bloc`);return false;}
  const lastEnd=t.notes.length?Math.max(...t.notes.map(n=>Number(n.beat||0)+Math.max(0,Number(n.dur||0)))):0;
  const destBeat=lastEnd<=1e-7?0:Math.ceil((lastEnd-1e-7)/4)*4;
  const pasted=clip.notes.map(n=>({...n,id:uid(),beat:destBeat+n.beat}));
  mutate(()=>{t.notes.push(...pasted);t.notes.sort((a,b)=>a.beat-b.beat||a.midi-b.midi);const neededBars=Math.ceil((destBeat+clip.bars*4)/4);if(neededBars>state.bars){state.bars=clamp(neededBars,1,512);state.duration=barsToSecondsV0811(state.bars);}});
  normalizeDurationDependentsV0811();updateDurationUiV0811();state.selectedNoteId=pasted[0]?.id||null;renderAll();
  const firstBar=Math.floor(destBeat/4)+1,lastBar=firstBar+clip.bars-1;if(showToast)toast(`Collé à la suite • mesure${clip.bars>1?'s':''} ${firstBar}${lastBar!==firstBar?` → ${lastBar}`:''}`);return true;
}
function duplicateSelectedMeasuresV08157(){if(copySelectedMeasuresV08157(false)){pasteMeasuresAfterContentV08157(false);const r=selectedMeasureRangeV08157();if(r)toast(`${r.bars} mesure${r.bars>1?'s':''} dupliquée${r.bars>1?'s':''} à la suite`);}}
function clearMeasureSelectionV08157(){measureEditV08157.startBar=null;measureEditV08157.endBar=null;measureEditV08157.dragging=false;measureEditV08157.pointerId=null;renderMeasureCopyUiV08157();renderRoll();}

let gesture=null;
let touchRollEditV089=null;
let uxNavGestureV089={active:false,suppressUntil:0,pointers:new Set()};
function uxNavBlockedV089(){return uxNavGestureV089.active||performance.now()<uxNavGestureV089.suppressUntil;}
function cancelRollTouchEditV089(restore=true){
  const p=touchRollEditV089;if(!p)return;
  clearTimeout(p.longTimer);
  if(restore&&p.type==='hit'&&p.editStarted){const t=state.tracks.find(x=>x.id===p.trackId),n=t?.notes.find(x=>x.id===p.noteId);if(n){n.beat=p.origBeat;n.dur=p.origDur;n.midi=p.origMidi;}}
  touchRollEditV089=null;renderRoll();renderInspector();
}
function bindRollPointer(){
  const c=els.roll;
  c.addEventListener('pointerdown',e=>{
    const pt=canvasPoint(e),t=currentTrack();if(!t)return;
    if(measureEditV08157.active){if(e.pointerType==='touch'&&uxNavBlockedV089()){measureEditV08157.dragging=false;measureEditV08157.pointerId=null;e.preventDefault();return;}const bar=measureBarAtX_V08157(pt.x);measureEditV08157.startBar=bar;measureEditV08157.endBar=bar;measureEditV08157.anchorBar=bar;measureEditV08157.dragging=true;measureEditV08157.pointerId=e.pointerId;state.selectedNoteId=null;c.setPointerCapture?.(e.pointerId);renderMeasureCopyUiV08157();renderRoll();e.preventDefault();return;}
    const hit=hitNote(pt.x,pt.y);
    if(e.pointerType==='touch'){
      if(uxNavBlockedV089()){e.preventDefault();return;}
      c.setPointerCapture?.(e.pointerId);
      const base={pid:e.pointerId,trackId:t.id,startX:pt.x,startY:pt.y,moved:false,editStarted:false,longTimer:null,before:null};
      if(hit){
        state.selectedNoteId=hit.id;
        const right=hit.beat*beatWidth()+hit.dur*beatWidth();
        touchRollEditV089={...base,type:'hit',noteId:hit.id,resize:Math.abs(pt.x-right)<14,origBeat:hit.beat,origDur:hit.dur,origMidi:hit.midi,before:snapshot()};
        touchRollEditV089.longTimer=setTimeout(()=>{const p=touchRollEditV089;if(!p||p.pid!==e.pointerId||p.moved||uxNavBlockedV089())return;mutate(()=>{const tt=state.tracks.find(x=>x.id===p.trackId);if(tt)tt.notes=tt.notes.filter(n=>n.id!==p.noteId);});state.selectedNoteId=null;touchRollEditV089=null;renderRoll();renderInspector();toast('Note supprimée');},650);
        renderInspector();renderRoll();
      }else{
        touchRollEditV089={...base,type:'create',beat:snap(pt.x/beatWidth()),midi:clamp(83-Math.floor(pt.y/28),48,83)};
      }
      e.preventDefault();return;
    }
    c.setPointerCapture(e.pointerId);
    if(hit){ state.selectedNoteId=hit.id; const right=hit.beat*beatWidth()+hit.dur*beatWidth(); gesture={type:Math.abs(pt.x-right)<14?'resize':'move',id:hit.id,startX:pt.x,startY:pt.y,origBeat:hit.beat,origDur:hit.dur,origMidi:hit.midi,moved:false,longTimer:setTimeout(()=>{if(!gesture?.moved){mutate(()=>t.notes=t.notes.filter(n=>n.id!==hit.id));state.selectedNoteId=null;gesture=null;renderRoll();renderInspector();toast('Note supprimée');}},650)}; renderInspector();renderRoll();
    } else { const beat=snap(pt.x/beatWidth()); const midi=clamp(83-Math.floor(pt.y/28),48,83); mutate(()=>{const n={id:uid(),beat,dur:Math.max(state.grid,1),midi,velocity:+els.velocity.value||.72};t.notes.push(n);state.selectedNoteId=n.id;}); renderRoll();renderInspector(); }
  });
  c.addEventListener('pointermove',e=>{
    if(measureEditV08157.active&&measureEditV08157.dragging&&measureEditV08157.pointerId===e.pointerId){const pt=canvasPoint(e),bar=measureBarAtX_V08157(pt.x);if(bar!==measureEditV08157.endBar){measureEditV08157.endBar=bar;renderMeasureCopyUiV08157();renderRoll();}e.preventDefault();return;}
    if(e.pointerType==='touch'){
      const p=touchRollEditV089;if(!p||p.pid!==e.pointerId)return;
      if(uxNavBlockedV089()){cancelRollTouchEditV089(true);e.preventDefault();return;}
      const pt=canvasPoint(e),dx=pt.x-p.startX,dy=pt.y-p.startY,dist=Math.hypot(dx,dy);
      if(dist>8){p.moved=true;clearTimeout(p.longTimer);}
      if(p.type==='hit'&&p.moved){const tt=state.tracks.find(x=>x.id===p.trackId),n=tt?.notes.find(x=>x.id===p.noteId);if(!n)return;p.editStarted=true;if(p.resize)n.dur=Math.max(state.grid,snap(p.origDur+dx/beatWidth()));else{n.beat=clamp(snap(p.origBeat+dx/beatWidth()),0,totalBeats()-state.grid);n.midi=clamp(p.origMidi-Math.round(dy/28),48,83);}renderRoll();}
      e.preventDefault();return;
    }
    if(!gesture)return; const pt=canvasPoint(e); if(Math.abs(pt.x-gesture.startX)>4||Math.abs(pt.y-gesture.startY)>4){gesture.moved=true;clearTimeout(gesture.longTimer);} const n=currentNote(); if(!n)return; if(gesture.type==='move'){n.beat=clamp(snap(gesture.origBeat+(pt.x-gesture.startX)/beatWidth()),0,totalBeats()-state.grid); n.midi=clamp(gesture.origMidi-Math.round((pt.y-gesture.startY)/28),48,83);} else n.dur=Math.max(state.grid,snap(gesture.origDur+(pt.x-gesture.startX)/beatWidth())); renderRoll();
  });
  c.addEventListener('pointerup',e=>{
    if(measureEditV08157.active&&measureEditV08157.pointerId===e.pointerId){measureEditV08157.dragging=false;measureEditV08157.pointerId=null;renderMeasureCopyUiV08157();renderRoll();e.preventDefault();return;}
    if(e.pointerType==='touch'){
      const p=touchRollEditV089;if(!p||p.pid!==e.pointerId)return;clearTimeout(p.longTimer);
      if(!uxNavBlockedV089()){
        if(p.type==='create'&&!p.moved){const tt=state.tracks.find(x=>x.id===p.trackId);if(tt)mutate(()=>{const n={id:uid(),beat:p.beat,dur:Math.max(state.grid,1),midi:p.midi,velocity:+els.velocity.value||.72};tt.notes.push(n);state.selectedNoteId=n.id;});}
        else if(p.type==='hit'&&p.editStarted){state.history.push(p.before);if(state.history.length>60)state.history.shift();state.future=[];markDirty();}
      }else if(p.type==='hit'&&p.editStarted){const tt=state.tracks.find(x=>x.id===p.trackId),n=tt?.notes.find(x=>x.id===p.noteId);if(n){n.beat=p.origBeat;n.dur=p.origDur;n.midi=p.origMidi;}}
      touchRollEditV089=null;renderRoll();renderInspector();return;
    }
    if(gesture){clearTimeout(gesture.longTimer);gesture=null;}
  });
  c.addEventListener('pointercancel',e=>{if(measureEditV08157.pointerId===e.pointerId){measureEditV08157.dragging=false;measureEditV08157.pointerId=null;renderMeasureCopyUiV08157();renderRoll();return;}if(e.pointerType==='touch'){cancelRollTouchEditV089(true);return;}if(gesture){clearTimeout(gesture.longTimer);gesture=null;}});
}
function canvasPoint(e){const r=els.roll.getBoundingClientRect();return{x:e.clientX-r.left,y:e.clientY-r.top};}
function hitNote(x,y){const t=currentTrack();if(!t)return null;return [...t.notes].reverse().find(n=>{const nx=n.beat*beatWidth(),ny=(83-n.midi)*28+3,nw=Math.max(8,n.dur*beatWidth()-3);return x>=nx&&x<=nx+nw&&y>=ny&&y<=ny+22;});}
function snap(v){return Math.round(v/state.grid)*state.grid;}
function duplicateSelectedNote(){const t=currentTrack(),n=currentNote();if(!t||!n)return;mutate(()=>{const d={...n,id:uid(),beat:clamp(n.beat+n.dur,0,totalBeats()-n.dur)};t.notes.push(d);state.selectedNoteId=d.id;});renderRoll();}
function deleteSelectedNote(){const t=currentTrack(),n=currentNote();if(!t||!n)return;mutate(()=>t.notes=t.notes.filter(x=>x.id!==n.id));state.selectedNoteId=null;renderRoll();}

function renderDrums(){
  els.drums.innerHTML='';
  Object.keys(state.drums).forEach(name=>{const row=document.createElement('div');row.className='drum-row';const lab=document.createElement('div');lab.className='drum-name';lab.textContent=name;row.appendChild(lab);for(let i=0;i<16;i++){const b=document.createElement('button');b.className='step'+(state.drums[name].has(i)?' active':'');b.textContent=(i%4===0)?String(i/4+1):'·';b.onclick=()=>{state.drums[name].has(i)?state.drums[name].delete(i):state.drums[name].add(i);markDirty();renderDrums();};row.appendChild(b);}els.drums.appendChild(row);});
}

// V0.7.8–V0.7.10 — lissage anti-coupures + diagnostic/stabilisation
function rawAutomationValueV078(a,sec,prop='value',fallback=1){
  if(!a?.enabled)return fallback;const pts=a.points||[];if(!pts.length)return fallback;
  if(sec<=pts[0].sec)return Number(pts[0][prop]);if(sec>=pts[pts.length-1].sec)return Number(pts[pts.length-1][prop]);
  let i=1;while(i<pts.length&&pts[i].sec<sec)i++;const p0=pts[i-1],p1=pts[i],d=Math.max(.001,p1.sec-p0.sec),u=clamp((sec-p0.sec)/d,0,1),k=a.curve==='soft'?(1-Math.cos(Math.PI*u))/2:u;
  return Number(p0[prop])+(Number(p1[prop])-Number(p0[prop]))*k;
}
function safeAutomationValueV078(a,sec,prop='value',fallback=1,min=0,max=1){
  const raw=rawAutomationValueV078(a,sec,prop,fallback);if(!a?.enabled||state.automationSafety?.enabled===false)return clamp(raw,min,max);
  const w=Math.max(.02,(Number(state.automationSafety?.smoothingMs)||150)/1000),weights=[1,2,3,2,1],offs=[-w,-w*.5,0,w*.5,w];let sum=0,ws=0;
  for(let i=0;i<offs.length;i++){sum+=weights[i]*rawAutomationValueV078(a,clamp(sec+offs[i],0,state.duration),prop,fallback);ws+=weights[i];}
  return clamp(sum/ws,min,max);
}
function scheduleSafeAutomationV078(param,a,when,totalSec,map,evalFn){
  if(!a?.enabled)return false;const smoothing=Math.max(80,Number(state.automationSafety?.smoothingMs)||150),step=state.automationSafety?.enabled===false?null:Math.max(.12,Math.min(.35,smoothing/1000));
  if(step==null)return false;try{param.cancelScheduledValues(when);}catch{}
  let sec=0,val=evalFn(0);param.setValueAtTime(map(val),when+tempoNominalToActualV073(0));
  for(sec=step;sec<totalSec;sec+=step){val=evalFn(sec);param.linearRampToValueAtTime(map(val),when+tempoNominalToActualV073(sec));}
  val=evalFn(totalSec);param.linearRampToValueAtTime(map(val),when+tempoNominalToActualV073(totalSec));return true;
}
function repairAutomationPointsV079(a,prop='value',fallback=1,min=0,max=1){
  if(!a||typeof a!=='object')return 0;let fixes=0,pts=Array.isArray(a.points)?a.points:[];const clean=[];
  for(const p of pts){let sec=clamp(Number(p.sec)||0,0,state.duration),v=clamp(Number(p[prop]),min,max);if(!Number.isFinite(v))v=fallback;const q=clean[clean.length-1];if(q&&Math.abs(q.sec-sec)<.05){q[prop]=v;fixes++;}else clean.push({sec,[prop]:v});}
  clean.sort((x,y)=>x.sec-y.sec);if(!clean.length){clean.push({sec:0,[prop]:fallback},{sec:state.duration,[prop]:fallback});fixes++;}
  if(clean[0].sec>.001){clean.unshift({sec:0,[prop]:clean[0][prop]});fixes++;}else clean[0].sec=0;
  const last=clean[clean.length-1];if(last.sec<state.duration-.001){clean.push({sec:state.duration,[prop]:last[prop]});fixes++;}else last.sec=state.duration;
  a.points=clean;a.curve=a.curve==='linear'?'linear':'soft';a.enabled=!!a.enabled;return fixes;
}
function automationDiagnosticsV079(){
  let curves=0,active=0,points=0,issues=0;const inspect=(a,prop='value',range=1)=>{if(!a)return;curves++;if(a.enabled)active++;const pts=Array.isArray(a.points)?a.points:[];points+=pts.length;for(let i=0;i<pts.length;i++){const p=pts[i],v=Number(p[prop]);if(!Number.isFinite(p.sec)||!Number.isFinite(v)||p.sec<0||p.sec>state.duration)issues++;if(i&&p.sec<=pts[i-1].sec)issues++;if(i){const dt=p.sec-pts[i-1].sec,dv=Math.abs(v-Number(pts[i-1][prop]));if(dt<.08&&dv>range*.15)issues++;}}};
  for(const t of state.tracks){inspect(ensureVolumeAutomationV070(t));inspect(ensureEffectAutomationV071(t,'filterAutomation'));inspect(ensureEffectAutomationV071(t,'reverbAutomation'));}
  inspect(ensureRhythmAutomationV072('rhythmIntensityAutomation'));inspect(ensureRhythmAutomationV072('rhythmDensityAutomation'));inspect(ensureTempoAutomationV073(),'bpm',120);
  normalizeAutomationGroupsV077();for(const g of state.automationGroups||[])for(const k of ['volumeAutomation','filterAutomation','reverbAutomation'])inspect(g[k]);for(const k of ['volumeAutomation','filterAutomation','reverbAutomation'])inspect(state.masterBusAutomation[k]);
  return {curves,active,points,issues};
}
function repairAllAutomationsV079(){let fixes=0;mutate(()=>{for(const t of state.tracks){fixes+=repairAutomationPointsV079(ensureVolumeAutomationV070(t));fixes+=repairAutomationPointsV079(ensureEffectAutomationV071(t,'filterAutomation'));fixes+=repairAutomationPointsV079(ensureEffectAutomationV071(t,'reverbAutomation'));}fixes+=repairAutomationPointsV079(ensureRhythmAutomationV072('rhythmIntensityAutomation'));fixes+=repairAutomationPointsV079(ensureRhythmAutomationV072('rhythmDensityAutomation'));fixes+=repairAutomationPointsV079(ensureTempoAutomationV073(),'bpm',state.bpm,40,160);normalizeAutomationGroupsV077();for(const g of state.automationGroups||[])for(const k of ['volumeAutomation','filterAutomation','reverbAutomation'])fixes+=repairAutomationPointsV079(g[k]);for(const k of ['volumeAutomation','filterAutomation','reverbAutomation'])fixes+=repairAutomationPointsV079(state.masterBusAutomation[k]);});invalidateTempoMapV073();renderAll();toast(fixes?`${fixes} correction(s) appliquée(s)`:'Courbes déjà propres');}
function renderAutomationStabilityV0710(){const st=$('#automationStabilityStatus'),diag=$('#automationDiagnostics'),en=$('#automationSafetyEnabled'),sm=$('#automationSafetySmoothing');if(!st)return;state.automationSafety=state.automationSafety||{enabled:true,smoothingMs:150};if(en)en.checked=state.automationSafety.enabled!==false;if(sm)sm.value=String(state.automationSafety.smoothingMs||150);const d=automationDiagnosticsV079();st.textContent=d.issues?`${d.issues} À VÉRIFIER`:`OK • ${d.active} ACTIVE${d.active>1?'S':''}`;st.className=d.issues?'automation-on-pill':'automation-off-pill';if(diag)diag.innerHTML=`<b>Diagnostic :</b> ${d.curves} courbes • ${d.points} points • ${d.active} actives • ${d.issues?'<b>'+d.issues+' anomalie(s)</b>':'aucune anomalie détectée'}. Anti-coupures ${state.automationSafety.enabled!==false?'ON':'OFF'}.`;}
function bindAutomationStabilityV0710(){const en=$('#automationSafetyEnabled'),sm=$('#automationSafetySmoothing'),an=$('#automationAnalyzeBtn'),rp=$('#automationRepairBtn');if(en)en.onchange=e=>{mutate(()=>{state.automationSafety=state.automationSafety||{};state.automationSafety.enabled=e.target.checked;});invalidateTempoMapV073();renderAll();};if(sm)sm.onchange=e=>{mutate(()=>{state.automationSafety=state.automationSafety||{};state.automationSafety.smoothingMs=+e.target.value||150;});invalidateTempoMapV073();renderAll();};if(an)an.onclick=()=>{renderAutomationStabilityV0710();toast('Diagnostic automation actualisé');};if(rp)rp.onclick=repairAllAutomationsV079;renderAutomationStabilityV0710();}

// V0.7.0 — automation de volume par piste
let volumeAutomationSelectedV070=null;
let volumeAutomationDragV070=null;
function ensureVolumeAutomationV070(t){
  if(!t)return null;
  let a=t.volumeAutomation;
  if(!a||typeof a!=='object')a=t.volumeAutomation={enabled:false,curve:'soft',points:[{sec:0,value:1},{sec:state.duration,value:1}]};
  a.enabled=!!a.enabled;a.curve=a.curve==='linear'?'linear':'soft';
  let pts=Array.isArray(a.points)?a.points:[];
  pts=pts.map(p=>({sec:clamp(Number(p.sec)||0,0,state.duration),value:clamp(Number(p.value),0,1)})).filter(p=>Number.isFinite(p.sec)&&Number.isFinite(p.value)).sort((x,y)=>x.sec-y.sec);
  if(!pts.length)pts=[{sec:0,value:1},{sec:state.duration,value:1}];
  const ded=[];for(const p of pts){const q=ded[ded.length-1];if(q&&Math.abs(q.sec-p.sec)<.015){q.value=p.value;}else ded.push(p);}
  pts=ded;
  if(pts[0].sec>.001)pts.unshift({sec:0,value:pts[0].value});else pts[0].sec=0;
  const last=pts[pts.length-1];if(last.sec<state.duration-.001)pts.push({sec:state.duration,value:last.value});else last.sec=state.duration;
  a.points=pts;return a;
}
function normalizeAllVolumeAutomationV070(){state.tracks.forEach(ensureVolumeAutomationV070);}
function volumeAutomationValueAtV070(t,sec){const a=ensureVolumeAutomationV070(t);return safeAutomationValueV078(a,sec,'value',1,0,1);}
function scheduleTrackVolumeAutomationV070(param,t,when,totalSec,base){
  const a=ensureVolumeAutomationV070(t);const b=Math.max(.0001,base||.0001);try{param.cancelScheduledValues(when);}catch{}
  if(!a?.enabled){param.setValueAtTime(b,when);return;}
  if(scheduleSafeAutomationV078(param,a,when,totalSec,v=>Math.max(.0001,b*v),sec=>volumeAutomationValueAtV070(t,sec)))return;
  const pts=a.points.map(p=>({sec:clamp(p.sec,0,totalSec),value:p.value})).filter((p,i,x)=>!i||p.sec>x[i-1].sec+.0005);
  if(!pts.length){param.setValueAtTime(b,when);return;}
  param.setValueAtTime(Math.max(.0001,b*pts[0].value),when+tempoNominalToActualV073(pts[0].sec));
  for(let i=1;i<pts.length;i++){
    const p0=pts[i-1],p1=pts[i],d=p1.sec-p0.sec;if(d<=.001)continue;
    if(a.curve==='linear'){param.linearRampToValueAtTime(Math.max(.0001,b*p1.value),when+tempoNominalToActualV073(p1.sec));}
    else{const steps=18;for(let j=1;j<=steps;j++){const u=j/steps,k=(1-Math.cos(Math.PI*u))/2,v=Math.max(.0001,b*(p0.value+(p1.value-p0.value)*k));param.linearRampToValueAtTime(v,when+tempoNominalToActualV073(p0.sec+d*u));}}
  }
}
function automationSvgPointV070(evt,svg){const r=svg.getBoundingClientRect(),x=clamp((evt.clientX-r.left)/Math.max(1,r.width),0,1),y=clamp((evt.clientY-r.top)/Math.max(1,r.height),0,1);return {sec:snapAutomationSecV077(x*state.duration),value:1-y};}
function renderVolumeAutomationV070(){
  const svg=$('#volumeAutomationSvg'),label=$('#automationTrackLabel'),info=$('#automationPointInfo'),del=$('#automationDeletePointBtn');if(!svg)return;const t=currentTrack();if(!t){svg.innerHTML='';if(label)label.textContent='—';return;}
  const a=ensureVolumeAutomationV070(t);if(label)label.textContent=t.name;if($('#automationEnabled'))$('#automationEnabled').checked=a.enabled;if($('#automationCurve'))$('#automationCurve').value=a.curve;
  const W=1000,H=260,pad=20,x=s=>pad+(W-pad*2)*(s/Math.max(.001,state.duration)),y=v=>pad+(H-pad*2)*(1-v);
  let s='';for(const v of [0,.25,.5,.75,1])s+=`<line x1="${pad}" y1="${y(v)}" x2="${W-pad}" y2="${y(v)}" class="auto-grid"/>`;
  for(let sec=0;sec<=state.duration+.01;sec+=Math.max(10,state.duration/6))s+=`<line x1="${x(sec)}" y1="${pad}" x2="${x(sec)}" y2="${H-pad}" class="auto-grid auto-grid-v"/>`;
  const samples=[];for(let i=0;i<=120;i++){const sec=state.duration*i/120;samples.push(`${x(sec).toFixed(1)},${y(volumeAutomationValueAtV070(t,sec)).toFixed(1)}`);}s+=`<polyline points="${samples.join(' ')}" class="auto-curve ${a.enabled?'':'disabled'}"/>`;
  a.points.forEach((p,i)=>{const selected=i===volumeAutomationSelectedV070;s+=`<circle data-auto-point="${i}" cx="${x(p.sec)}" cy="${y(p.value)}" r="${selected?13:11}" class="auto-point ${selected?'selected':''}"/>`;});svg.innerHTML=s;
  if(info){const i=volumeAutomationSelectedV070,p=a.points[i];info.textContent=p?`Point ${i+1}/${a.points.length} • ${p.sec.toFixed(1)} s • ${Math.round(p.value*100)}%`:`${a.enabled?'Active':'Inactive'} • ${a.points.length} points • touche la courbe pour ajouter un point.`;}
  if(del){const i=volumeAutomationSelectedV070;del.disabled=i==null||i<=0||i>=a.points.length-1;}
}
function setVolumeAutomationPresetV070(kind){const t=currentTrack();if(!t)return;mutate(()=>{const a=ensureVolumeAutomationV070(t),d=state.duration;a.enabled=true;if(kind==='fadein')a.points=[{sec:0,value:0},{sec:Math.min(10,d*.18),value:1},{sec:d,value:1}];else if(kind==='fadeout')a.points=[{sec:0,value:1},{sec:Math.max(0,d-Math.min(10,d*.18)),value:1},{sec:d,value:0}];else if(kind==='rise')a.points=[{sec:0,value:.30},{sec:d*.5,value:.62},{sec:d,value:1}];else if(kind==='fall')a.points=[{sec:0,value:1},{sec:d*.5,value:.62},{sec:d,value:.30}];else a.points=[{sec:0,value:1},{sec:d,value:1}];});volumeAutomationSelectedV070=null;renderVolumeAutomationV070();}
function bindVolumeAutomationV070(){
  const svg=$('#volumeAutomationSvg');if(!svg)return;
  $('#automationEnabled').onchange=e=>{const t=currentTrack();if(!t)return;mutate(()=>ensureVolumeAutomationV070(t).enabled=e.target.checked);renderVolumeAutomationV070();};
  $('#automationCurve').onchange=e=>{const t=currentTrack();if(!t)return;mutate(()=>ensureVolumeAutomationV070(t).curve=e.target.value);renderVolumeAutomationV070();};
  $('#automationFadeInBtn').onclick=()=>setVolumeAutomationPresetV070('fadein');$('#automationFadeOutBtn').onclick=()=>setVolumeAutomationPresetV070('fadeout');$('#automationRiseBtn').onclick=()=>setVolumeAutomationPresetV070('rise');$('#automationFallBtn').onclick=()=>setVolumeAutomationPresetV070('fall');$('#automationFlatBtn').onclick=()=>setVolumeAutomationPresetV070('flat');
  $('#automationDeletePointBtn').onclick=()=>{const t=currentTrack(),a=ensureVolumeAutomationV070(t),i=volumeAutomationSelectedV070;if(i==null||i<=0||i>=a.points.length-1)return;mutate(()=>a.points.splice(i,1));volumeAutomationSelectedV070=null;renderVolumeAutomationV070();};
  $('#automationPreviewBtn').onclick=()=>{stop();play();toast('Lecture avec automation de volume');};
  svg.addEventListener('pointerdown',e=>{const t=currentTrack();if(!t)return;const a=ensureVolumeAutomationV070(t),circle=e.target.closest?.('[data-auto-point]');
    if(circle){const i=+circle.dataset.autoPoint;volumeAutomationSelectedV070=i;setLastAutoSelectionV077('volume');volumeAutomationDragV070={i,before:snapshot(),pid:e.pointerId};circle.setPointerCapture?.(e.pointerId);renderVolumeAutomationV070();e.preventDefault();return;}
    const p=automationSvgPointV070(e,svg);mutate(()=>{a.enabled=true;a.points.push(p);a.points.sort((x,y)=>x.sec-y.sec);});volumeAutomationSelectedV070=ensureVolumeAutomationV070(t).points.findIndex(q=>Math.abs(q.sec-p.sec)<.02&&Math.abs(q.value-p.value)<.02);setLastAutoSelectionV077('volume');renderVolumeAutomationV070();e.preventDefault();
  });
  window.addEventListener('pointermove',e=>{if(!volumeAutomationDragV070||e.pointerId!==volumeAutomationDragV070.pid)return;const t=currentTrack(),a=ensureVolumeAutomationV070(t),i=volumeAutomationDragV070.i,p=automationSvgPointV070(e,svg);if(!a.points[i])return;a.enabled=true;a.points[i].value=p.value;if(i>0&&i<a.points.length-1){const lo=a.points[i-1].sec+.05,hi=a.points[i+1].sec-.05;a.points[i].sec=clamp(p.sec,lo,hi);}markDirty();renderVolumeAutomationV070();e.preventDefault();});
  const end=e=>{if(!volumeAutomationDragV070||e.pointerId!==volumeAutomationDragV070.pid)return;state.history.push(volumeAutomationDragV070.before);if(state.history.length>60)state.history.shift();state.future=[];volumeAutomationDragV070=null;renderVolumeAutomationV070();};window.addEventListener('pointerup',end);window.addEventListener('pointercancel',end);
}


// V0.7.1 — automation filtre + reverb
const FX_AUTOMATION_V071={
  filterAutomation:{svg:'filterAutomationSvg',enabled:'filterAutomationEnabled',curve:'filterAutomationCurve',label:'filterAutomationTrackLabel',info:'filterAutomationPointInfo',del:'filterAutomationDeletePointBtn',preview:'filterAutomationPreviewBtn'},
  reverbAutomation:{svg:'reverbAutomationSvg',enabled:'reverbAutomationEnabled',curve:'reverbAutomationCurve',label:'reverbAutomationTrackLabel',info:'reverbAutomationPointInfo',del:'reverbAutomationDeletePointBtn',preview:'reverbAutomationPreviewBtn'}
};
const effectAutoSelectedV071={filterAutomation:null,reverbAutomation:null};
const effectAutoDragV071={filterAutomation:null,reverbAutomation:null};
function ensureEffectAutomationV071(t,key){
  if(!t)return null;let a=t[key];if(!a||typeof a!=='object')a=t[key]={enabled:false,curve:'soft',points:[{sec:0,value:1},{sec:state.duration,value:1}]};
  a.enabled=!!a.enabled;a.curve=a.curve==='linear'?'linear':'soft';let pts=Array.isArray(a.points)?a.points:[];
  pts=pts.map(p=>({sec:clamp(Number(p.sec)||0,0,state.duration),value:clamp(Number(p.value),0,1)})).filter(p=>Number.isFinite(p.sec)&&Number.isFinite(p.value)).sort((x,y)=>x.sec-y.sec);
  if(!pts.length)pts=[{sec:0,value:1},{sec:state.duration,value:1}];const ded=[];for(const p of pts){const q=ded[ded.length-1];if(q&&Math.abs(q.sec-p.sec)<.015)q.value=p.value;else ded.push(p);}pts=ded;
  if(pts[0].sec>.001)pts.unshift({sec:0,value:pts[0].value});else pts[0].sec=0;const last=pts[pts.length-1];if(last.sec<state.duration-.001)pts.push({sec:state.duration,value:last.value});else last.sec=state.duration;a.points=pts;return a;
}
function normalizeAllEffectAutomationV071(){for(const t of state.tracks){ensureEffectAutomationV071(t,'filterAutomation');ensureEffectAutomationV071(t,'reverbAutomation');}}
function effectAutomationValueAtV071(t,key,sec){const a=ensureEffectAutomationV071(t,key);return safeAutomationValueV078(a,sec,'value',1,0,1);}
function filterHzFromNormV071(baseHz,v){const lo=Math.min(420,Math.max(160,baseHz*.08)),hi=Math.max(lo+50,Math.min(20000,baseHz||16000));return lo*Math.pow(hi/lo,clamp(v,0,1));}
function scheduleEffectAutomationV071(param,t,key,when,totalSec,base){
  const a=ensureEffectAutomationV071(t,key);try{param.cancelScheduledValues(when);}catch{}
  const map=key==='filterAutomation'?(v=>filterHzFromNormV071(base,v)):(v=>Math.max(.00001,(base||0)*v));
  if(!a?.enabled){param.setValueAtTime(map(1),when);return;}if(scheduleSafeAutomationV078(param,a,when,totalSec,map,sec=>effectAutomationValueAtV071(t,key,sec)))return;const pts=a.points.map(p=>({sec:clamp(p.sec,0,totalSec),value:p.value})).filter((p,i,x)=>!i||p.sec>x[i-1].sec+.0005);if(!pts.length){param.setValueAtTime(map(1),when);return;}
  param.setValueAtTime(map(pts[0].value),when+tempoNominalToActualV073(pts[0].sec));for(let i=1;i<pts.length;i++){const p0=pts[i-1],p1=pts[i],d=p1.sec-p0.sec;if(d<=.001)continue;if(a.curve==='linear'){param.linearRampToValueAtTime(map(p1.value),when+tempoNominalToActualV073(p1.sec));}else{const steps=18;for(let j=1;j<=steps;j++){const u=j/steps,k=(1-Math.cos(Math.PI*u))/2,v=p0.value+(p1.value-p0.value)*k;param.linearRampToValueAtTime(map(v),when+tempoNominalToActualV073(p0.sec+d*u));}}}
}
function renderOneEffectAutomationV071(key){const cfg=FX_AUTOMATION_V071[key],svg=$('#'+cfg.svg),label=$('#'+cfg.label),info=$('#'+cfg.info),del=$('#'+cfg.del);if(!svg)return;const t=currentTrack();if(!t){svg.innerHTML='';if(label)label.textContent='—';return;}const a=ensureEffectAutomationV071(t,key);$('#'+cfg.enabled).checked=a.enabled;$('#'+cfg.curve).value=a.curve;if(label)label.textContent=t.name;
  const W=1000,H=260,pad=20,x=sec=>pad+(W-pad*2)*(sec/Math.max(.001,state.duration)),y=v=>pad+(H-pad*2)*(1-v);let h='';for(const v of [0,.25,.5,.75,1])h+=`<line x1="${pad}" y1="${y(v)}" x2="${W-pad}" y2="${y(v)}" class="auto-grid"/>`;for(let sec=0;sec<=state.duration+.01;sec+=Math.max(10,state.duration/6))h+=`<line x1="${x(sec)}" y1="${pad}" x2="${x(sec)}" y2="${H-pad}" class="auto-grid auto-grid-v"/>`;
  const samples=[];for(let i=0;i<=120;i++){const sec=state.duration*i/120;samples.push(`${x(sec).toFixed(1)},${y(effectAutomationValueAtV071(t,key,sec)).toFixed(1)}`);}h+=`<polyline points="${samples.join(' ')}" class="auto-curve ${a.enabled?'':'disabled'}"/>`;a.points.forEach((p,i)=>{const sel=i===effectAutoSelectedV071[key];h+=`<circle data-fx-point="${i}" cx="${x(p.sec)}" cy="${y(p.value)}" r="${sel?13:11}" class="auto-point ${sel?'selected':''}"/>`;});svg.innerHTML=h;
  const i=effectAutoSelectedV071[key],pt=a.points[i];if(info){let val='';if(pt)val=key==='filterAutomation'?`${Math.round(filterHzFromNormV071(t.filter||12000,pt.value))} Hz`:`${Math.round(pt.value*100)}%`;info.textContent=pt?`Point ${i+1}/${a.points.length} • ${pt.sec.toFixed(1)} s • ${val}`:`${a.enabled?'Active':'Inactive'} • ${a.points.length} points • touche la courbe pour ajouter un point.`;}if(del)del.disabled=i==null||i<=0||i>=a.points.length-1;
}
function renderEffectAutomationV071(){renderOneEffectAutomationV071('filterAutomation');renderOneEffectAutomationV071('reverbAutomation');}
function setEffectAutomationPresetV071(key,kind){const t=currentTrack();if(!t)return;mutate(()=>{const a=ensureEffectAutomationV071(t,key),d=state.duration;a.enabled=true;if(kind==='rise')a.points=[{sec:0,value:.24},{sec:d*.5,value:.62},{sec:d,value:1}];else if(kind==='fall')a.points=[{sec:0,value:1},{sec:d*.5,value:.62},{sec:d,value:.24}];else if(kind==='breathe')a.points=[{sec:0,value:.48},{sec:d*.28,value:.82},{sec:d*.55,value:.55},{sec:d*.78,value:.92},{sec:d,value:.55}];else if(kind==='wave')a.points=[{sec:0,value:.18},{sec:d*.3,value:.72},{sec:d*.56,value:.34},{sec:d*.8,value:.85},{sec:d,value:.28}];else a.points=[{sec:0,value:1},{sec:d,value:1}];});effectAutoSelectedV071[key]=null;renderOneEffectAutomationV071(key);}
function bindOneEffectAutomationV071(key){const cfg=FX_AUTOMATION_V071[key],svg=$('#'+cfg.svg);if(!svg)return;$('#'+cfg.enabled).onchange=e=>{const t=currentTrack();if(!t)return;mutate(()=>ensureEffectAutomationV071(t,key).enabled=e.target.checked);renderOneEffectAutomationV071(key);};$('#'+cfg.curve).onchange=e=>{const t=currentTrack();if(!t)return;mutate(()=>ensureEffectAutomationV071(t,key).curve=e.target.value);renderOneEffectAutomationV071(key);};$('#'+cfg.del).onclick=()=>{const t=currentTrack(),a=ensureEffectAutomationV071(t,key),i=effectAutoSelectedV071[key];if(i==null||i<=0||i>=a.points.length-1)return;mutate(()=>a.points.splice(i,1));effectAutoSelectedV071[key]=null;renderOneEffectAutomationV071(key);};$('#'+cfg.preview).onclick=()=>{stop();play();toast(key==='filterAutomation'?'Lecture avec automation de filtre':'Lecture avec automation de reverb');};
  svg.addEventListener('pointerdown',e=>{const t=currentTrack();if(!t)return;const a=ensureEffectAutomationV071(t,key),circle=e.target.closest?.('[data-fx-point]');if(circle){const i=+circle.dataset.fxPoint;effectAutoSelectedV071[key]=i;setLastAutoSelectionV077('fx',key);effectAutoDragV071[key]={i,before:snapshot(),pid:e.pointerId};circle.setPointerCapture?.(e.pointerId);renderOneEffectAutomationV071(key);e.preventDefault();return;}const p=automationSvgPointV070(e,svg);mutate(()=>{a.enabled=true;a.points.push(p);a.points.sort((x,y)=>x.sec-y.sec);});effectAutoSelectedV071[key]=ensureEffectAutomationV071(t,key).points.findIndex(q=>Math.abs(q.sec-p.sec)<.02&&Math.abs(q.value-p.value)<.02);setLastAutoSelectionV077('fx',key);renderOneEffectAutomationV071(key);e.preventDefault();});
  window.addEventListener('pointermove',e=>{const drag=effectAutoDragV071[key];if(!drag||e.pointerId!==drag.pid)return;const t=currentTrack(),a=ensureEffectAutomationV071(t,key),i=drag.i,p=automationSvgPointV070(e,svg);if(!a.points[i])return;a.enabled=true;a.points[i].value=p.value;if(i>0&&i<a.points.length-1){const lo=a.points[i-1].sec+.05,hi=a.points[i+1].sec-.05;a.points[i].sec=clamp(p.sec,lo,hi);}markDirty();renderOneEffectAutomationV071(key);e.preventDefault();});
  const end=e=>{const drag=effectAutoDragV071[key];if(!drag||e.pointerId!==drag.pid)return;state.history.push(drag.before);if(state.history.length>60)state.history.shift();state.future=[];effectAutoDragV071[key]=null;renderOneEffectAutomationV071(key);};window.addEventListener('pointerup',end);window.addEventListener('pointercancel',end);
}
function bindEffectAutomationV071(){bindOneEffectAutomationV071('filterAutomation');bindOneEffectAutomationV071('reverbAutomation');$('#filterAutomationOpenBtn').onclick=()=>setEffectAutomationPresetV071('filterAutomation','rise');$('#filterAutomationCloseBtn').onclick=()=>setEffectAutomationPresetV071('filterAutomation','fall');$('#filterAutomationBreatheBtn').onclick=()=>setEffectAutomationPresetV071('filterAutomation','breathe');$('#filterAutomationFlatBtn').onclick=()=>setEffectAutomationPresetV071('filterAutomation','flat');$('#reverbAutomationRiseBtn').onclick=()=>setEffectAutomationPresetV071('reverbAutomation','rise');$('#reverbAutomationFallBtn').onclick=()=>setEffectAutomationPresetV071('reverbAutomation','fall');$('#reverbAutomationWaveBtn').onclick=()=>setEffectAutomationPresetV071('reverbAutomation','wave');$('#reverbAutomationFlatBtn').onclick=()=>setEffectAutomationPresetV071('reverbAutomation','flat');}


// V0.7.2 — automation globale des percussions : intensité + densité
const RHYTHM_AUTO_CFG_V072={
  rhythmIntensityAutomation:{svg:'rhythmIntensitySvg',enabled:'rhythmIntensityEnabled',curve:'rhythmIntensityCurve',info:'rhythmIntensityInfo',del:'rhythmIntensityDeleteBtn'},
  rhythmDensityAutomation:{svg:'rhythmDensitySvg',enabled:'rhythmDensityEnabled',curve:'rhythmDensityCurve',info:'rhythmDensityInfo',del:'rhythmDensityDeleteBtn'}
};
const rhythmAutoSelectedV072={rhythmIntensityAutomation:null,rhythmDensityAutomation:null};
const rhythmAutoDragV072={rhythmIntensityAutomation:null,rhythmDensityAutomation:null};
function ensureRhythmAutomationV072(key){
  let a=state[key];if(!a||typeof a!=='object')a=state[key]={enabled:false,curve:'soft',points:[{sec:0,value:1},{sec:state.duration,value:1}]};
  a.enabled=!!a.enabled;a.curve=a.curve==='linear'?'linear':'soft';let pts=Array.isArray(a.points)?a.points:[];
  pts=pts.map(p=>({sec:clamp(Number(p.sec)||0,0,state.duration),value:clamp(Number(p.value),0,1)})).filter(p=>Number.isFinite(p.sec)&&Number.isFinite(p.value)).sort((x,y)=>x.sec-y.sec);
  if(!pts.length)pts=[{sec:0,value:1},{sec:state.duration,value:1}];const ded=[];for(const p of pts){const q=ded[ded.length-1];if(q&&Math.abs(q.sec-p.sec)<.015)q.value=p.value;else ded.push(p);}pts=ded;
  if(pts[0].sec>.001)pts.unshift({sec:0,value:pts[0].value});else pts[0].sec=0;const last=pts[pts.length-1];if(last.sec<state.duration-.001)pts.push({sec:state.duration,value:last.value});else last.sec=state.duration;a.points=pts;return a;
}
function normalizeRhythmAutomationV072(){ensureRhythmAutomationV072('rhythmIntensityAutomation');ensureRhythmAutomationV072('rhythmDensityAutomation');}
function rhythmAutomationValueAtV072(key,sec){const a=ensureRhythmAutomationV072(key);return safeAutomationValueV078(a,sec,'value',1,0,1);}
function renderOneRhythmAutomationV072(key){const cfg=RHYTHM_AUTO_CFG_V072[key],svg=$('#'+cfg.svg),info=$('#'+cfg.info),del=$('#'+cfg.del);if(!svg)return;const a=ensureRhythmAutomationV072(key);$('#'+cfg.enabled).checked=a.enabled;$('#'+cfg.curve).value=a.curve;const W=1000,H=260,pad=20,x=sec=>pad+(W-pad*2)*(sec/Math.max(.001,state.duration)),y=v=>pad+(H-pad*2)*(1-v);let h='';for(const v of [0,.25,.5,.75,1])h+=`<line x1="${pad}" y1="${y(v)}" x2="${W-pad}" y2="${y(v)}" class="auto-grid"/>`;for(let sec=0;sec<=state.duration+.01;sec+=Math.max(10,state.duration/6))h+=`<line x1="${x(sec)}" y1="${pad}" x2="${x(sec)}" y2="${H-pad}" class="auto-grid auto-grid-v"/>`;const samples=[];for(let i=0;i<=120;i++){const sec=state.duration*i/120;samples.push(`${x(sec).toFixed(1)},${y(rhythmAutomationValueAtV072(key,sec)).toFixed(1)}`);}h+=`<polyline points="${samples.join(' ')}" class="auto-curve ${a.enabled?'':'disabled'}"/>`;a.points.forEach((p,i)=>{const sel=i===rhythmAutoSelectedV072[key];h+=`<circle data-rhythm-point="${i}" cx="${x(p.sec)}" cy="${y(p.value)}" r="${sel?13:11}" class="auto-point ${sel?'selected':''}"/>`;});svg.innerHTML=h;const i=rhythmAutoSelectedV072[key],pt=a.points[i];if(info)info.textContent=pt?`Point ${i+1}/${a.points.length} • ${pt.sec.toFixed(1)} s • ${Math.round(pt.value*100)}%`:`${a.enabled?'Active':'Inactive'} • ${a.points.length} points • touche la courbe pour ajouter un point.`;if(del)del.disabled=i==null||i<=0||i>=a.points.length-1;}
function renderRhythmAutomationV072(){renderOneRhythmAutomationV072('rhythmIntensityAutomation');renderOneRhythmAutomationV072('rhythmDensityAutomation');}
function setRhythmAutomationPresetV072(key,kind){mutate(()=>{const a=ensureRhythmAutomationV072(key),d=state.duration;a.enabled=true;if(kind==='rise')a.points=[{sec:0,value:.14},{sec:d*.32,value:.34},{sec:d*.68,value:.68},{sec:d,value:1}];else if(kind==='fall')a.points=[{sec:0,value:1},{sec:d*.35,value:.72},{sec:d*.72,value:.38},{sec:d,value:.12}];else if(kind==='pulse')a.points=[{sec:0,value:.42},{sec:d*.22,value:.62},{sec:d*.44,value:.46},{sec:d*.68,value:.74},{sec:d,value:.55}];else if(kind==='sparse')a.points=[{sec:0,value:.18},{sec:d*.45,value:.28},{sec:d,value:.42}];else a.points=[{sec:0,value:1},{sec:d,value:1}];});rhythmAutoSelectedV072[key]=null;renderOneRhythmAutomationV072(key);}
function setCivilisationPresetV072(){mutate(()=>{const d=state.duration,i=ensureRhythmAutomationV072('rhythmIntensityAutomation'),den=ensureRhythmAutomationV072('rhythmDensityAutomation');i.enabled=true;den.enabled=true;i.curve=den.curve='soft';i.points=[{sec:0,value:.08},{sec:d*.25,value:.22},{sec:d*.5,value:.48},{sec:d*.75,value:.74},{sec:d,value:1}];den.points=[{sec:0,value:.12},{sec:d*.3,value:.28},{sec:d*.55,value:.52},{sec:d*.78,value:.76},{sec:d,value:1}];});rhythmAutoSelectedV072.rhythmIntensityAutomation=null;rhythmAutoSelectedV072.rhythmDensityAutomation=null;renderRhythmAutomationV072();toast('Preset Civilisation 0→100 % appliqué');}
function bindOneRhythmAutomationV072(key){const cfg=RHYTHM_AUTO_CFG_V072[key],svg=$('#'+cfg.svg);if(!svg)return;$('#'+cfg.enabled).onchange=e=>{mutate(()=>ensureRhythmAutomationV072(key).enabled=e.target.checked);renderOneRhythmAutomationV072(key);};$('#'+cfg.curve).onchange=e=>{mutate(()=>ensureRhythmAutomationV072(key).curve=e.target.value);renderOneRhythmAutomationV072(key);};$('#'+cfg.del).onclick=()=>{const a=ensureRhythmAutomationV072(key),i=rhythmAutoSelectedV072[key];if(i==null||i<=0||i>=a.points.length-1)return;mutate(()=>a.points.splice(i,1));rhythmAutoSelectedV072[key]=null;renderOneRhythmAutomationV072(key);};svg.addEventListener('pointerdown',e=>{const a=ensureRhythmAutomationV072(key),circle=e.target.closest?.('[data-rhythm-point]');if(circle){const i=+circle.dataset.rhythmPoint;rhythmAutoSelectedV072[key]=i;setLastAutoSelectionV077('rhythm',key);rhythmAutoDragV072[key]={i,before:snapshot(),pid:e.pointerId};circle.setPointerCapture?.(e.pointerId);renderOneRhythmAutomationV072(key);e.preventDefault();return;}const p=automationSvgPointV070(e,svg);mutate(()=>{a.enabled=true;a.points.push(p);a.points.sort((x,y)=>x.sec-y.sec);});rhythmAutoSelectedV072[key]=ensureRhythmAutomationV072(key).points.findIndex(q=>Math.abs(q.sec-p.sec)<.02&&Math.abs(q.value-p.value)<.02);setLastAutoSelectionV077('rhythm',key);renderOneRhythmAutomationV072(key);e.preventDefault();});window.addEventListener('pointermove',e=>{const drag=rhythmAutoDragV072[key];if(!drag||e.pointerId!==drag.pid)return;const a=ensureRhythmAutomationV072(key),i=drag.i,p=automationSvgPointV070(e,svg);if(!a.points[i])return;a.enabled=true;a.points[i].value=p.value;if(i>0&&i<a.points.length-1){const lo=a.points[i-1].sec+.05,hi=a.points[i+1].sec-.05;a.points[i].sec=clamp(p.sec,lo,hi);}markDirty();renderOneRhythmAutomationV072(key);e.preventDefault();});const end=e=>{const drag=rhythmAutoDragV072[key];if(!drag||e.pointerId!==drag.pid)return;state.history.push(drag.before);if(state.history.length>60)state.history.shift();state.future=[];rhythmAutoDragV072[key]=null;renderOneRhythmAutomationV072(key);};window.addEventListener('pointerup',end);window.addEventListener('pointercancel',end);}
function bindRhythmAutomationV072(){bindOneRhythmAutomationV072('rhythmIntensityAutomation');bindOneRhythmAutomationV072('rhythmDensityAutomation');$('#rhythmIntensityRiseBtn').onclick=()=>setRhythmAutomationPresetV072('rhythmIntensityAutomation','rise');$('#rhythmIntensityFallBtn').onclick=()=>setRhythmAutomationPresetV072('rhythmIntensityAutomation','fall');$('#rhythmIntensityPulseBtn').onclick=()=>setRhythmAutomationPresetV072('rhythmIntensityAutomation','pulse');$('#rhythmIntensityFlatBtn').onclick=()=>setRhythmAutomationPresetV072('rhythmIntensityAutomation','flat');$('#rhythmDensityRiseBtn').onclick=()=>setRhythmAutomationPresetV072('rhythmDensityAutomation','rise');$('#rhythmDensityFallBtn').onclick=()=>setRhythmAutomationPresetV072('rhythmDensityAutomation','fall');$('#rhythmDensitySparseBtn').onclick=()=>setRhythmAutomationPresetV072('rhythmDensityAutomation','sparse');$('#rhythmDensityFlatBtn').onclick=()=>setRhythmAutomationPresetV072('rhythmDensityAutomation','flat');$('#rhythmCivilisationBtn').onclick=setCivilisationPresetV072;$('#rhythmPreviewBtn').onclick=()=>{stop();play();toast('Lecture avec automation des percussions');};}


// V0.7.10 — automation globale du tempo / BPM
let tempoAutoSelectedV073=null;
let tempoAutoDragV073=null;
let tempoMapCacheV073=null;
function invalidateTempoMapV073(){tempoMapCacheV073=null;}
function ensureTempoAutomationV073(){
  let a=state.tempoAutomation;if(!a||typeof a!=='object')a=state.tempoAutomation={enabled:false,curve:'soft',points:[{sec:0,bpm:state.bpm},{sec:state.duration,bpm:state.bpm}]};
  a.enabled=!!a.enabled;a.curve=a.curve==='linear'?'linear':'soft';let pts=Array.isArray(a.points)?a.points:[];
  pts=pts.map(p=>({sec:clamp(Number(p.sec)||0,0,state.duration),bpm:clamp(Number(p.bpm)||state.bpm,40,160)})).filter(p=>Number.isFinite(p.sec)&&Number.isFinite(p.bpm)).sort((x,y)=>x.sec-y.sec);
  if(!pts.length)pts=[{sec:0,bpm:state.bpm},{sec:state.duration,bpm:state.bpm}];const ded=[];for(const p of pts){const q=ded[ded.length-1];if(q&&Math.abs(q.sec-p.sec)<.015)q.bpm=p.bpm;else ded.push(p);}pts=ded;
  if(pts[0].sec>.001)pts.unshift({sec:0,bpm:pts[0].bpm});else pts[0].sec=0;const last=pts[pts.length-1];if(last.sec<state.duration-.001)pts.push({sec:state.duration,bpm:last.bpm});else last.sec=state.duration;a.points=pts;return a;
}
function normalizeTempoAutomationV073(){ensureTempoAutomationV073();invalidateTempoMapV073();}
function tempoBpmAtNominalSecV073(sec){const a=ensureTempoAutomationV073();return safeAutomationValueV078(a,sec,'bpm',state.bpm,40,160);}
function tempoMapV073(){
  const a=ensureTempoAutomationV073(),key=[state.bpm,state.duration,a.enabled?1:0,a.curve,state.automationSafety?.enabled!==false?1:0,state.automationSafety?.smoothingMs||150,...a.points.flatMap(p=>[p.sec,p.bpm])].join('|');if(tempoMapCacheV073?.key===key)return tempoMapCacheV073;
  const n=Math.max(240,Math.ceil(state.duration*5)),nom=new Float64Array(n+1),act=new Float64Array(n+1);nom[0]=0;act[0]=0;
  for(let i=1;i<=n;i++){const s0=state.duration*(i-1)/n,s1=state.duration*i/n,mid=(s0+s1)/2,bpm=Math.max(40,tempoBpmAtNominalSecV073(mid));nom[i]=s1;act[i]=act[i-1]+(s1-s0)*state.bpm/bpm;}
  return tempoMapCacheV073={key,nom,act,n,total:act[n]};
}
function tempoNominalToActualV073(sec){sec=clamp(sec,0,state.duration);const m=tempoMapV073(),f=sec/state.duration*m.n,i=Math.min(m.n-1,Math.max(0,Math.floor(f))),u=f-i;return m.act[i]+(m.act[i+1]-m.act[i])*u;}
function tempoActualToNominalV073(sec){const m=tempoMapV073();sec=clamp(sec,0,m.total);let lo=0,hi=m.n;while(lo+1<hi){const mid=(lo+hi)>>1;if(m.act[mid]<=sec)lo=mid;else hi=mid;}const d=Math.max(1e-9,m.act[lo+1]-m.act[lo]),u=(sec-m.act[lo])/d;return m.nom[lo]+(m.nom[lo+1]-m.nom[lo])*u;}
function tempoBeatToActualSecV073(beat){return tempoNominalToActualV073(clamp(beat*60/state.bpm,0,state.duration));}
function tempoActualDurationV073(){return tempoMapV073().total;}
function tempoSvgPointV073(evt,svg){const r=svg.getBoundingClientRect(),x=clamp((evt.clientX-r.left)/Math.max(1,r.width),0,1),y=clamp((evt.clientY-r.top)/Math.max(1,r.height),0,1);return {sec:snapAutomationSecV077(x*state.duration),bpm:160-y*120};}
function renderTempoAutomationV073(){
  const svg=$('#tempoAutomationSvg'),info=$('#tempoAutomationInfo'),del=$('#tempoAutomationDeleteBtn'),dur=$('#tempoDurationInfo');if(!svg)return;const a=ensureTempoAutomationV073();$('#tempoAutomationEnabled').checked=a.enabled;$('#tempoAutomationCurve').value=a.curve;
  const W=1000,H=260,pad=20,x=sec=>pad+(W-pad*2)*(sec/Math.max(.001,state.duration)),y=bpm=>pad+(H-pad*2)*(1-(clamp(bpm,40,160)-40)/120);let h='';for(const bpm of [40,70,100,130,160])h+=`<line x1="${pad}" y1="${y(bpm)}" x2="${W-pad}" y2="${y(bpm)}" class="auto-grid"/>`;for(let sec=0;sec<=state.duration+.01;sec+=Math.max(10,state.duration/6))h+=`<line x1="${x(sec)}" y1="${pad}" x2="${x(sec)}" y2="${H-pad}" class="auto-grid auto-grid-v"/>`;
  const samples=[];for(let i=0;i<=160;i++){const sec=state.duration*i/160;samples.push(`${x(sec).toFixed(1)},${y(tempoBpmAtNominalSecV073(sec)).toFixed(1)}`);}h+=`<polyline points="${samples.join(' ')}" class="auto-curve ${a.enabled?'':'disabled'}"/>`;a.points.forEach((p,i)=>{const sel=i===tempoAutoSelectedV073;h+=`<circle data-tempo-point="${i}" cx="${x(p.sec)}" cy="${y(p.bpm)}" r="${sel?13:11}" class="auto-point ${sel?'selected':''}"/>`;});svg.innerHTML=h;
  const pt=a.points[tempoAutoSelectedV073];if(info)info.textContent=pt?`Point ${tempoAutoSelectedV073+1}/${a.points.length} • ${pt.sec.toFixed(1)} s • ${pt.bpm.toFixed(1)} BPM`:`${a.enabled?'Active':'Inactive'} • base ${state.bpm} BPM • ${a.points.length} points.`;if(del)del.disabled=tempoAutoSelectedV073==null||tempoAutoSelectedV073<=0||tempoAutoSelectedV073>=a.points.length-1;if(dur)dur.textContent=`Durée réelle : ${tempoActualDurationV073().toFixed(1)} s • grille : ${state.duration} s`;
}
function setTempoPresetV073(kind){mutate(()=>{const a=ensureTempoAutomationV073(),d=state.duration,b=state.bpm;a.enabled=true;if(kind==='morning')a.points=[{sec:0,bpm:70},{sec:d*.38,bpm:72},{sec:d*.72,bpm:76},{sec:d,bpm:78}];else if(kind==='rise')a.points=[{sec:0,bpm:clamp(b-5,40,160)},{sec:d*.5,bpm:b},{sec:d,bpm:clamp(b+8,40,160)}];else if(kind==='fall')a.points=[{sec:0,bpm:clamp(b+8,40,160)},{sec:d*.5,bpm:b},{sec:d,bpm:clamp(b-5,40,160)}];else if(kind==='wave')a.points=[{sec:0,bpm:b},{sec:d*.28,bpm:clamp(b+4,40,160)},{sec:d*.55,bpm:clamp(b-2,40,160)},{sec:d*.8,bpm:clamp(b+5,40,160)},{sec:d,bpm:b}];else a.points=[{sec:0,bpm:b},{sec:d,bpm:b}];});invalidateTempoMapV073();tempoAutoSelectedV073=null;renderTempoAutomationV073();}
function bindTempoAutomationV073(){const svg=$('#tempoAutomationSvg');if(!svg)return;$('#tempoAutomationEnabled').onchange=e=>{mutate(()=>ensureTempoAutomationV073().enabled=e.target.checked);invalidateTempoMapV073();renderTempoAutomationV073();};$('#tempoAutomationCurve').onchange=e=>{mutate(()=>ensureTempoAutomationV073().curve=e.target.value);invalidateTempoMapV073();renderTempoAutomationV073();};$('#tempoMorningBtn').onclick=()=>setTempoPresetV073('morning');$('#tempoRiseBtn').onclick=()=>setTempoPresetV073('rise');$('#tempoFallBtn').onclick=()=>setTempoPresetV073('fall');$('#tempoWaveBtn').onclick=()=>setTempoPresetV073('wave');$('#tempoFlatBtn').onclick=()=>setTempoPresetV073('flat');$('#tempoPreviewBtn').onclick=()=>{stop();play();toast('Lecture avec automation du tempo');};$('#tempoAutomationDeleteBtn').onclick=()=>{const a=ensureTempoAutomationV073(),i=tempoAutoSelectedV073;if(i==null||i<=0||i>=a.points.length-1)return;mutate(()=>a.points.splice(i,1));invalidateTempoMapV073();tempoAutoSelectedV073=null;renderTempoAutomationV073();};
  svg.addEventListener('pointerdown',e=>{const a=ensureTempoAutomationV073(),circle=e.target.closest?.('[data-tempo-point]');if(circle){const i=+circle.dataset.tempoPoint;tempoAutoSelectedV073=i;setLastAutoSelectionV077('tempo');tempoAutoDragV073={i,before:snapshot(),pid:e.pointerId};circle.setPointerCapture?.(e.pointerId);renderTempoAutomationV073();e.preventDefault();return;}const p=tempoSvgPointV073(e,svg);mutate(()=>{a.enabled=true;a.points.push(p);a.points.sort((x,y)=>x.sec-y.sec);});invalidateTempoMapV073();tempoAutoSelectedV073=ensureTempoAutomationV073().points.findIndex(q=>Math.abs(q.sec-p.sec)<.02&&Math.abs(q.bpm-p.bpm)<.2);setLastAutoSelectionV077('tempo');renderTempoAutomationV073();e.preventDefault();});
  window.addEventListener('pointermove',e=>{if(!tempoAutoDragV073||e.pointerId!==tempoAutoDragV073.pid)return;const a=ensureTempoAutomationV073(),i=tempoAutoDragV073.i,p=tempoSvgPointV073(e,svg);if(!a.points[i])return;a.enabled=true;a.points[i].bpm=clamp(p.bpm,40,160);if(i>0&&i<a.points.length-1){const lo=a.points[i-1].sec+.05,hi=a.points[i+1].sec-.05;a.points[i].sec=clamp(p.sec,lo,hi);}invalidateTempoMapV073();markDirty();renderTempoAutomationV073();e.preventDefault();});const end=e=>{if(!tempoAutoDragV073||e.pointerId!==tempoAutoDragV073.pid)return;state.history.push(tempoAutoDragV073.before);if(state.history.length>60)state.history.shift();state.future=[];tempoAutoDragV073=null;renderTempoAutomationV073();};window.addEventListener('pointerup',end);window.addEventListener('pointercancel',end);
}


// V0.7.4 + V0.7.10 — presets optionnels, OFF explicite et stabilisation UX
function automationTrackActiveCountV075(t){
  if(!t)return 0;return [ensureVolumeAutomationV070(t),ensureEffectAutomationV071(t,'filterAutomation'),ensureEffectAutomationV071(t,'reverbAutomation')].filter(a=>a?.enabled).length;
}
function automationActiveCountV075(){
  let n=state.tracks.reduce((sum,t)=>sum+automationTrackActiveCountV075(t),0);
  if(ensureRhythmAutomationV072('rhythmIntensityAutomation').enabled)n++;
  if(ensureRhythmAutomationV072('rhythmDensityAutomation').enabled)n++;
  if(ensureTempoAutomationV073().enabled)n++;
  normalizeAutomationGroupsV077();
  for(const g of state.automationGroups||[])n+=busHolderActiveCountV077(g);
  n+=busHolderActiveCountV077(state.masterBusAutomation);
  return n;
}
function renderAutomationHubV075(){
  const badge=$('#automationActiveCount');if(!badge)return;const n=automationActiveCountV075();badge.textContent=n?`${n} ACTIVE${n>1?'S':''}`:'0 ACTIVE • SON STATIQUE';badge.className=n?'automation-on-pill':'automation-off-pill';
  const t=currentTrack(),trackBtn=$('#automationDisableTrackBtn');if(trackBtn){const c=automationTrackActiveCountV075(t);trackBtn.textContent=t?`OFF ${t.name} (${c})`:'OFF piste sélectionnée';trackBtn.disabled=!t||!c;}
  const cards=[['#volumeAutomationSvg',t?.volumeAutomation?.enabled],['#filterAutomationSvg',t?.filterAutomation?.enabled],['#reverbAutomationSvg',t?.reverbAutomation?.enabled],['#rhythmIntensitySvg',state.rhythmIntensityAutomation?.enabled],['#rhythmDensitySvg',state.rhythmDensityAutomation?.enabled],['#tempoAutomationSvg',state.tempoAutomation?.enabled]];
  for(const [sel,on] of cards){const card=$(sel)?.closest('.automation-card');if(card)card.classList.toggle('auto-inactive',!on);}
}
function setTrackAutomationShapeV075(t,key,points){
  if(!t)return;let a;if(key==='volumeAutomation')a=ensureVolumeAutomationV070(t);else a=ensureEffectAutomationV071(t,key);a.enabled=true;a.curve='soft';a.points=points.map(p=>({sec:clamp(p[0]*state.duration,0,state.duration),value:clamp(p[1],0,1)}));
}
function setGlobalRhythmShapeV075(key,points){const a=ensureRhythmAutomationV072(key);a.enabled=true;a.curve='soft';a.points=points.map(p=>({sec:clamp(p[0]*state.duration,0,state.duration),value:clamp(p[1],0,1)}));}
function setTempoShapeV075(points){const a=ensureTempoAutomationV073();a.enabled=true;a.curve='soft';a.points=points.map(p=>({sec:clamp(p[0]*state.duration,0,state.duration),bpm:clamp(p[1],40,160)}));invalidateTempoMapV073();}
function presetTrackShapesV075(kind,t){
  const shapes={
    morning:{v:[[0,.35],[.45,.62],[1,1]],f:[[0,.45],[.55,.72],[1,1]],r:[[0,.38],[.5,.28],[1,.22]]},
    calm:{v:[[0,1],[.55,.85],[1,.68]],f:[[0,.9],[.55,.65],[1,.42]],r:[[0,.25],[.55,.48],[1,.72]]},
    civilisation:{v:[[0,.58],[.5,.78],[1,1]],f:[[0,.7],[.55,.86],[1,1]],r:[[0,.24],[.6,.34],[1,.44]]},
    dusk:{v:[[0,1],[.55,.9],[1,.76]],f:[[0,1],[.5,.72],[1,.42]],r:[[0,.22],[.5,.46],[1,.72]]},
    disappear:{v:[[0,1],[.7,.62],[1,0]],f:[[0,.82],[.7,.5],[1,.24]],r:[[0,.32],[.65,.62],[1,1]]},
    tension:{v:[[0,.72],[.3,.86],[.58,.76],[.82,.94],[1,.84]],f:[[0,.55],[.28,.84],[.55,.58],[.8,.94],[1,.68]],r:[[0,.18],[.35,.36],[.65,.24],[1,.42]]}
  }[kind];if(!shapes)return;setTrackAutomationShapeV075(t,'volumeAutomation',shapes.v);setTrackAutomationShapeV075(t,'filterAutomation',shapes.f);setTrackAutomationShapeV075(t,'reverbAutomation',shapes.r);
}
function presetGlobalShapesV075(kind){const b=state.bpm;
  if(kind==='morning'){setGlobalRhythmShapeV075('rhythmIntensityAutomation',[[0,.18],[.55,.42],[1,.7]]);setGlobalRhythmShapeV075('rhythmDensityAutomation',[[0,.22],[.6,.45],[1,.68]]);setTempoShapeV075([[0,70],[.38,72],[.72,76],[1,78]]);}
  else if(kind==='calm'){setGlobalRhythmShapeV075('rhythmIntensityAutomation',[[0,.65],[.55,.42],[1,.2]]);setGlobalRhythmShapeV075('rhythmDensityAutomation',[[0,.62],[.6,.4],[1,.22]]);setTempoShapeV075([[0,clamp(b+2,40,160)],[.55,b],[1,clamp(b-5,40,160)]]);}
  else if(kind==='civilisation'){setGlobalRhythmShapeV075('rhythmIntensityAutomation',[[0,.05],[.35,.22],[.7,.58],[1,1]]);setGlobalRhythmShapeV075('rhythmDensityAutomation',[[0,.1],[.4,.28],[.72,.62],[1,1]]);}
  else if(kind==='dusk'){setGlobalRhythmShapeV075('rhythmIntensityAutomation',[[0,.62],[.55,.44],[1,.24]]);setGlobalRhythmShapeV075('rhythmDensityAutomation',[[0,.58],[.6,.4],[1,.28]]);setTempoShapeV075([[0,b],[.55,clamp(b-2,40,160)],[1,clamp(b-5,40,160)]]);}
  else if(kind==='disappear'){setGlobalRhythmShapeV075('rhythmIntensityAutomation',[[0,.62],[.65,.3],[1,0]]);setGlobalRhythmShapeV075('rhythmDensityAutomation',[[0,.55],[.68,.28],[1,.05]]);setTempoShapeV075([[0,b],[.7,clamp(b-3,40,160)],[1,clamp(b-7,40,160)]]);}
  else if(kind==='tension'){setGlobalRhythmShapeV075('rhythmIntensityAutomation',[[0,.32],[.28,.66],[.55,.42],[.8,.82],[1,.58]]);setGlobalRhythmShapeV075('rhythmDensityAutomation',[[0,.4],[.3,.7],[.58,.5],[.82,.82],[1,.62]]);setTempoShapeV075([[0,b],[.28,clamp(b+4,40,160)],[.55,clamp(b-1,40,160)],[.82,clamp(b+6,40,160)],[1,b]]);}
}
function applyAutomationPresetV075(kind){
  const scope=$('#automationPresetScope')?.value||'current';const t=currentTrack();if(scope==='current'&&!t)return toast('Choisis une piste');
  mutate(()=>{if(scope==='current')presetTrackShapesV075(kind,t);else if(scope==='all'){state.tracks.forEach(x=>presetTrackShapesV075(kind,x));presetGlobalShapesV075(kind);}else presetGlobalShapesV075(kind);});
  invalidateTempoMapV073();renderAll();const labels={morning:'Réveil progressif',calm:'Apaisement',civilisation:'Montée civilisation',dusk:'Crépuscule',disappear:'Disparition',tension:'Tension légère'};toast(`${labels[kind]||kind} • preset appliqué volontairement`);
}
function disableTrackAutomationsV075(){const t=currentTrack();if(!t)return;mutate(()=>{ensureVolumeAutomationV070(t).enabled=false;ensureEffectAutomationV071(t,'filterAutomation').enabled=false;ensureEffectAutomationV071(t,'reverbAutomation').enabled=false;});renderAll();toast('Automations de la piste désactivées • réglages fixes restaurés');}
function disableAllAutomationsV075(){
  mutate(()=>{for(const t of state.tracks){ensureVolumeAutomationV070(t).enabled=false;ensureEffectAutomationV071(t,'filterAutomation').enabled=false;ensureEffectAutomationV071(t,'reverbAutomation').enabled=false;}ensureRhythmAutomationV072('rhythmIntensityAutomation').enabled=false;ensureRhythmAutomationV072('rhythmDensityAutomation').enabled=false;ensureTempoAutomationV073().enabled=false;for(const g of state.automationGroups||[])disableBusHolderV077(g);disableBusHolderV077(state.masterBusAutomation);});
  invalidateTempoMapV073();renderAll();toast('Toutes les automations sont OFF • son statique');
}
function bindAutomationHubV075(){
  $$('.automation-preset').forEach(b=>b.addEventListener('click',()=>applyAutomationPresetV075(b.dataset.autoPreset)));
  $('#automationDisableTrackBtn')?.addEventListener('click',disableTrackAutomationsV075);
  $('#automationDisableAllBtn')?.addEventListener('click',disableAllAutomationsV075);
  renderAutomationHubV075();
}


// V0.7.6 + V0.7.10 — vrais groupes/master + éditeur tactile précis
let busAutomationTargetV077='master',busAutomationParamV077='volumeAutomation',busAutoSelectedV077=null,busAutoDragV077=null;
let lastAutoSelectionV077=null;
function freshBusAutomationV077(kind='normal'){return {enabled:false,curve:'soft',points:[{sec:0,value:kind==='reverb'?0:1},{sec:state.duration,value:kind==='reverb'?0:1}]};}
function normalizeBusHolderV077(h){if(!h)return;for(const key of ['volumeAutomation','filterAutomation','reverbAutomation']){if(!h[key]||typeof h[key]!=='object')h[key]=freshBusAutomationV077(key==='reverbAutomation'?'reverb':'normal');ensureEffectAutomationV071(h,key);if(key==='reverbAutomation'&&!h[key].enabled&&h[key].points.every(p=>p.value===1))h[key].points=[{sec:0,value:0},{sec:state.duration,value:0}];}}
function normalizeAutomationGroupsV077(){if(!Array.isArray(state.automationGroups))state.automationGroups=[];const valid=new Set(state.tracks.map(t=>t.id)),used=new Set();state.automationGroups=state.automationGroups.map((g,i)=>{g.id=g.id||uid();g.name=g.name||`Groupe ${i+1}`;g.enabled=g.enabled!==false;g.trackIds=(Array.isArray(g.trackIds)?g.trackIds:[]).filter(id=>valid.has(id)&&!used.has(id));g.trackIds.forEach(id=>used.add(id));normalizeBusHolderV077(g);return g;});if(!state.masterBusAutomation)state.masterBusAutomation={};normalizeBusHolderV077(state.masterBusAutomation);}
function busHolderActiveCountV077(h){if(!h)return 0;normalizeBusHolderV077(h);return ['volumeAutomation','filterAutomation','reverbAutomation'].filter(k=>h[k]?.enabled).length;}
function disableBusHolderV077(h){if(!h)return;normalizeBusHolderV077(h);for(const k of ['volumeAutomation','filterAutomation','reverbAutomation'])h[k].enabled=false;}
function automationGroupForTrackV077(t){normalizeAutomationGroupsV077();return state.automationGroups.find(g=>g.enabled!==false&&g.trackIds.includes(t.id))||null;}
function currentBusHolderV077(){normalizeAutomationGroupsV077();if(busAutomationTargetV077==='master')return state.masterBusAutomation;return state.automationGroups.find(g=>g.id===busAutomationTargetV077)||state.masterBusAutomation;}
function currentBusAutomationV077(){const h=currentBusHolderV077();normalizeBusHolderV077(h);return h[busAutomationParamV077];}
function busAutomationValueAtV077(holder,key,sec){normalizeBusHolderV077(holder);const a=holder[key],fallback=key==='reverbAutomation'?0:1;return safeAutomationValueV078(a,sec,'value',fallback,0,1);}
function scheduleBusGainV077(param,holder,when,totalSec,base=1){normalizeBusHolderV077(holder);const a=holder.volumeAutomation;try{param.cancelScheduledValues(when);}catch{}if(!a.enabled){param.setValueAtTime(base,when);return;}scheduleNormalizedBusParamV077(param,a,when,totalSec,v=>Math.max(.0001,base*v));}
function scheduleBusFilterV077(param,holder,when,totalSec){normalizeBusHolderV077(holder);const a=holder.filterAutomation;try{param.cancelScheduledValues(when);}catch{}if(!a.enabled){param.setValueAtTime(20000,when);return;}scheduleNormalizedBusParamV077(param,a,when,totalSec,v=>filterHzFromNormV071(20000,v));}
function scheduleBusReverbV077(param,holder,when,totalSec){normalizeBusHolderV077(holder);const a=holder.reverbAutomation;try{param.cancelScheduledValues(when);}catch{}if(!a.enabled){param.setValueAtTime(.00001,when);return;}scheduleNormalizedBusParamV077(param,a,when,totalSec,v=>Math.max(.00001,.42*v));}
function scheduleNormalizedBusParamV077(param,a,when,totalSec,map){if(scheduleSafeAutomationV078(param,a,when,totalSec,map,sec=>safeAutomationValueV078(a,sec,'value',1,0,1)))return;const pts=a.points.map(p=>({sec:clamp(p.sec,0,totalSec),value:clamp(p.value,0,1)})).filter((p,i,x)=>!i||p.sec>x[i-1].sec+.0005);if(!pts.length){param.setValueAtTime(map(1),when);return;}param.setValueAtTime(map(pts[0].value),when+tempoNominalToActualV073(pts[0].sec));for(let i=1;i<pts.length;i++){const p0=pts[i-1],p1=pts[i],d=p1.sec-p0.sec;if(d<=.001)continue;if(a.curve==='linear')param.linearRampToValueAtTime(map(p1.value),when+tempoNominalToActualV073(p1.sec));else for(let j=1;j<=18;j++){const u=j/18,k=(1-Math.cos(Math.PI*u))/2;param.linearRampToValueAtTime(map(p0.value+(p1.value-p0.value)*k),when+tempoNominalToActualV073(p0.sec+d*u));}}}
function busReverbNeededV0813(holder){normalizeBusHolderV077(holder);const a=holder?.reverbAutomation;if(!a?.enabled)return false;return (a.points||[]).some(p=>Number(p.value)>.001);}
function createBusNodeV077(ctx,dest,holder,when,impulse,baseGain=1){const input=ctx.createGain(),gain=ctx.createGain();scheduleBusGainV077(gain.gain,holder,when,state.duration,baseGain);input.connect(gain);const f=ctx.createBiquadFilter();f.type='lowpass';f.Q.value=.18;scheduleBusFilterV077(f.frequency,holder,when,state.duration);gain.connect(f);f.connect(dest);if(busReverbNeededV0813(holder)){const rev=ctx.createConvolver();rev.buffer=impulse;const rg=ctx.createGain();scheduleBusReverbV077(rg.gain,holder,when,state.duration);f.connect(rev);rev.connect(rg);rg.connect(dest);}return input;}
function renderAutomationGroupsV077(){normalizeAutomationGroupsV077();const sel=$('#busAutomationTarget');if(!sel)return;const prev=busAutomationTargetV077;sel.innerHTML='<option value="master">MASTER</option>'+state.automationGroups.map(g=>`<option value="${g.id}">${esc(g.name)}</option>`).join('');if(prev!=='master'&&!state.automationGroups.some(g=>g.id===prev))busAutomationTargetV077='master';sel.value=busAutomationTargetV077;$('#busAutomationParam').value=busAutomationParamV077;const holder=currentBusHolderV077(),a=currentBusAutomationV077();$('#busAutomationEnabled').checked=!!a.enabled;$('#busAutomationCurve').value=a.curve;const group=busAutomationTargetV077==='master'?null:state.automationGroups.find(g=>g.id===busAutomationTargetV077);const names=group?group.trackIds.map(id=>state.tracks.find(t=>t.id===id)?.name).filter(Boolean):[];$('#automationGroupMembers').textContent=group?`${group.name} : ${names.length?names.join(' • '):'aucune piste'}`:'MASTER : toutes les pistes + rythme.';$('#automationGroupRenameBtn').disabled=!group;$('#automationGroupAddTrackBtn').disabled=!group||!currentTrack();$('#automationGroupRemoveTrackBtn').disabled=!group||!currentTrack()||!group.trackIds.includes(currentTrack().id);$('#automationGroupDeleteBtn').disabled=!group;const status=$('#busAutomationStatus');status.textContent=`${group?group.name:'MASTER'} • ${busHolderActiveCountV077(holder)?busHolderActiveCountV077(holder)+' ACTIVE':'OFF'}`;status.className=busHolderActiveCountV077(holder)?'automation-on-pill':'automation-off-pill';renderBusGraphV077();}
function renderBusGraphV077(){const svg=$('#busAutomationSvg'),info=$('#busAutomationPointInfo'),del=$('#busAutomationDeletePointBtn');if(!svg)return;const h=currentBusHolderV077(),a=currentBusAutomationV077(),W=1000,H=260,pad=20,x=s=>pad+(W-pad*2)*(s/Math.max(.001,state.duration)),y=v=>pad+(H-pad*2)*(1-v);let out='';for(const v of [0,.25,.5,.75,1])out+=`<line x1="${pad}" y1="${y(v)}" x2="${W-pad}" y2="${y(v)}" class="auto-grid"/>`;for(let sec=0;sec<=state.duration+.01;sec+=Math.max(10,state.duration/6))out+=`<line x1="${x(sec)}" y1="${pad}" x2="${x(sec)}" y2="${H-pad}" class="auto-grid auto-grid-v"/>`;const samples=[];for(let i=0;i<=120;i++){const sec=state.duration*i/120;samples.push(`${x(sec).toFixed(1)},${y(busAutomationValueAtV077(h,busAutomationParamV077,sec)).toFixed(1)}`);}out+=`<polyline points="${samples.join(' ')}" class="auto-curve ${a.enabled?'':'disabled'}"/>`;a.points.forEach((p,i)=>{const sel=i===busAutoSelectedV077;out+=`<circle data-bus-point="${i}" cx="${x(p.sec)}" cy="${y(p.value)}" r="${sel?13:11}" class="auto-point ${sel?'selected':''}"/>`;});svg.innerHTML=out;const p=a.points[busAutoSelectedV077];if(info)info.textContent=p?`Point ${busAutoSelectedV077+1}/${a.points.length} • ${p.sec.toFixed(1)} s • ${Math.round(p.value*100)}%`:`${a.enabled?'Active':'Inactive'} • ${a.points.length} points`;if(del)del.disabled=busAutoSelectedV077==null||busAutoSelectedV077<=0||busAutoSelectedV077>=a.points.length-1;applyAutomationZoomV077();}
function setBusPresetV077(kind){mutate(()=>{const a=currentBusAutomationV077(),d=state.duration;a.enabled=true;a.curve='soft';if(kind==='rise')a.points=[{sec:0,value:.25},{sec:d*.5,value:.62},{sec:d,value:1}];else if(kind==='fall')a.points=[{sec:0,value:1},{sec:d*.5,value:.62},{sec:d,value:.25}];else if(kind==='wave')a.points=[{sec:0,value:.42},{sec:d*.3,value:.82},{sec:d*.58,value:.46},{sec:d*.82,value:.88},{sec:d,value:.55}];else a.points=[{sec:0,value:busAutomationParamV077==='reverbAutomation'?0:1},{sec:d,value:busAutomationParamV077==='reverbAutomation'?0:1}];});busAutoSelectedV077=null;renderAutomationGroupsV077();renderAutomationHubV075();}
function bindAutomationGroupsV077(){const svg=$('#busAutomationSvg');if(!svg)return;$('#busAutomationTarget').onchange=e=>{busAutomationTargetV077=e.target.value;busAutoSelectedV077=null;renderAutomationGroupsV077();};$('#busAutomationParam').onchange=e=>{busAutomationParamV077=e.target.value;busAutoSelectedV077=null;renderAutomationGroupsV077();};$('#busAutomationEnabled').onchange=e=>{mutate(()=>currentBusAutomationV077().enabled=e.target.checked);renderAll();};$('#busAutomationCurve').onchange=e=>{mutate(()=>currentBusAutomationV077().curve=e.target.value);renderAutomationGroupsV077();};$('#busAutomationRiseBtn').onclick=()=>setBusPresetV077('rise');$('#busAutomationFallBtn').onclick=()=>setBusPresetV077('fall');$('#busAutomationWaveBtn').onclick=()=>setBusPresetV077('wave');$('#busAutomationFlatBtn').onclick=()=>setBusPresetV077('flat');$('#busAutomationPreviewBtn').onclick=()=>{stop();play();toast('Lecture avec automation groupe/master');};$('#automationGroupCreateBtn').onclick=()=>{const name=(prompt('Nom du groupe',`Groupe ${state.automationGroups.length+1}`)||'').trim();if(!name)return;mutate(()=>{const g={id:uid(),name,enabled:true,trackIds:[]};normalizeBusHolderV077(g);state.automationGroups.push(g);busAutomationTargetV077=g.id;});renderAll();};$('#automationGroupRenameBtn').onclick=()=>{const g=state.automationGroups.find(x=>x.id===busAutomationTargetV077);if(!g)return;const n=(prompt('Nouveau nom',g.name)||'').trim();if(n)mutate(()=>g.name=n);renderAll();};$('#automationGroupDeleteBtn').onclick=()=>{const g=state.automationGroups.find(x=>x.id===busAutomationTargetV077);if(!g||!confirm(`Supprimer ${g.name} ? Les pistes restent intactes.`))return;mutate(()=>state.automationGroups=state.automationGroups.filter(x=>x.id!==g.id));busAutomationTargetV077='master';renderAll();};$('#automationGroupAddTrackBtn').onclick=()=>{const g=state.automationGroups.find(x=>x.id===busAutomationTargetV077),t=currentTrack();if(!g||!t)return;mutate(()=>{for(const x of state.automationGroups)x.trackIds=x.trackIds.filter(id=>id!==t.id);g.trackIds.push(t.id);});renderAll();};$('#automationGroupRemoveTrackBtn').onclick=()=>{const g=state.automationGroups.find(x=>x.id===busAutomationTargetV077),t=currentTrack();if(!g||!t)return;mutate(()=>g.trackIds=g.trackIds.filter(id=>id!==t.id));renderAll();};$('#busAutomationDeletePointBtn').onclick=()=>deleteBusPointV077();svg.addEventListener('pointerdown',e=>{const a=currentBusAutomationV077(),circle=e.target.closest?.('[data-bus-point]');if(circle){const i=+circle.dataset.busPoint;busAutoSelectedV077=i;lastAutoSelectionV077={type:'bus'};busAutoDragV077={i,before:snapshot(),pid:e.pointerId};circle.setPointerCapture?.(e.pointerId);renderBusGraphV077();renderAutomationPrecisionV077();e.preventDefault();return;}const p=automationSvgPointV070(e,svg);mutate(()=>{a.enabled=true;a.points.push(p);a.points.sort((x,y)=>x.sec-y.sec);});busAutoSelectedV077=a.points.findIndex(q=>Math.abs(q.sec-p.sec)<.02&&Math.abs(q.value-p.value)<.02);lastAutoSelectionV077={type:'bus'};renderBusGraphV077();renderAutomationPrecisionV077();e.preventDefault();});window.addEventListener('pointermove',e=>{if(!busAutoDragV077||e.pointerId!==busAutoDragV077.pid)return;const a=currentBusAutomationV077(),i=busAutoDragV077.i,p=automationSvgPointV070(e,svg);if(!a.points[i])return;a.enabled=true;a.points[i].value=p.value;if(i>0&&i<a.points.length-1)a.points[i].sec=clamp(p.sec,a.points[i-1].sec+.05,a.points[i+1].sec-.05);markDirty();renderBusGraphV077();e.preventDefault();});const end=e=>{if(!busAutoDragV077||e.pointerId!==busAutoDragV077.pid)return;state.history.push(busAutoDragV077.before);state.future=[];busAutoDragV077=null;renderAll();};window.addEventListener('pointerup',end);window.addEventListener('pointercancel',end);}
function deleteBusPointV077(){const a=currentBusAutomationV077(),i=busAutoSelectedV077;if(i==null||i<=0||i>=a.points.length-1)return;mutate(()=>a.points.splice(i,1));busAutoSelectedV077=null;lastAutoSelectionV077=null;renderAll();}
function snapAutomationSecV077(sec){const snap=Number(state.automationEditor?.snap||0);return clamp(snap>0?Math.round(sec/snap)*snap:sec,0,state.duration);}
function applyAutomationZoomV077(){const z=Number(state.automationEditor?.zoom||1);$$('.automation-graph').forEach(svg=>{svg.style.width=`${z*100}%`;svg.style.minWidth=`${z*100}%`;});}
function setLastAutoSelectionV077(type,key=null){lastAutoSelectionV077={type,key};renderAutomationPrecisionV077();}
function getSelectedAutomationPointV077(){const t=currentTrack();if(!lastAutoSelectionV077)return null;let a,i,kind='value';const x=lastAutoSelectionV077;if(x.type==='volume'){a=ensureVolumeAutomationV070(t);i=volumeAutomationSelectedV070;}else if(x.type==='fx'){a=ensureEffectAutomationV071(t,x.key);i=effectAutoSelectedV071[x.key];}else if(x.type==='rhythm'){a=ensureRhythmAutomationV072(x.key);i=rhythmAutoSelectedV072[x.key];}else if(x.type==='tempo'){a=ensureTempoAutomationV073();i=tempoAutoSelectedV073;kind='bpm';}else if(x.type==='bus'){a=currentBusAutomationV077();i=busAutoSelectedV077;}if(!a||i==null||!a.points[i])return null;return {a,i,p:a.points[i],kind};}
function renderAutomationPrecisionV077(){if(!state.automationEditor)state.automationEditor={zoom:1,snap:1};const z=$('#automationEditorZoom'),s=$('#automationEditorSnap');if(z)z.value=String(state.automationEditor.zoom||1);if(s)s.value=String(state.automationEditor.snap??1);applyAutomationZoomV077();const hit=getSelectedAutomationPointV077(),info=$('#automationPrecisionInfo');if(info)info.innerHTML=hit?`<b>Point sélectionné :</b> ${hit.p.sec.toFixed(1)} s • ${hit.kind==='bpm'?Math.round(hit.p.bpm)+' BPM':Math.round(hit.p.value*100)+'%'}`:'<b>Précision :</b> touche d’abord un point sur n’importe quelle courbe. Le snap ne change jamais une courbe tant que tu ne déplaces pas un point.';for(const id of ['automationNudgeLeftBtn','automationNudgeRightBtn','automationNudgeDownBtn','automationNudgeUpBtn','automationDuplicatePointBtn','automationDeleteSelectedPointBtn']){const b=$('#'+id);if(b)b.disabled=!hit;}}
function nudgeSelectedAutomationV077(dt=0,dv=0){const hit=getSelectedAutomationPointV077();if(!hit)return;mutate(()=>{const {a,i,p,kind}=hit;if(dt&&i>0&&i<a.points.length-1){const step=Number(state.automationEditor?.snap||1)||1;p.sec=clamp(snapAutomationSecV077(p.sec+dt*step),a.points[i-1].sec+.05,a.points[i+1].sec-.05);}if(dv){if(kind==='bpm')p.bpm=clamp(p.bpm+dv*2,40,160);else p.value=clamp(p.value+dv*.05,0,1);}});invalidateTempoMapV073();renderAll();}
function duplicateSelectedAutomationPointV077(){const hit=getSelectedAutomationPointV077();if(!hit||hit.i<=0||hit.i>=hit.a.points.length-1)return toast('Choisis un point intermédiaire');mutate(()=>{const step=Number(state.automationEditor?.snap||1)||1,next=hit.a.points[hit.i+1],copy={...hit.p,sec:clamp(snapAutomationSecV077(hit.p.sec+step),hit.p.sec+.05,next.sec-.05)};hit.a.points.splice(hit.i+1,0,copy);});renderAll();}
function deleteSelectedAutomationPointV077(){const hit=getSelectedAutomationPointV077();if(!hit||hit.i<=0||hit.i>=hit.a.points.length-1)return toast('Les points début/fin sont protégés');mutate(()=>hit.a.points.splice(hit.i,1));lastAutoSelectionV077=null;volumeAutomationSelectedV070=null;effectAutoSelectedV071.filterAutomation=effectAutoSelectedV071.reverbAutomation=null;rhythmAutoSelectedV072.rhythmIntensityAutomation=rhythmAutoSelectedV072.rhythmDensityAutomation=null;tempoAutoSelectedV073=null;busAutoSelectedV077=null;renderAll();}
function bindAutomationPrecisionV077(){if(!state.automationEditor)state.automationEditor={zoom:1,snap:1};$('#automationEditorZoom').onchange=e=>{state.automationEditor.zoom=+e.target.value||1;markDirty();renderAutomationPrecisionV077();};$('#automationEditorSnap').onchange=e=>{state.automationEditor.snap=+e.target.value||0;markDirty();renderAutomationPrecisionV077();};$('#automationNudgeLeftBtn').onclick=()=>nudgeSelectedAutomationV077(-1,0);$('#automationNudgeRightBtn').onclick=()=>nudgeSelectedAutomationV077(1,0);$('#automationNudgeDownBtn').onclick=()=>nudgeSelectedAutomationV077(0,-1);$('#automationNudgeUpBtn').onclick=()=>nudgeSelectedAutomationV077(0,1);$('#automationDuplicatePointBtn').onclick=duplicateSelectedAutomationPointV077;$('#automationDeleteSelectedPointBtn').onclick=deleteSelectedAutomationPointV077;renderAutomationPrecisionV077();}

function renderMixer(){els.mixer.innerHTML='';state.tracks.forEach(t=>{const c=document.createElement('div');c.className='channel';c.style.setProperty('--track-color',t.color);c.innerHTML=`<div class="channel-head"><strong>${esc(t.name)}</strong><div class="channel-controls"><button class="mute ${t.mute?'active':''}">M</button><button class="solo ${t.solo?'active':''}">S</button></div></div><label>Volume<input type="range" min="0" max="1" step=".01" value="${t.volume}"></label><label>Pan<input class="p" type="range" min="-1" max="1" step=".01" value="${t.pan}"></label>`;const [v,p]=c.querySelectorAll('input');v.oninput=()=>{t.volume=+v.value;markDirty();};p.oninput=()=>{t.pan=+p.value;markDirty();};c.querySelector('.mute').onclick=()=>{t.mute=!t.mute;markDirty();renderAll();};c.querySelector('.solo').onclick=()=>{t.solo=!t.solo;markDirty();renderAll();};els.mixer.appendChild(c);});}
function chordMidisV0810(root,type){const ints=CHORD_INTERVALS[type]||CHORD_INTERVALS.maj;let base=48+(Number(root)||0);if(base>59)base-=12;while(base<48)base+=12;return ints.map(i=>base+i).filter(m=>m>=48&&m<=83);}
async function previewChordV0810(){const t=currentTrack();if(!t)return;const ctx=ensureAudio();await ctx.resume();const midis=chordMidisV0810(+els.chordRoot.value,els.chordType.value);for(const m of midis)await preloadTrackSamples(t,ctx,null,m,.68);const g=ctx.createGain(),p=PRESETS[t.instrument]||{};g.gain.value=Math.max(.12,t.volume)*(p.mixTrim??1);const pan=ctx.createStereoPanner?ctx.createStereoPanner():null;if(pan){pan.pan.value=t.pan;g.connect(pan);connectSafePreviewV0813(ctx,pan);}else connectSafePreviewV0813(ctx,g);const at=ctx.currentTime+.035;midis.forEach(m=>scheduleVoice(ctx,g,at,1.7,m,.68,t));toast(`${NOTE_NAMES[+els.chordRoot.value]}${els.chordType.value} • ${midis.map(m=>NOTE_NAMES[m%12]+(Math.floor(m/12)-1)).join(' ')}`);}
function nextFreeMeasureBeatV08158(t){const notes=Array.isArray(t?.notes)?t.notes:[];if(!notes.length)return 0;let maxEnd=0;for(const n of notes){const b=Math.max(0,+n.beat||0),d=Math.max(.001,+n.dur||state.grid||.5);maxEnd=Math.max(maxEnd,b+d);}const lastOccupiedBar=Math.floor(Math.max(0,maxEnd-1e-6)/4);return (lastOccupiedBar+1)*4;}
function insertChordV0810(){const t=currentTrack();if(!t)return;const midis=chordMidisV0810(+els.chordRoot.value,els.chordType.value);const beat=nextFreeMeasureBeatV08158(t),dur=4,neededBars=Math.ceil((beat+dur)/4);mutate(()=>{if(neededBars>state.bars){state.bars=clamp(neededBars,1,512);state.duration=barsToSecondsV0811(state.bars);}const made=midis.map(m=>({id:uid(),beat,dur,midi:m,velocity:+els.velocity.value||.68}));t.notes.push(...made);t.notes.sort((a,b)=>a.beat-b.beat||a.midi-b.midi);state.selectedNoteId=made[0]?.id||null;});normalizeDurationDependentsV0811();updateDurationUiV0811();renderAll();toast(`Accord inséré mesure ${Math.floor(beat/4)+1} sur ${t.name}`);}
function renderChords(){els.chords.innerHTML='';state.chords.forEach(ch=>{const d=document.createElement('span');d.className='chord-chip';d.innerHTML=`${NOTE_NAMES[ch.root]}${ch.type}<button>×</button>`;d.querySelector('button').onclick=()=>{state.chords=state.chords.filter(x=>x.id!==ch.id);markDirty();renderChords();};els.chords.appendChild(d);});}

function switchMode(mode){$$('.mode').forEach(b=>b.classList.toggle('active',b.dataset.mode===mode));$$('.view').forEach(v=>v.classList.remove('active'));$('#'+mode+'View').classList.add('active');if(mode==='mix')renderMixer();if(mode==='arrange')renderArrangementV061();if(mode==='automation'){renderVolumeAutomationV070();renderEffectAutomationV071();renderRhythmAutomationV072();renderTempoAutomationV073();renderAutomationHubV075();renderAutomationGroupsV077();renderAutomationPrecisionV077();renderAutomationStabilityV0710();}if(mode==='ltc')renderLtcModeV082();}
function switchMobile(m,b){if(m==='library'){openLibrary();return;}els.workspace.classList.remove('show-tracks','show-inspector');if(m==='tracks')els.workspace.classList.add('show-tracks');if(m==='inspector')els.workspace.classList.add('show-inspector');$$('.mobile-tabs button').forEach(x=>x.classList.toggle('active',x===b));}


function openMotifGenerator(){
  const t=currentTrack();if(!t)return toast('Choisis d’abord une piste');
  const p=PRESETS[t.instrument]||{};if(p.percussion||p.engine==='custom-sample')return toast('Choisis une piste mélodique pour générer un motif');
  $('#motifTrackName').textContent=t.name+' • '+t.instrument;motifCandidate=[];motifSource=[];motifSourceMeta=null;motifCandidateMode='new';renderMotifPreview();updateVariationSourceUI();
  $('#previewMotifBtn').disabled=true;$('#insertMotifBtn').disabled=true;$('#sourceFromCandidateBtn').disabled=true;$('#motifModal').classList.remove('hidden');
}
function closeMotifGenerator(){stopMotifPreview();$('#motifModal').classList.add('hidden');}
function motifRegisterRange(kind){return kind==='low'?[48,59]:kind==='high'?[72,83]:[60,71];}
function notesInScale(root,intervals,lo,hi){const pcs=new Set(intervals.map(x=>(root+x)%12)),out=[];for(let m=lo;m<=hi;m++)if(pcs.has(m%12))out.push(m);return out;}
function chordPitchClasses(ch){const ints=CHORD_INTERVALS[ch?.type]||CHORD_INTERVALS.maj;return new Set(ints.map(x=>(Number(ch?.root||0)+x)%12));}
function nearestIndex(arr,midi){let bi=0,bd=1e9;arr.forEach((v,i)=>{const d=Math.abs(v-midi);if(d<bd){bd=d;bi=i;}});return bi;}
function pickStepIndex(cur,len,direction,progress){
  const r=Math.random();let step=0;
  if(direction==='rise')step=r<.55?1:r<.78?2:r<.90?0:-1;
  else if(direction==='fall')step=r<.55?-1:r<.78?-2:r<.90?0:1;
  else if(direction==='stable')step=r<.55?0:r<.78?1:r<.96?-1:(Math.random()<.5?2:-2);
  else {const rising=Math.sin(progress*Math.PI*2)>=0;step=r<.50?(rising?1:-1):r<.72?0:r<.88?(rising?2:-2):(rising?-1:1);}
  return clamp(cur+step,0,len-1);
}
function motifDuration(kind){if(kind==='long')return [1.5,2,2.5,3][Math.floor(Math.random()*4)];if(kind==='short')return [.5,.5,.75,1][Math.floor(Math.random()*4)];return [.5,1,1.5,2][Math.floor(Math.random()*4)];}
function generateMotifCandidate(){
  const t=currentTrack();if(!t)return;
  const bars=+$('#motifBars').value||4,density=$('#motifDensity').value,reg=$('#motifRegister').value,lenKind=$('#motifNoteLength').value,dir=$('#motifDirection').value,scaleName=$('#motifScale').value;
  const [lo,hi]=motifRegisterRange(reg),scale=MOTIF_SCALES[scaleName]||MOTIF_SCALES.major,baseNotes=notesInScale(state.key,scale,lo,hi);
  if(!baseNotes.length)return toast('Registre incompatible');
  const perBar=density==='low'?2:density==='high'?6:4,useChords=$('#motifUseChords').checked&&state.chords.length>0;
  const result=[];let cursor=Math.floor(baseNotes.length*.45),lastMidi=baseNotes[cursor];
  for(let bar=0;bar<bars;bar++){
    const chord=useChords?state.chords[bar%state.chords.length]:null,pcs=chord?chordPitchClasses(chord):null;
    const candidates=pcs?baseNotes.filter(m=>pcs.has(m%12)):baseNotes;const notePool=candidates.length?candidates:baseNotes;
    const slots=perBar,spacing=4/slots;
    for(let i=0;i<slots;i++){
      if(density==='low'&&Math.random()<.18)continue;
      const progress=(bar+i/slots)/bars,targetPool=notePool;
      let idx=nearestIndex(targetPool,lastMidi);idx=pickStepIndex(idx,targetPool.length,dir,progress);let midi=targetPool[idx];
      if(Math.abs(midi-lastMidi)>7){const sign=midi>lastMidi?1:-1;midi=targetPool[nearestIndex(targetPool,lastMidi+sign*5)];}
      let beat=bar*4+i*spacing;if(i>0)beat+=([-.04,0,.04][Math.floor(Math.random()*3)]);
      let dur=motifDuration(lenKind);if(lenKind==='long')dur=Math.max(dur,spacing*1.05);dur=Math.min(dur,Math.max(.25,bars*4-beat));
      const velocity=clamp(.58+Math.random()*.16+(i===0?.05:0),.4,.9);
      result.push({id:uid(),beat:Math.max(0,beat),dur,midi,velocity});lastMidi=midi;
    }
  }
  motifCandidate=result.sort((a,b)=>a.beat-b.beat);motifCandidateMode='new';renderMotifPreview();$('#previewMotifBtn').disabled=!result.length;$('#insertMotifBtn').disabled=!result.length;$('#sourceFromCandidateBtn').disabled=!result.length;
}
function copyMotifNotes(notes){return (notes||[]).map(n=>({beat:+n.beat||0,dur:Math.max(.05,+n.dur||.5),midi:Math.round(+n.midi||60),velocity:clamp(Number.isFinite(+n.velocity)?+n.velocity:.7,.2,1)})).sort((a,b)=>a.beat-b.beat);}
function updateVariationSourceUI(){
  const el=$('#variationSourceStatus');if(!el)return;
  if(!motifSource.length){el.textContent='Aucune source';return;}
  const label=motifSourceMeta?.label||'Motif';el.textContent=`${label} • ${motifSource.length} notes`;
}
function useCandidateAsVariationSource(){
  if(!motifCandidate.length)return toast('Génère d’abord une proposition');
  motifSource=copyMotifNotes(motifCandidate);motifSourceMeta={label:'Proposition actuelle',startBeat:null,inTrack:false};updateVariationSourceUI();renderMotifPreview();toast('Proposition définie comme motif A');
}
function captureMotifSourceFromTrack(){
  const t=currentTrack();if(!t?.notes?.length)return toast('Cette piste ne contient encore aucune note');
  const bars=+$('#motifBars').value||4,span=bars*4,selected=currentNote();let start=0;
  if(selected)start=Math.floor(selected.beat/4)*4;
  else {const end=Math.max(...t.notes.map(n=>n.beat+n.dur));start=Math.max(0,Math.ceil(end/4)*4-span);}
  let src=t.notes.filter(n=>n.beat<span+start&&n.beat+n.dur>start).map(n=>({...n,beat:Math.max(0,n.beat-start),dur:Math.min(n.dur,span-Math.max(0,n.beat-start))})).filter(n=>n.dur>.05);
  if(!src.length&&start>0){start=0;src=t.notes.filter(n=>n.beat<span).map(n=>({...n,beat:n.beat,dur:Math.min(n.dur,span-n.beat)})).filter(n=>n.dur>.05);}
  if(!src.length)return toast('Aucune note dans la zone choisie');
  motifSource=copyMotifNotes(src);motifSourceMeta={label:selected?'Mesures autour de la note':'Dernières mesures de la piste',startBeat:start,inTrack:true};
  motifCandidate=copyMotifNotes(motifSource);updateVariationSourceUI();renderMotifPreview();$('#previewMotifBtn').disabled=false;$('#insertMotifBtn').disabled=false;$('#sourceFromCandidateBtn').disabled=false;toast('Motif A chargé depuis la piste');
}
function nearestAllowedMidi(target,allowed,preferredDir=0){
  if(!allowed?.length)return target;let best=allowed[0],score=1e9;
  for(const m of allowed){let sc=Math.abs(m-target);if(preferredDir&&Math.sign(m-target)!==preferredDir&&m!==target)sc+=.35;if(sc<score){score=sc;best=m;}}
  return best;
}
function variationAllowedNotes(noteBeat){
  const reg=$('#motifRegister').value,scaleName=$('#motifScale').value,[lo0,hi0]=motifRegisterRange(reg),sourceMid=motifSource.length?motifSource.reduce((a,n)=>a+n.midi,0)/motifSource.length:66;
  const lo=Math.min(lo0,Math.floor(sourceMid)-12),hi=Math.max(hi0,Math.ceil(sourceMid)+12),scale=MOTIF_SCALES[scaleName]||MOTIF_SCALES.major;
  let allowed=notesInScale(state.key,scale,clamp(lo,36,84),clamp(hi,48,96));
  if($('#motifUseChords').checked&&state.chords.length){const bar=Math.max(0,Math.floor(noteBeat/4)),pcs=chordPitchClasses(state.chords[bar%state.chords.length]);const chordAllowed=allowed.filter(m=>pcs.has(m%12));if(chordAllowed.length)allowed=chordAllowed;}
  return allowed;
}
function generateMotifVariation(kind='prime'){
  if(!motifSource.length){if(motifCandidate.length)useCandidateAsVariationSource();else captureMotifSourceFromTrack();}
  if(!motifSource.length)return;
  const strength=$('#variationStrength').value||'gentle',keepRhythm=$('#variationKeepRhythm').checked,keepLengths=$('#variationKeepLengths').checked,changeEnding=$('#variationChangeEnding').checked;
  const baseProb={gentle:.22,medium:.34,open:.48}[strength]||.22,mult=kind==='double'?1.35:1,prob=Math.min(.72,baseProb*mult),timingChance=kind==='double'?.28:.10,lengthChance=kind==='double'?.35:.14,octChance=kind==='double'?.10:.035;
  const endStart=Math.max(0,Math.max(...motifSource.map(n=>n.beat+n.dur))-4);
  let out=motifSource.map((src,i)=>{
    const n={...src,id:uid()},isEnd=src.beat>=endStart,boost=(changeEnding&&isEnd)?1.65:1,doPitch=Math.random()<Math.min(.9,prob*boost);
    if(doPitch){const allowed=variationAllowedNotes(src.beat),idx=nearestIndex(allowed,src.midi),choices=[];for(const step of [-2,-1,1,2]){const j=idx+step;if(j>=0&&j<allowed.length)choices.push(allowed[j]);}if(choices.length){let midi=choices[Math.floor(Math.random()*choices.length)];if(Math.random()<octChance){const oct=midi+(Math.random()<.5?-12:12);if(oct>=36&&oct<=96)midi=oct;}n.midi=midi;}}
    if(!keepRhythm&&Math.random()<timingChance){n.beat=Math.max(0,snap(src.beat+([-.25,-.125,.125,.25][Math.floor(Math.random()*4)])));}
    if(!keepLengths&&Math.random()<lengthChance){n.dur=Math.max(state.grid*.5,snap(src.dur*(Math.random()<.5?.75:1.25)));}
    if(kind==='double'&&isEnd&&i===motifSource.length-1&&Math.random()<.8){const allowed=variationAllowedNotes(src.beat),dir=Math.random()<.65?-1:1;n.midi=nearestAllowedMidi(n.midi+dir*(Math.random()<.5?2:4),allowed,dir);}
    n.velocity=clamp(src.velocity+((Math.random()-.5)*(kind==='double'?.10:.05)),.35,.95);return n;
  }).sort((a,b)=>a.beat-b.beat);
  const unchanged=out.length===motifSource.length&&out.every((n,i)=>motifSource[i]&&n.midi===motifSource[i].midi&&Math.abs(n.beat-motifSource[i].beat)<.001&&Math.abs(n.dur-motifSource[i].dur)<.001);
  if(unchanged&&out.length){const i=out.length-1,src=motifSource[i],allowed=variationAllowedNotes(src.beat),idx=nearestIndex(allowed,src.midi),j=clamp(idx+(idx<allowed.length-1?1:-1),0,allowed.length-1);out[i].midi=allowed[j]??src.midi;}
  motifCandidate=out;motifCandidateMode=kind==='double'?'variation-double':'variation-prime';renderMotifPreview();$('#previewMotifBtn').disabled=false;$('#insertMotifBtn').disabled=false;$('#sourceFromCandidateBtn').disabled=false;
  toast(kind==='double'?'A″ générée — identité conservée, variation plus libre':'A′ générée — variation légère du motif A');
}

function sourceSpanBeats(){
  if(!motifSource.length)return (+$('#motifBars').value||4)*4;
  const end=Math.max(...motifSource.map(n=>n.beat+n.dur));
  return Math.max(4,Math.ceil(end/4)*4);
}
function median(vals){if(!vals.length)return 1;const a=[...vals].sort((x,y)=>x-y),m=Math.floor(a.length/2);return a.length%2?a[m]:(a[m-1]+a[m])/2;}
function sourceRhythmPattern(span,targetCount){
  const src=copyMotifNotes(motifSource).filter(n=>n.beat<span);
  if(!src.length)return Array.from({length:targetCount},(_,i)=>i*span/Math.max(1,targetCount));
  const beats=src.map(n=>n.beat),gaps=[];for(let i=1;i<beats.length;i++)if(beats[i]-beats[i-1]>.05)gaps.push(beats[i]-beats[i-1]);
  const baseGap=clamp(median(gaps)||1,.25,2.5),out=[];let b=0,i=0;
  while(b<span-.05&&out.length<targetCount){out.push(b);const srcGap=gaps.length?gaps[i%gaps.length]:baseGap;const vary=[.88,1,1,1.12][Math.floor(Math.random()*4)];b+=clamp(srcGap*vary,.25,2.5);i++;}
  return out;
}
function motifStableEndingMidi(beat,near){
  const reg=$('#motifRegister').value,scaleName=$('#motifScale').value,[lo0,hi0]=motifRegisterRange(reg),scale=MOTIF_SCALES[scaleName]||MOTIF_SCALES.major;
  let allowed=notesInScale(state.key,scale,Math.max(36,lo0-12),Math.min(96,hi0+12));
  let pcs=new Set([state.key%12]);
  if($('#motifUseChords').checked&&state.chords.length){const bar=Math.max(0,Math.floor(beat/4));pcs=chordPitchClasses(state.chords[bar%state.chords.length]);}
  const stable=allowed.filter(m=>pcs.has(m%12));return nearestAllowedMidi(near,stable.length?stable:allowed,0);
}
function generateMotifContinuation(kind='continue'){
  if(!motifSource.length){if(motifCandidate.length)useCandidateAsVariationSource();else captureMotifSourceFromTrack();}
  if(!motifSource.length)return;
  const bars=+$('#motifBars').value||4,span=bars*4,density=$('#motifDensity').value,lenKind=$('#motifNoteLength').value;
  const baseCount=Math.max(3,motifSource.filter(n=>n.beat<span).length||motifSource.length),densityMul=density==='low'?.72:density==='high'?1.22:1;
  const targetCount=clamp(Math.round(baseCount*densityMul),3,Math.max(4,bars*7));
  let onsets=sourceRhythmPattern(span,targetCount);if(kind==='response')onsets=onsets.filter((_,i)=>i===0||i===onsets.length-1||Math.random()>.18);
  const src=copyMotifNotes(motifSource),last=src[src.length-1],recent=src.slice(-5),rawIntervals=[];for(let i=1;i<recent.length;i++)rawIntervals.push(recent[i].midi-recent[i-1].midi);
  const trend=rawIntervals.length?rawIntervals.reduce((a,b)=>a+b,0)/rawIntervals.length:0;
  let cur=last?.midi||66,out=[];const sourceDurs=src.map(n=>n.dur).filter(Boolean),sourceVels=src.map(n=>n.velocity||.7);
  if(kind==='response'){const allowed=variationAllowedNotes(0);cur=nearestAllowedMidi(cur+(trend>=0?-3:3),allowed,trend>=0?-1:1);}
  for(let i=0;i<onsets.length;i++){
    const beat=onsets[i],allowed=variationAllowedNotes(beat);if(!allowed.length)continue;
    let target=cur;
    if(kind==='continue'){
      const tendency=Math.abs(trend)>.35?Math.sign(trend):($('#motifDirection').value==='fall'?-1:$('#motifDirection').value==='rise'?1:0);
      const r=Math.random(),step=r<.18?0:r<.67?(tendency|| (Math.random()<.5?1:-1)):(Math.random()<.5?2:-2);
      const idx=nearestIndex(allowed,cur);target=allowed[clamp(idx+step,0,allowed.length-1)];
      if(i>1&&Math.random()<.18){const echo=src[i%src.length]?.midi;target=nearestAllowedMidi((target+echo)/2,allowed,0);}
    }else{
      const srcI=src[Math.min(src.length-1,Math.floor(i*src.length/Math.max(1,onsets.length)))],prevSrc=src[Math.max(0,Math.min(src.length-1,Math.floor(i*src.length/Math.max(1,onsets.length))-1))];
      const contour=(srcI?.midi||cur)-(prevSrc?.midi||srcI?.midi||cur),inv=contour===0?(Math.random()<.5?-1:1):-Math.sign(contour);
      const idx=nearestIndex(allowed,cur),step=Math.random()<.62?inv:(Math.random()<.5?0:inv*2);target=allowed[clamp(idx+step,0,allowed.length-1)];
    }
    if(Math.abs(target-cur)>7)target=nearestAllowedMidi(cur+Math.sign(target-cur)*5,allowed,Math.sign(target-cur));cur=target;
    let dur=lenKind==='long'?Math.max(1.25,(sourceDurs[i%sourceDurs.length]||1.5)*1.05):lenKind==='short'?Math.min(1,sourceDurs[i%sourceDurs.length]||.75):(sourceDurs[i%sourceDurs.length]||1.2);
    if(i<onsets.length-1)dur=Math.min(dur,Math.max(.3,(onsets[i+1]-beat)*1.35));dur=Math.min(dur,Math.max(.2,span-beat));
    const velocity=clamp((sourceVels[i%sourceVels.length]||.68)+(Math.random()-.5)*.08,.38,.92);
    out.push({id:uid(),beat,dur,midi:cur,velocity});
  }
  if(out.length){const li=out.length-1;if(kind==='response')out[li].midi=motifStableEndingMidi(out[li].beat,out[li].midi);else if(Math.random()<.65)out[li].midi=motifStableEndingMidi(out[li].beat,out[li].midi);}
  motifCandidate=out.sort((a,b)=>a.beat-b.beat);motifCandidateMode=kind;renderMotifPreview();$('#previewMotifBtn').disabled=!out.length;$('#insertMotifBtn').disabled=!out.length;$('#sourceFromCandidateBtn').disabled=!out.length;
  if($('#motifInsert').value==='after'&&motifSourceMeta?.inTrack)$('#motifInsert').value='afterSource';
  toast(kind==='response'?'Réponse B générée — phrase complémentaire au motif A':'Suite générée — prolongement naturel du motif A');
}
function ensureMotifSourceForTransform(){
  if(!motifSource.length){if(motifCandidate.length)useCandidateAsVariationSource();else captureMotifSourceFromTrack();}
  return motifSource.length>0;
}
function motifTransformStrength(){return $('#transformStrength')?.value||'medium';}
function importantMotifIndexes(src){
  const keep=new Set();if(!src.length)return keep;keep.add(0);keep.add(src.length-1);
  let minI=0,maxI=0;for(let i=1;i<src.length;i++){if(src[i].midi<src[minI].midi)minI=i;if(src[i].midi>src[maxI].midi)maxI=i;}keep.add(minI);keep.add(maxI);
  src.forEach((n,i)=>{const pos=((n.beat%4)+4)%4;if(pos<.08||Math.abs(pos-2)<.08)keep.add(i);});
  return keep;
}
function calmMotifSource(src,strength){
  const ratios={gentle:.82,medium:.68,strong:.54},target=Math.max(2,Math.round(src.length*(ratios[strength]||.68))),important=importantMotifIndexes(src),chosen=new Set(important);
  const candidates=src.map((_,i)=>i).filter(i=>!chosen.has(i));
  while(chosen.size<target&&candidates.length){let bestAt=0,best=-1;for(let k=0;k<candidates.length;k++){const i=candidates[k],n=src[i],score=(Math.abs((n.beat%4)-0)<.12?2:0)+(n.dur>1.2?1:0)+Math.random()*.7;if(score>best){best=score;bestAt=k;}}chosen.add(candidates.splice(bestAt,1)[0]);}
  const kept=[...chosen].sort((a,b)=>a-b).map(i=>({...src[i],id:uid()})).sort((a,b)=>a.beat-b.beat),stretch={gentle:1.15,medium:1.38,strong:1.62}[strength]||1.38;
  kept.forEach((n,i)=>{const next=kept[i+1],room=next?Math.max(.3,next.beat-n.beat):Math.max(.4,sourceSpanBeats()-n.beat);n.dur=Math.min(room*.92,Math.max(n.dur*stretch,strength==='strong'?1.25:1));n.velocity=clamp(n.velocity*(strength==='strong'?.86:.92),.3,.9);});
  return kept;
}
function densifyMotifSource(src,strength){
  const out=copyMotifNotes(src).map(n=>({...n,id:uid()})),factor={gentle:.25,medium:.48,strong:.72}[strength]||.48,targetAdds=Math.max(1,Math.round(src.length*factor)),span=sourceSpanBeats();
  const intervals=[];for(let i=0;i<src.length;i++){const a=src[i],b=src[i+1]||null,end=b?b.beat:span,gap=end-a.beat;if(gap>.55)intervals.push({i,a,b,end,gap});}
  intervals.sort((x,y)=>y.gap-x.gap);let added=0,pass=0;
  while(added<targetAdds&&intervals.length&&pass<targetAdds*4){const g=intervals[pass%intervals.length],slot=g.a.beat+g.gap*(pass%2?0.66:0.5);if(slot<span-.05&&!out.some(n=>Math.abs(n.beat-slot)<.18)){const allowed=variationAllowedNotes(slot),near=g.b?Math.round((g.a.midi+g.b.midi)/2):g.a.midi,target=nearestAllowedMidi(near,allowed,0),dur=Math.min(Math.max(.35,g.gap*.34),1.1);out.push({id:uid(),beat:snap(slot),dur,midi:target,velocity:clamp(((g.a.velocity||.68)+(g.b?.velocity||g.a.velocity||.68))/2*.88,.32,.82)});added++;}pass++;}
  if(added<targetAdds){for(let k=0;k<targetAdds-added;k++){const base=src[k%src.length],slot=Math.min(span-.25,snap(base.beat+Math.max(.25,base.dur*.55)));const allowed=variationAllowedNotes(slot),idx=nearestIndex(allowed,base.midi),step=k%2?1:-1,midi=allowed[clamp(idx+step,0,allowed.length-1)]??base.midi;if(!out.some(n=>Math.abs(n.beat-slot)<.16))out.push({id:uid(),beat:slot,dur:Math.max(.3,Math.min(.8,base.dur*.6)),midi,velocity:clamp((base.velocity||.7)*.82,.3,.8)});}}
  return out.sort((a,b)=>a.beat-b.beat||a.midi-b.midi);
}
function simplifyMotifSource(src,strength){
  const ratios={gentle:.72,medium:.52,strong:.36},target=Math.max(2,Math.round(src.length*(ratios[strength]||.52))),important=importantMotifIndexes(src),scores=src.map((n,i)=>{let sc=0;if(important.has(i))sc+=8;const pos=((n.beat%4)+4)%4;if(pos<.08)sc+=4;else if(Math.abs(pos-2)<.08)sc+=2;if(n.dur>=1)sc+=1.5;if(i>0&&Math.abs(n.midi-src[i-1].midi)>=4)sc+=1;return {i,sc};}).sort((a,b)=>b.sc-a.sc||a.i-b.i),chosen=new Set(scores.slice(0,target).map(x=>x.i));important.forEach(i=>chosen.add(i));
  let out=[...chosen].sort((a,b)=>a-b).map(i=>({...src[i],id:uid()})).sort((a,b)=>a.beat-b.beat);const finalTarget=Math.max(target,important.size);if(out.length>finalTarget)out=out.filter((_,i)=>i===0||i===out.length-1||i<finalTarget);
  out.forEach((n,i)=>{const next=out[i+1],room=next?next.beat-n.beat:Math.max(.5,sourceSpanBeats()-n.beat);n.dur=Math.min(room*.88,Math.max(n.dur,strength==='strong'?1.15:.8));n.velocity=clamp(Math.round((n.velocity||.7)*20)/20,.35,.9);});return out;
}
function generateMotifTransform(kind){
  if(!ensureMotifSourceForTransform())return;const src=copyMotifNotes(motifSource),strength=motifTransformStrength();let out=[];
  if(kind==='calm')out=calmMotifSource(src,strength);else if(kind==='densify')out=densifyMotifSource(src,strength);else out=simplifyMotifSource(src,strength);
  if(!out.length)return toast('Impossible de transformer ce motif');motifCandidate=out;motifCandidateMode='transform-'+kind;renderMotifPreview();$('#previewMotifBtn').disabled=false;$('#insertMotifBtn').disabled=false;$('#sourceFromCandidateBtn').disabled=false;
  const labels={calm:'Motif calmé — plus d’espace et notes plus longues',densify:'Motif densifié — A conservé avec des notes compatibles ajoutées',simplify:'Motif simplifié — signature essentielle conservée'};toast(labels[kind]);
}
function naturalizeStrength(){return $('#naturalizeStrength')?.value||'medium';}
function currentInstrumentNaturalizeProfile(){
  const t=currentTrack(),p=PRESETS[t?.instrument]||{},name=String(t?.instrument||'').toLowerCase();
  if(p.kind==='pad'||p.engine==='pad-hq')return {family:'pad',overlap:.24,timingMs:5,vel:.018,dur:.10};
  if(name.includes('guitare')||name.includes('mandoline')||name.includes('harpe')||name.includes('pizzicato'))return {family:'strings',overlap:.10,timingMs:14,vel:.050,dur:.075};
  if(name.includes('piano')||name.includes('rhodes'))return {family:'keys',overlap:.055,timingMs:10,vel:.040,dur:.055};
  if(name.includes('kalimba')||name.includes('marimba')||name.includes('triangle'))return {family:'mallet',overlap:.025,timingMs:8,vel:.032,dur:.040};
  if(name.includes('basse'))return {family:'bass',overlap:.07,timingMs:11,vel:.035,dur:.060};
  return {family:'generic',overlap:.06,timingMs:10,vel:.035,dur:.055};
}
function linkMotifSource(src,strength){
  const out=copyMotifNotes(src).map(n=>({...n,id:uid()})).sort((a,b)=>a.beat-b.beat),profile=currentInstrumentNaturalizeProfile(),mul={gentle:.55,medium:1,strong:1.55}[strength]||1,span=sourceSpanBeats();
  out.forEach((n,i)=>{const next=out[i+1],gap=next?next.beat-n.beat:span-n.beat;if(gap<=.08)return;const overlap=profile.overlap*mul;const target=Math.max(n.dur,gap+overlap);const max=gap+Math.min(.45,overlap*1.6+.04);n.dur=Math.min(target,max,Math.max(.08,span-n.beat+.35));});
  return out;
}
function extendMotifSource(src,strength){
  const out=copyMotifNotes(src).map(n=>({...n,id:uid()})).sort((a,b)=>a.beat-b.beat),profile=currentInstrumentNaturalizeProfile(),factor={gentle:1.18,medium:1.42,strong:1.75}[strength]||1.42,span=sourceSpanBeats();
  out.forEach((n,i)=>{const next=out[i+1],gap=next?next.beat-n.beat:span-n.beat;let cap=gap+(profile.family==='pad'?.32:profile.family==='strings'?.12:.04);if(next&&next.midi===n.midi)cap=Math.max(.08,gap-.03);n.dur=clamp(Math.max(n.dur,n.dur*factor),.08,Math.max(.08,cap));});
  return out;
}
function humanizeMotifSourceSmart(src,strength){
  const out=copyMotifNotes(src).map(n=>({...n,id:uid()})).sort((a,b)=>a.beat-b.beat),p=currentInstrumentNaturalizeProfile(),mul={gentle:.55,medium:1,strong:1.55}[strength]||1,bpm=Math.max(30,state.bpm),msToBeat=bpm/60000,span=sourceSpanBeats();
  out.forEach((n,i)=>{const timing=(Math.random()*2-1)*p.timingMs*mul*msToBeat;const vel=(Math.random()*2-1)*p.vel*mul;const durScale=1+(Math.random()*2-1)*p.dur*mul;n.beat=clamp(n.beat+timing,0,Math.max(0,span-.03));n.velocity=clamp(n.velocity+vel,.25,.98);n.dur=Math.max(.08,n.dur*durScale);});
  out.sort((a,b)=>a.beat-b.beat);for(let i=1;i<out.length;i++){if(out[i].beat<=out[i-1].beat+.015)out[i].beat=out[i-1].beat+.018;}out.forEach(n=>{n.beat=Math.min(n.beat,span-.02);n.dur=Math.min(n.dur,Math.max(.08,span-n.beat+.2));});
  return out;
}
function generateMotifNaturalize(kind){
  if(!ensureMotifSourceForTransform())return;const src=copyMotifNotes(motifSource),strength=naturalizeStrength();let out=[];
  if(kind==='link')out=linkMotifSource(src,strength);else if(kind==='extend')out=extendMotifSource(src,strength);else out=humanizeMotifSourceSmart(src,strength);
  if(!out.length)return toast('Impossible de naturaliser ce motif');motifCandidate=out;motifCandidateMode='naturalize-'+kind;renderMotifPreview();$('#previewMotifBtn').disabled=false;$('#insertMotifBtn').disabled=false;$('#sourceFromCandidateBtn').disabled=false;
  const labels={link:'Motif lié — transitions plus continues',extend:'Notes étendues selon l’espace disponible',humanize:'Humanisation intelligente appliquée selon l’instrument'};toast(labels[kind]);
}
function realtimeHumanizeForTrack(t,n){
  if(!state.humanize)return {jitterSec:0,vel:n.velocity,durScale:1};const p=PRESETS[t.instrument]||{},name=String(t.instrument||'').toLowerCase(),amount=state.humanize;
  let ms=8,velAmt=.035,durAmt=.035;if(p.kind==='pad'||p.engine==='pad-hq'){ms=3;velAmt=.012;durAmt=.050;}else if(name.includes('guitare')||name.includes('mandoline')||name.includes('harpe')||name.includes('pizzicato')){ms=13;velAmt=.050;durAmt=.045;}else if(name.includes('piano')||name.includes('rhodes')){ms=9;velAmt=.040;durAmt=.032;}else if(name.includes('kalimba')||name.includes('marimba')||name.includes('triangle')){ms=6;velAmt=.028;durAmt=.025;}else if(name.includes('basse')){ms=8;velAmt=.030;durAmt=.035;}
  return {jitterSec:(Math.random()*2-1)*(ms/1000)*amount,vel:clamp(n.velocity+(Math.random()*2-1)*velAmt*amount,.02,1),durScale:clamp(1+(Math.random()*2-1)*durAmt*amount,.82,1.18)};
}
function renderMotifPreview(){
  const c=$('#motifPreviewCanvas'),sum=$('#motifSummary');if(!c||!sum)return;const ctx=c.getContext('2d'),w=c.clientWidth||900,h=c.clientHeight||210,dpr=devicePixelRatio||1;c.width=Math.floor(w*dpr);c.height=Math.floor(h*dpr);ctx.scale(dpr,dpr);ctx.clearRect(0,0,w,h);ctx.fillStyle='#0f1318';ctx.fillRect(0,0,w,h);
  if(!motifCandidate.length){ctx.fillStyle='#77808d';ctx.font='14px sans-serif';ctx.fillText('Génère une proposition ou charge un motif A depuis la piste.',20,h/2);sum.textContent='Aucune proposition générée.';return;}
  const bars=+$('#motifBars').value||4,total=bars*4,allPreview=[...motifCandidate,...motifSource],minM=Math.min(...allPreview.map(n=>n.midi))-1,maxM=Math.max(...allPreview.map(n=>n.midi))+1,range=Math.max(5,maxM-minM+1);
  ctx.strokeStyle='#27303a';ctx.lineWidth=1;for(let b=0;b<=bars;b++){const x=b/bars*w;ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,h);ctx.stroke();}
  if(motifSource.length){ctx.globalAlpha=.32;motifSource.forEach(n=>{const x=n.beat/total*w,nw=Math.max(5,n.dur/total*w),y=(maxM-n.midi)/range*(h-24)+10;ctx.fillStyle='#8aa0b8';ctx.fillRect(x+1,y,nw-2,12);});ctx.globalAlpha=1;}
  motifCandidate.forEach(n=>{const x=n.beat/total*w,nw=Math.max(5,n.dur/total*w),y=(maxM-n.midi)/range*(h-24)+10;ctx.fillStyle='#7ee787';ctx.fillRect(x+1,y,nw-2,12);});
  const first=motifCandidate[0],last=motifCandidate[motifCandidate.length-1];let txt=`${motifCandidate.length} notes • ${bars} mesures • ${NOTE_NAMES[first.midi%12]}${Math.floor(first.midi/12)-1} → ${NOTE_NAMES[last.midi%12]}${Math.floor(last.midi/12)-1}`;if(motifSource.length&&String(motifCandidateMode).startsWith('variation')){const samePitch=motifCandidate.filter((n,i)=>motifSource[i]&&n.midi===motifSource[i].midi).length;txt+=` • identité mélodique ≈ ${Math.round(samePitch/Math.max(1,motifCandidate.length)*100)}%`;}else if(motifCandidateMode==='continue')txt+=' • suite naturelle de A';else if(motifCandidateMode==='response')txt+=' • réponse B à A';else if(motifCandidateMode==='transform-calm')txt+=' • A calmé';else if(motifCandidateMode==='transform-densify')txt+=' • A densifié';else if(motifCandidateMode==='transform-simplify')txt+=' • A simplifié';else if(motifCandidateMode==='naturalize-link')txt+=' • notes liées';else if(motifCandidateMode==='naturalize-extend')txt+=' • notes étendues';else if(motifCandidateMode==='naturalize-humanize')txt+=' • humanisation intelligente';sum.textContent=txt;
}
function stopMotifPreview(){if(motifPreviewTimer){clearTimeout(motifPreviewTimer);motifPreviewTimer=null;}if(!state.playing){state.nodes.forEach(n=>{try{n.stop()}catch{}});state.nodes=[];}}
async function previewMotifCandidate(){
  if(!motifCandidate.length)return;stop();stopMotifPreview();const t=currentTrack();if(!t)return;const ctx=ensureAudio();await ctx.resume();const pack=multisamplePackForTrack(t);if(pack&&window.LTCSampleEngine?.preloadUsage)await window.LTCSampleEngine.preloadUsage(pack,ctx,motifCandidate.map(n=>({midi:n.midi,velocity:n.velocity})));
  const g=ctx.createGain(),preset=PRESETS[t.instrument]||{};g.gain.value=t.volume*(preset.mixTrim??1);let dest=g;const pan=ctx.createStereoPanner?ctx.createStereoPanner():null;if(pan){pan.pan.value=t.pan;g.connect(pan);connectSafePreviewV0813(ctx,pan);}else connectSafePreviewV0813(ctx,g);
  const now=ctx.currentTime+.05,spb=60/state.bpm;motifCandidate.forEach(n=>scheduleVoice(ctx,dest,now+n.beat*spb,n.dur*spb,n.midi,n.velocity,t));const end=Math.max(...motifCandidate.map(n=>n.beat+n.dur))*spb+.5;motifPreviewTimer=setTimeout(()=>stopMotifPreview(),end*1000);toast('Pré-écoute du motif');
}
function insertMotifCandidate(){
  if(!motifCandidate.length)return;const t=currentTrack();if(!t)return;const bars=+$('#motifBars').value||4,mode=$('#motifInsert').value;let offset=0;
  if(mode==='after'&&t.notes.length){const end=Math.max(...t.notes.map(n=>n.beat+n.dur));offset=Math.ceil(end/4)*4;}else if(mode==='afterSource'){if(motifSourceMeta?.inTrack&&Number.isFinite(motifSourceMeta.startBeat))offset=motifSourceMeta.startBeat+sourceSpanBeats();else if(t.notes.length){const end=Math.max(...t.notes.map(n=>n.beat+n.dur));offset=Math.ceil(end/4)*4;toast('Motif A non lié à la piste : insertion après les notes existantes');}}
  const total=totalBeats(),room=total-offset;if(room<=0)return toast('Plus de place dans cette piste');
  const notes=motifCandidate.filter(n=>n.beat<room).map(n=>({...n,id:uid(),beat:Math.max(0,n.beat+offset),dur:Math.min(n.dur,total-(n.beat+offset))})).filter(n=>n.dur>.05);
  if(!notes.length)return toast('Motif trop long pour la durée du morceau');mutate(()=>{t.notes.push(...notes);state.selectedNoteId=notes[0].id;});renderAll();closeMotifGenerator();toast(`${notes.length} notes insérées`);
}

function ensureAudio(){ if(!state.audioCtx) state.audioCtx=new (window.AudioContext||window.webkitAudioContext)(); return state.audioCtx; }
function multisamplePackForTrack(t){const p=PRESETS[t?.instrument];return p?.engine==='multisample'?p.packId:null;}
async function preloadTrackSamples(t,ctx,onProgress,midi=null,velocity=.72){const p=PRESETS[t?.instrument];if(p?.engine==='custom-sample'&&window.LTCCustomSamples){await window.LTCCustomSamples.preloadUsed([p.sampleId],ctx);return true;}const packId=multisamplePackForTrack(t);if(!packId||!window.LTCSampleEngine)return null;if(midi!=null&&window.LTCSampleEngine.preloadUsage)return window.LTCSampleEngine.preloadUsage(packId,ctx,[{midi,velocity}],onProgress);return window.LTCSampleEngine.preloadPack(packId,ctx,onProgress);}
function multisamplePackForDrumName(name){const p=PRESETS[name];return p?.engine==='multisample'?p.packId:null;}
function projectSampleUsage(){const by=new Map();const add=(id,u)=>{if(!id)return;if(!by.has(id))by.set(id,[]);by.get(id).push(u);};for(const t of state.tracks){const id=multisamplePackForTrack(t);if(!id)continue;for(const n of t.notes||[])add(id,{midi:n.midi,velocity:Number.isFinite(n.velocity)?n.velocity:.72});}for(const [name,set] of Object.entries(state.drums)){if(!set?.size)continue;const p=PRESETS[name],id=multisamplePackForDrumName(name);if(id)add(id,{midi:p.percussionMidi??60,velocity:.55});}return by;}
async function preloadProjectSamples(ctx){const customIds=customSampleIdsInProject();if(customIds.length&&window.LTCCustomSamples)await window.LTCCustomSamples.preloadUsed(customIds,ctx);if(!window.LTCSampleEngine)return;const usage=projectSampleUsage(),packs=[...usage.keys()];if(perfPrefs.mobileMemory){window.LTCSampleEngine.retainPacks?.(packs);for(const [id,items] of usage)window.LTCSampleEngine.trimPackToUsage?.(id,items);}for(const [id,items] of usage){if(window.LTCSampleEngine.preloadUsage)await window.LTCSampleEngine.preloadUsage(id,ctx,items);else await window.LTCSampleEngine.preloadPack(id,ctx);}renderBank();renderInspector();}
function renderSampleStatus(t=currentTrack()){
  if(!els.bankStatus)return;const p=PRESETS[t?.instrument];
  if(p?.engine==='custom-sample'){const m=window.LTCCustomSamples?.metadata(p.sampleId);els.bankStatus.className='sample-status ready';els.bankStatus.textContent=m?`Son personnel • ${m.name}`:'Son personnel • fichier à retrouver dans Sons perso';return;}
  if(!p||p.engine!=='multisample'){els.bankStatus.className='sample-status synth';els.bankStatus.textContent='Moteur : synthèse locale';return;}
  const st=window.LTCSampleEngine?.getPackStatus(p.packId)||{};
  els.bankStatus.className='sample-status '+(st.ready?'ready':st.error?'error':'pending');
  els.bankStatus.textContent=st.ready?`Multisample prêt • ${st.decoded}/${st.samples}`:st.error?`Multisample indisponible • fallback synthé`:`Multisample • chargement à la première lecture`;
}
function openBank(){renderBank();els.bankModal?.classList.remove('hidden');}
function closeBank(){els.bankModal?.classList.add('hidden');}
function renderBank(){
  if(!els.bankPackList||!window.LTCSampleEngine)return;
  const packs=window.LTCSampleEngine.listKnownPacks();
  els.bankPackList.innerHTML=packs.map(p=>{const mb=(p.decodedBytes/1048576||0).toFixed(1);const status=p.ready?'PRÊT':p.decoded?`PARTIEL ${p.decoded}/${p.samples}`:p.loaded?'MANIFESTE':'NON CHARGÉ';return `<div class="bank-pack ${p.ready?'ready':p.decoded?'partial':''}"><div><strong>${esc(p.name||p.id)}</strong><small>${p.description||'Pack multisample'}</small></div><span>${status}${p.decoded?` • ${mb} Mo`:''}</span></div>`;}).join('');
  const st=window.LTCSampleEngine.getStats(),dev=navigator.deviceMemory?`${navigator.deviceMemory} Go`:'non exposée';els.bankStats.innerHTML=`<b>RAM audio décodée : ${st.decodedMB.toFixed(1)} Mo</b> • Buffers: ${st.buffers} • Préchargements ciblés: ${st.partialPreloads} • Évictions: ${st.evictions}<br>RAM appareil estimée: ${dev} • Mode mémoire mobile: <b>${perfPrefs.mobileMemory?'ON':'OFF'}</b> • Fallbacks: ${st.fallbacks}`;
}
function activeProjectPacks(){return [...projectSampleUsage().keys()];}
async function optimizeMemoryNow(){if(!window.LTCSampleEngine)return;const usage=projectSampleUsage(),packs=[...usage.keys()];let freed=window.LTCSampleEngine.retainPacks?.(packs)||0;for(const [id,items] of usage)freed+=window.LTCSampleEngine.trimPackToUsage?.(id,items)||0;const ctx=ensureAudio();for(const [id,items] of usage)await window.LTCSampleEngine.preloadUsage?.(id,ctx,items);renderBank();renderInspector();toast(`Mémoire optimisée • ${(freed/1048576).toFixed(1)} Mo libérés`);}
async function clearDownloadedSamples(){if(!window.LTCSampleEngine?.clearPersistentSampleCache)return;try{const n=await window.LTCSampleEngine.clearPersistentSampleCache();toast(`${n} fichiers audio hors ligne retirés`);renderBank();}catch(e){alert('Nettoyage cache hors ligne : '+e.message);}}
async function preloadNamedPack(packId,btn,label,doneMsg){try{btn.disabled=true;const ctx=ensureAudio();await ctx.resume();await window.LTCSampleEngine.preloadPack(packId,ctx,(done,total)=>{btn.textContent=`Chargement ${done}/${total}`;});toast(doneMsg);}catch(e){alert('Banque multisample : '+e.message);}finally{btn.disabled=false;btn.textContent=label;renderBank();renderInspector();}}
async function preloadGuitarPack(){const btn=$('#preloadGuitarBtn');return preloadNamedPack('classical-guitar-hq',btn,'Précharger guitare sèche HQ','Guitare classique sèche HQ prête');}
async function preloadNylonPack(){const btn=$('#preloadNylonBtn');return preloadNamedPack('nylon-guitar-hq',btn,'Précharger nylon HQ','Guitare nylon douce HQ prête');}
async function preloadDryPianoPack(){const btn=$('#preloadDryPianoBtn');return preloadNamedPack('dry-piano-hq',btn,'Précharger piano sec HQ','Piano sec HQ prêt');}
async function preloadFeltPianoPack(){const btn=$('#preloadFeltPianoBtn');return preloadNamedPack('felt-piano-hq',btn,'Précharger piano feutré HQ','Piano feutré HQ prêt');}
async function preloadRhodesPack(){const btn=$('#preloadRhodesBtn');return preloadNamedPack('rhodes-hq',btn,'Précharger Rhodes HQ','Rhodes HQ prêt');}
async function preloadMarimbaPack(){const btn=$('#preloadMarimbaBtn');return preloadNamedPack('marimba-hq',btn,'Précharger Marimba HQ','Marimba bois HQ prêt');}
async function preloadKalimbaPack(){const btn=$('#preloadKalimbaBtn');return preloadNamedPack('kalimba-hq',btn,'Précharger Kalimba HQ','Kalimba douce HQ prête');}
async function preloadMandolinPack(){const btn=$('#preloadMandolinBtn');return preloadNamedPack('mandolin-hq',btn,'Précharger Mandoline HQ','Mandoline douce HQ prête');}
async function preloadPizzicatoPack(){const btn=$('#preloadPizzicatoBtn');return preloadNamedPack('pizzicato-hq',btn,'Précharger Pizzicato HQ','Cordes pizzicato HQ prêtes');}
async function preloadHarpPack(){const btn=$('#preloadHarpBtn');return preloadNamedPack('harp-hq',btn,'Précharger Harpe HQ','Harpe douce HQ prête');}
async function preloadHandDrumPack(){const btn=$('#preloadHandDrumBtn');return preloadNamedPack('hand-drum-hq',btn,'Précharger Hand drum HQ','Hand drum HQ prêt');}
async function preloadWoodPercPack(){const btn=$('#preloadWoodPercBtn');return preloadNamedPack('wood-perc-hq',btn,'Précharger Bois HQ','Percussion bois HQ prête');}
async function preloadShakerPack(){const btn=$('#preloadShakerBtn');return preloadNamedPack('shaker-hq',btn,'Précharger Shaker HQ','Shaker doux HQ prêt');}
async function preloadTrianglePack(){const btn=$('#preloadTriangleBtn');return preloadNamedPack('triangle-hq',btn,'Précharger Triangle HQ','Triangle doux HQ prêt');}
async function preloadBassPack(){const btn=$('#preloadBassBtn');return preloadNamedPack('round-bass-hq',btn,'Précharger Basse HQ','Basse ronde HQ prête');}
async function preloadDiagnosticPack(){const btn=$('#preloadDiagnosticBtn');return preloadNamedPack('diagnostic-pluck',btn,'Précharger le pack diagnostic','Pack diagnostic prêt');}
function midiFreq(m){return 440*Math.pow(2,(m-69)/12);}
function makeImpulse(ctx,seconds=1.8,decay=2.5){const len=Math.floor(ctx.sampleRate*seconds),buf=ctx.createBuffer(2,len,ctx.sampleRate);for(let c=0;c<2;c++){const d=buf.getChannelData(c);for(let i=0;i<len;i++)d[i]=(Math.random()*2-1)*Math.pow(1-i/len,decay);}return buf;}
function cachedImpulseV0810(ctx){let b=cachedImpulsesV0810.get(ctx);if(!b){b=makeImpulse(ctx);cachedImpulsesV0810.set(ctx,b);}return b;}
function trackReverbNeededV0813(t){const base=clamp(Number(t?.reverb)||0,0,1);if(base<=.0001)return false;const a=ensureEffectAutomationV071(t,'reverbAutomation');if(!a?.enabled)return true;return (a.points||[]).some(p=>Number(p.value)>.001);}
function sharedTrackReverbInputV0813(ctx,dest,impulse,registry){let row=registry.get(dest);if(row)return row.input;const input=ctx.createGain(),conv=ctx.createConvolver(),wet=ctx.createGain();conv.buffer=impulse;wet.gain.value=.92;input.connect(conv);conv.connect(wet);wet.connect(dest);row={input,conv,wet};registry.set(dest,row);return input;}
function scheduleProject(ctx,when,offline=false,opts={}){
  const {trackIds=null,includeDrums=true,ignoreMuteSolo=false,outputNode=null,resetNodes=true}=opts;
  normalizeAutomationGroupsV077();
  const impulse=offline?makeImpulse(ctx):cachedImpulseV0810(ctx);
  const destination=outputNode||ctx.destination;
  const masterInput=createBusNodeV077(ctx,destination,state.masterBusAutomation,when,impulse,.75);
  const groupInputs=new Map();for(const g of state.automationGroups){if(g.enabled===false)continue;groupInputs.set(g.id,createBusNodeV077(ctx,masterInput,g,when,impulse,1));}
  const sharedTrackReverbs=new Map();
  if(resetNodes)state.nodes=[];
  const anySolo=!ignoreMuteSolo&&state.tracks.some(t=>t.solo&&!t.mute);
  for(const t of state.tracks){
    if(trackIds&& !trackIds.has(t.id))continue;
    if(!ignoreMuteSolo&&(t.mute||(anySolo&&!t.solo)))continue;
    const group=automationGroupForTrackV077(t),trackDest=group&&groupInputs.has(group.id)?groupInputs.get(group.id):masterInput;
    const tg=ctx.createGain();const preset=PRESETS[t.instrument]||{};scheduleTrackVolumeAutomationV070(tg.gain,t,when,state.duration,t.volume*(preset.mixTrim??1));
    const ltcGate=ctx.createGain();scheduleLtcTrackGateV082(ltcGate.gain,t,when);tg.connect(ltcGate);
    const trackFilter=ctx.createBiquadFilter();trackFilter.type='lowpass';trackFilter.Q.value=.22;scheduleEffectAutomationV071(trackFilter.frequency,t,'filterAutomation',when,state.duration,t.filter||preset.filter||16000);ltcGate.connect(trackFilter);let out=trackFilter;
    const pan=ctx.createStereoPanner?ctx.createStereoPanner():null;if(pan){pan.pan.value=t.pan;trackFilter.connect(pan);out=pan;}
    out.connect(trackDest);if(trackReverbNeededV0813(t)){const send=ctx.createGain();scheduleEffectAutomationV071(send.gain,t,'reverbAutomation',when,state.duration,t.reverb);out.connect(send);send.connect(sharedTrackReverbInputV0813(ctx,trackDest,impulse,sharedTrackReverbs));}
    for(const n of t.notes){const h=offline?{jitterSec:0,vel:n.velocity,durScale:1}:realtimeHumanizeForTrack(t,n),startSec=tempoBeatToActualSecV073(n.beat),endSec=tempoBeatToActualSecV073(n.beat+n.dur),durSec=Math.max(.02,endSec-startSec)*h.durScale;scheduleVoice(ctx,tg,when+startSec+h.jitterSec,durSec,n.midi,h.vel,t);}
  }
  if(includeDrums)scheduleDrums(ctx,masterInput,when,offline);
  return masterInput;
}
function schedulePadHQ(ctx,dest,start,dur,midi,vel,t,p){
  const filter=ctx.createBiquadFilter();filter.type='lowpass';filter.frequency.setValueAtTime(t.filter||p.filter||6000,start);filter.Q.value=.35;filter.connect(dest);
  const gain=ctx.createGain();gain.connect(filter);const a=Math.max(.08,t.attack??p.attack??.6),r=Math.max(.8,t.release??p.release??4.5),peak=Math.max(.0002,vel*.105);
  gain.gain.setValueAtTime(.0001,start);gain.gain.exponentialRampToValueAtTime(peak,start+a);gain.gain.setValueAtTime(peak,start+Math.max(a,dur));gain.gain.exponentialRampToValueAtTime(.0001,start+dur+r);
  const group=ctx.createGain();group.gain.value=1;group.connect(gain);
  const lfo=ctx.createOscillator(),lg=ctx.createGain();lfo.frequency.value=p.lfoRate||.06;lg.gain.value=p.lfoDepth||.05;lfo.connect(lg);lg.connect(group.gain);lfo.start(start);lfo.stop(start+dur+r+.1);state.nodes.push(lfo);
  const flfo=ctx.createOscillator(),fg=ctx.createGain();flfo.frequency.value=(p.lfoRate||.06)*.73;fg.gain.value=p.filterDrift||300;flfo.connect(fg);fg.connect(filter.frequency);flfo.start(start);flfo.stop(start+dur+r+.1);state.nodes.push(flfo);
  const base=midiFreq(midi);for(const [cents,amp,wave] of (p.padVoices||[[0,1,'sine']])){const o=ctx.createOscillator(),og=ctx.createGain();o.type=wave||'sine';o.frequency.value=base*Math.pow(2,cents/1200);og.gain.value=amp;o.connect(og);og.connect(group);o.start(start);o.stop(start+dur+r+.08);state.nodes.push(o);}
}
function scheduleVoice(ctx,dest,start,dur,midi,vel,t){
  const p=PRESETS[t.instrument]||PRESETS['Piano feutré'];
  if(p.engine==='custom-sample'&&window.LTCCustomSamples){const ok=window.LTCCustomSamples.schedule(p.sampleId,ctx,dest,start,dur,vel,t,state.nodes);if(ok)return;}
  if(p.engine==='multisample'&&window.LTCSampleEngine){const ok=window.LTCSampleEngine.schedule(p.packId,ctx,dest,start,dur,midi,vel,t,state.nodes);if(ok)return;}
  if(p.engine==='pad-hq'){schedulePadHQ(ctx,dest,start,dur,midi,vel,t,p);return;}
  if(p.percussion){schedulePerc(ctx,dest,start,vel,p.percussion,t);return;}
  const filter=ctx.createBiquadFilter();filter.type='lowpass';filter.frequency.value=t.filter||p.filter||12000;filter.connect(dest);
  const gain=ctx.createGain();gain.connect(filter);const a=Math.max(AUDIO_MICRO_FADE_IN_V08157,t.attack||0),r=Math.max(AUDIO_MICRO_FADE_OUT_V08157,.05,t.release||0),peak=Math.max(.0002,vel*.18);gain.gain.setValueAtTime(.0001,start);gain.gain.exponentialRampToValueAtTime(peak,start+a);if(p.kind==='pluck'){const d=Math.min(Math.max(.18,dur*.45),.9);gain.gain.exponentialRampToValueAtTime(Math.max(.0002,peak*.24),start+a+d);gain.gain.exponentialRampToValueAtTime(.0001,start+Math.max(dur,a+d)+r);}else if(p.kind==='key'){gain.gain.exponentialRampToValueAtTime(Math.max(.0002,peak*.55),start+a+Math.min(.7,dur*.35));gain.gain.setValueAtTime(Math.max(.0002,peak*.50),start+Math.max(a+.1,dur));gain.gain.exponentialRampToValueAtTime(.0001,start+dur+r);}else{gain.gain.setValueAtTime(peak,start+Math.max(a,dur));gain.gain.exponentialRampToValueAtTime(.0001,start+dur+r);}
  (p.partials||[[1,1]]).forEach(([ratio,amp])=>{const o=ctx.createOscillator();o.type=p.wave||'sine';o.frequency.value=midiFreq(midi)*ratio;const og=ctx.createGain();og.gain.value=amp;o.connect(og);og.connect(gain);o.start(start);o.stop(start+dur+r+.05);state.nodes.push(o);});
}
function schedulePerc(ctx,dest,start,vel,type,t={}){
  const g=ctx.createGain();g.connect(dest);const peak=Math.max(.0001,vel*.2);g.gain.setValueAtTime(.0001,start);g.gain.linearRampToValueAtTime(peak,start+.003);g.gain.exponentialRampToValueAtTime(.0001,start+(type==='shaker'?.12:type==='triangle'?1.8:.32));
  if(type==='shaker'){const len=Math.floor(ctx.sampleRate*.14),buf=ctx.createBuffer(1,len,ctx.sampleRate),d=buf.getChannelData(0);for(let i=0;i<len;i++)d[i]=(Math.random()*2-1);const src=ctx.createBufferSource();src.buffer=buf;const f=ctx.createBiquadFilter();f.type='highpass';f.frequency.value=5000;src.connect(f);f.connect(g);src.start(start);}
  else if(type==='triangle'){const o=ctx.createOscillator();o.type='sine';o.frequency.value=1046.5;o.connect(g);o.start(start);o.stop(start+1.9);}
  else {const o=ctx.createOscillator();o.type=type==='wood'?'triangle':'sine';o.frequency.setValueAtTime(type==='wood'?180:90,start);o.frequency.exponentialRampToValueAtTime(type==='wood'?120:55,start+.20);o.connect(g);o.start(start);o.stop(start+.35);}
}
function rhythmEventPriorityV072(name,step,cycle){
  let base=String(name).includes('Hand drum')?.08:String(name).includes('bois')?.24:String(name).includes('Triangle')?.38:.52;
  if(step%8===0)base=Math.max(.03,base-.12);else if(step%4===0)base=Math.max(.06,base-.06);
  let h=2166136261>>>0;const key=`${name}|${step}|${cycle}`;for(let i=0;i<key.length;i++){h^=key.charCodeAt(i);h=Math.imul(h,16777619)>>>0;}
  return clamp(base+(h/4294967295)*Math.max(.05,1-base)*.62,0,1);
}
function scheduleRhythmIntensityV072(param,when,totalSec){
  const a=ensureRhythmAutomationV072('rhythmIntensityAutomation');try{param.cancelScheduledValues(when);}catch{}
  if(!a.enabled){param.setValueAtTime(1,when);return;}const pts=a.points.map(p=>({sec:clamp(p.sec,0,totalSec),value:p.value}));param.setValueAtTime(Math.max(.0001,pts[0].value),when+tempoNominalToActualV073(pts[0].sec));
  for(let i=1;i<pts.length;i++){const p0=pts[i-1],p1=pts[i],d=p1.sec-p0.sec;if(d<=.001)continue;if(a.curve==='linear')param.linearRampToValueAtTime(Math.max(.0001,p1.value),when+tempoNominalToActualV073(p1.sec));else{for(let j=1;j<=18;j++){const u=j/18,k=(1-Math.cos(Math.PI*u))/2,v=p0.value+(p1.value-p0.value)*k;param.linearRampToValueAtTime(Math.max(.0001,v),when+tempoNominalToActualV073(p0.sec+d*u));}}}
}
function scheduleDrums(ctx,dest,when){const stepBeat=.5,patternBeats=8,total=totalBeats();const drumGain=ctx.createGain();scheduleRhythmIntensityV072(drumGain.gain,when,state.duration);const ltcDrumGain=ctx.createGain();scheduleLtcCivilisationDrumGainV084(ltcDrumGain.gain,when);drumGain.connect(ltcDrumGain);ltcDrumGain.connect(dest);const civDensity=ltcCivilisationDrumFactorV084();for(const [name,set] of Object.entries(state.drums)){const p=PRESETS[name]||PRESETS['Percussion bois'];for(let base=0;base<total;base+=patternBeats){const cycle=Math.floor(base/patternBeats);for(const s of set){const beat=base+s*stepBeat;if(beat>=total)continue;const nominalSec=beat*60/state.bpm,density=clamp(rhythmAutomationValueAtV072('rhythmDensityAutomation',nominalSec)*civDensity,0,1);if(density<.995&&rhythmEventPriorityV072(name,s,cycle)>density)continue;const start=when+tempoBeatToActualSecV073(beat);let ok=false;if(p.engine==='multisample'&&window.LTCSampleEngine){const drumTrack={attack:p.attack,release:p.release,filter:p.filter};ok=window.LTCSampleEngine.schedule(p.packId,ctx,drumGain,start,.35,p.percussionMidi??60,.55,drumTrack,state.nodes);}if(!ok)schedulePerc(ctx,drumGain,start,.55,p.percussionFallback||p.percussion||'wood');}}}}

function createLiveOutputV0810(ctx){
  try{liveAudioV0810.master?.disconnect();liveAudioV0810.dcFilter?.disconnect();liveAudioV0810.limiter?.disconnect();liveAudioV0810.ceiling?.disconnect();}catch{}
  const master=ctx.createGain(),dc=ctx.createBiquadFilter(),limiter=ctx.createDynamicsCompressor(),ceiling=ctx.createWaveShaper();
  const now=ctx.currentTime;master.gain.setValueAtTime(.0001,now);master.gain.linearRampToValueAtTime(LIVE_MASTER_GAIN_V0813,now+.025);
  dc.type='highpass';dc.frequency.value=18;dc.Q.value=.55;
  limiter.threshold.value=-10;limiter.knee.value=8;limiter.ratio.value=10;limiter.attack.value=.003;limiter.release.value=.14;
  ceiling.curve=audioSoftCeilingCurveV0813();try{ceiling.oversample='2x';}catch{}
  master.connect(dc);dc.connect(limiter);limiter.connect(ceiling);ceiling.connect(ctx.destination);liveAudioV0810.ctx=ctx;liveAudioV0810.master=master;liveAudioV0810.dcFilter=dc;liveAudioV0810.limiter=limiter;liveAudioV0810.ceiling=ceiling;return master;
}
function scheduleLiveCycleV0810(index){
  const ctx=liveAudioV0810.ctx;if(!ctx||!state.playing)return;const sec=liveAudioV0810.cycleSec,when=state.startAudioTime+index*sec,xf=Math.min(liveAudioV0810.crossfade,Math.max(.06,sec*.02));
  const cycle=ctx.createGain();cycle.connect(liveAudioV0810.master);
  // V0.8.13: raccord continu. Le cycle sortant décroît pendant que le suivant monte, sans saut de gain.
  const fadeOut=Math.min(.22,Math.max(.08,xf)),fadeIn=index>0?fadeOut:Math.min(.018,xf*.18);
  cycle.gain.setValueAtTime(.0001,when);cycle.gain.linearRampToValueAtTime(1,when+fadeIn);
  cycle.gain.setValueAtTime(1,Math.max(when+fadeIn,when+sec));cycle.gain.linearRampToValueAtTime(.0001,when+sec+fadeOut);
  if(index>0)state.nodes=[];
  scheduleProject(ctx,when,false,{outputNode:cycle,resetNodes:false});
  liveAudioV0810.scheduledCycle=index;
}
function armNextCycleV0810(){
  if(!state.playing||!state.loop)return;clearTimeout(liveAudioV0810.cycleTimer);const ctx=liveAudioV0810.ctx,next=liveAudioV0810.scheduledCycle+1,nextAt=state.startAudioTime+next*liveAudioV0810.cycleSec;
  const delay=Math.max(0,(nextAt-ctx.currentTime-2.2)*1000);liveAudioV0810.cycleTimer=setTimeout(()=>{if(!state.playing||!state.loop)return;scheduleLiveCycleV0810(next);armNextCycleV0810();},delay);
}
async function play(){
  if(state.playing)return;const ctx=ensureAudio();await ctx.resume();await preloadProjectSamples(ctx);state.nodes=[];state.playing=true;state.startAudioTime=ctx.currentTime+.20;liveAudioV0810.cycleSec=tempoActualDurationV073();createLiveOutputV0810(ctx);scheduleLiveCycleV0810(0);
  if(state.loop)armNextCycleV0810();else state.playTimer=setTimeout(()=>stop(false),(liveAudioV0810.cycleSec+.12)*1000);animatePlayhead();
}
function stop(reset=true){
  if(state.playTimer)clearTimeout(state.playTimer);state.playTimer=null;if(liveAudioV0810.cycleTimer)clearTimeout(liveAudioV0810.cycleTimer);liveAudioV0810.cycleTimer=null;
  const ctx=state.audioCtx,master=liveAudioV0810.master,dc=liveAudioV0810.dcFilter,limiter=liveAudioV0810.limiter,ceiling=liveAudioV0810.ceiling,nodes=state.nodes.splice(0);if(ctx&&master){try{master.gain.cancelScheduledValues(ctx.currentTime);master.gain.setValueAtTime(Math.max(.0001,master.gain.value||.94),ctx.currentTime);master.gain.linearRampToValueAtTime(.0001,ctx.currentTime+.025);}catch{}}
  setTimeout(()=>{nodes.forEach(n=>{try{n.stop()}catch{}});try{master?.disconnect();dc?.disconnect();limiter?.disconnect();ceiling?.disconnect();}catch{}},45);
  state.playing=false;if(state.playheadRAF)cancelAnimationFrame(state.playheadRAF);if(reset){$('#playheadLabel').textContent='00:00.0';renderRoll();}
}
function currentPlaySeconds(){if(!state.playing||!state.audioCtx)return 0;const elapsed=Math.max(0,state.audioCtx.currentTime-state.startAudioTime),sec=liveAudioV0810.cycleSec||tempoActualDurationV073();return state.loop&&sec>0?elapsed%sec:clamp(elapsed,0,sec);}
function currentPlayBeat(){return tempoActualToNominalV073(currentPlaySeconds())*state.bpm/60;}
function animatePlayhead(ts=0){const s=currentPlaySeconds();$('#playheadLabel').textContent=fmtTime(s);if(ts-lastPlayheadPaint>PLAYHEAD_PAINT_MS_V0813){lastPlayheadPaint=ts;renderRoll();const x=currentPlayBeat()*beatWidth(),left=els.rollScroller.scrollLeft,right=left+els.rollScroller.clientWidth;if(uxPrefsV088.followPlayhead===true&&!uxNavGestureV089.active&&x>right-80)els.rollScroller.scrollLeft=x-120;}if(state.playing)state.playheadRAF=requestAnimationFrame(animatePlayhead);}
function fmtTime(s){return String(Math.floor(s/60)).padStart(2,'0')+':'+String(Math.floor(s%60)).padStart(2,'0')+'.'+Math.floor((s%1)*10);}

function openExport(){
  els.exportModal.classList.remove('hidden');
  setExportProgress(0,'');
  syncExportUiV08155();
  detectExportSupport();
}
function closeExport(){if($('#exportConfirmBtn')?.disabled)return;els.exportModal.classList.add('hidden');}
function exportSettings(){const [sr,bitrate]=String(els.exportQuality.value||'48000-192').split('-').map(Number);return {sampleRate:sr||48000,bitrate:(bitrate||192)*1000,normalize:!!els.exportNormalize.checked,fade:+els.exportFade.value||0};}
function selectedExportFormatV08155(){return $('input[name="exportFormat"]:checked')?.value||'wav';}
function selectedExportScopeV08155(){return els.exportScope?.value||'master';}
function selectedTrackExportV08155(){const t=currentTrack();if(!t)throw new Error('Aucune piste sélectionnée');return t;}
function exportRenderOptionsV08155(mode){if(mode==='track'){const t=selectedTrackExportV08155();return {opts:{trackIds:new Set([t.id]),includeDrums:false,ignoreMuteSolo:true},suffix:'_'+safeName(t.name)};}return {opts:{},suffix:''};}
function syncExportUiV08155(){
  const scope=selectedExportScopeV08155();
  if(scope==='stems'){
    const wav=$('input[name="exportFormat"][value="wav"]');if(wav)wav.checked=true;
  }
  $$('[data-format-card]').forEach(card=>{
    const input=card.querySelector('input');
    const forcedOff=scope==='stems'&&input.value!=='wav';
    input.disabled=forcedOff||card.dataset.unsupported==='1';
    card.classList.toggle('unsupported',input.disabled);
  });
  const checked=$('input[name="exportFormat"]:checked');if(!checked||checked.disabled){const wav=$('input[name="exportFormat"][value="wav"]');if(wav)wav.checked=true;}
  $$('[data-format-card]').forEach(card=>{const input=card.querySelector('input');card.classList.toggle('selected',input.checked&&!input.disabled);});
  const confirm=$('#exportConfirmBtn');if(confirm)confirm.textContent=scope==='stems'?'Exporter les stems':'Exporter';
}
async function runSelectedExportV08155(){
  const scope=selectedExportScopeV08155(),format=selectedExportFormatV08155();
  if(scope==='stems')return exportStemsV08155();
  if(format==='wav')return exportWavV08155({mode:scope});
  if(format==='m4a')return exportM4aV08155({mode:scope});
  if(format==='mp3')return exportNativeCompressedV08155('mp3',{mode:scope});
  if(format==='opus')return exportNativeCompressedV08155('opus',{mode:scope});
}
function setExportProgress(p,text){if(!els.exportProgress)return;if(!text){els.exportProgress.classList.add('hidden');return;}els.exportProgress.classList.remove('hidden');els.exportProgressBar.style.width=Math.round(clamp(p,0,1)*100)+'%';els.exportProgressText.textContent=text;}
function setExportBusy(busy){
  const confirm=$('#exportConfirmBtn'),cancel=$('#cancelExportBtn'),close=$('#closeExportBtn'),card=$('.export-card');
  if(confirm)confirm.disabled=busy;if(cancel)cancel.disabled=busy;if(close)close.disabled=busy;
  $('#loopCheckBtn').disabled=busy;els.exportScope.disabled=busy;els.exportQuality.disabled=busy;els.exportNormalize.disabled=busy;els.exportFade.disabled=busy;
  $$('input[name="exportFormat"]').forEach(x=>x.disabled=busy||x.closest('[data-format-card]')?.dataset.unsupported==='1'||(selectedExportScopeV08155()==='stems'&&x.value!=='wav'));
  card?.classList.toggle('export-busy',busy);
  if(!busy)syncExportUiV08155();
}
async function renderExportBuffer(opts={}){const cfg=exportSettings(),len=Math.ceil(tempoActualDurationV073()*cfg.sampleRate);const ctx=new OfflineAudioContext(2,len,cfg.sampleRate);await preloadProjectSamples(ctx);scheduleProject(ctx,0,true,opts);const buf=await ctx.startRendering();processExportBuffer(buf,cfg);return buf;}
function processExportBuffer(buf,cfg){const n=buf.length,ch=buf.numberOfChannels;let peak=0;for(let c=0;c<ch;c++){const d=buf.getChannelData(c);for(let i=0;i<n;i++){const a=Math.abs(d[i]);if(a>peak)peak=a;}}const target=Math.pow(10,-1/20),safety=Math.pow(10,-.35/20),normGain=cfg.normalize&&peak>1e-6?Math.min(8,target/peak):1,clipGain=peak*normGain>safety?safety/(peak*normGain):1,gain=normGain*clipGain;const userFade=Math.min(Math.floor(cfg.fade*buf.sampleRate),Math.floor(n/2)),edge=Math.min(Math.floor(AUDIO_EDGE_FADE_V0811*buf.sampleRate),Math.floor(n/4));for(let c=0;c<ch;c++){const d=buf.getChannelData(c);for(let i=0;i<n;i++){let g=gain;if(userFade&&i<userFade)g*=i/userFade;if(userFade&&i>=n-userFade)g*=(n-1-i)/userFade;if(!userFade&&edge&&i<edge)g*=i/edge;if(!userFade&&edge&&i>=n-edge)g*=(n-1-i)/edge;d[i]=clamp(d[i]*g,-safety,safety);}}}
async function exportWavV08155({mode='master'}={}){let target;try{const {opts,suffix}=exportRenderOptionsV08155(mode),name=safeName(state.projectName)+suffix+'.wav';target=await requestSaveTargetV08155(name,'audio/wav','wav','Audio WAV');if(target.cancelled)return;setExportBusy(true);setExportProgress(.05,'Rendu audio…');const buf=await renderExportBuffer(opts);setExportProgress(.80,'Création du WAV…');const blob=new Blob([audioBufferToWav(buf)],{type:'audio/wav'});await saveBlobTargetV08155(blob,target,name,p=>setExportProgress(.82+p*.17,'Écriture du fichier…'));setExportProgress(1,'WAV enregistré');toast('WAV enregistré');}catch(e){await abortNativeSaveV08155(target);alert('Export impossible : '+e.message);}finally{setTimeout(()=>setExportProgress(0,''),900);setExportBusy(false);detectExportSupport();}}
async function exportStemsV08155(){try{setExportBusy(true);const total=state.tracks.length+1;let i=0;for(const t of state.tracks){setExportProgress(i/total,'Rendu '+(i+1)+'/'+total+' : '+t.name);const buf=await renderExportBuffer({trackIds:new Set([t.id]),includeDrums:false,ignoreMuteSolo:true}),name=safeName(state.projectName)+'__'+String(i+1).padStart(2,'0')+'_'+safeName(t.name)+'.wav',blob=new Blob([audioBufferToWav(buf)],{type:'audio/wav'}),target=await requestSaveTargetV08155(name,'audio/wav','wav','Stem WAV');if(target.cancelled)throw new Error('Export des stems annulé');await saveBlobTargetV08155(blob,target,name,p=>setExportProgress((i+p*.8)/total,'Écriture '+(i+1)+'/'+total+'…'));i++;}setExportProgress(i/total,'Rendu Rythme '+(i+1)+'/'+total);const drums=await renderExportBuffer({trackIds:new Set(),includeDrums:true,ignoreMuteSolo:true}),name=safeName(state.projectName)+'__Rythme.wav',blob=new Blob([audioBufferToWav(drums)],{type:'audio/wav'}),target=await requestSaveTargetV08155(name,'audio/wav','wav','Stem WAV');if(target.cancelled)throw new Error('Export des stems annulé');await saveBlobTargetV08155(blob,target,name,p=>setExportProgress((i+p*.8)/total,'Écriture Rythme…'));setExportProgress(1,'Stems enregistrés');toast('Stems WAV enregistrés');}catch(e){if(e.message!=='Export des stems annulé')alert('Export stems impossible : '+e.message);}finally{setTimeout(()=>setExportProgress(0,''),900);setExportBusy(false);detectExportSupport();}}
function delay(ms){return new Promise(r=>setTimeout(r,ms));}
function audioBufferToWav(buffer){const num=buffer.numberOfChannels,len=buffer.length*num*2+44,ab=new ArrayBuffer(len),v=new DataView(ab);let p=0;const str=s=>{for(let i=0;i<s.length;i++)v.setUint8(p++,s.charCodeAt(i));};str('RIFF');v.setUint32(p,36+buffer.length*num*2,true);p+=4;str('WAVEfmt ');v.setUint32(p,16,true);p+=4;v.setUint16(p,1,true);p+=2;v.setUint16(p,num,true);p+=2;v.setUint32(p,buffer.sampleRate,true);p+=4;v.setUint32(p,buffer.sampleRate*num*2,true);p+=4;v.setUint16(p,num*2,true);p+=2;v.setUint16(p,16,true);p+=2;str('data');v.setUint32(p,buffer.length*num*2,true);p+=4;const chans=[];for(let c=0;c<num;c++)chans.push(buffer.getChannelData(c));for(let i=0;i<buffer.length;i++)for(let c=0;c<num;c++){let s=clamp(chans[c][i],-1,1);v.setInt16(p,s<0?s*0x8000:s*0x7fff,true);p+=2;}return ab;}


async function detectExportSupport(){
  let aac=false;if(typeof AudioEncoder!=='undefined'&&AudioEncoder.isConfigSupported){try{aac=(await AudioEncoder.isConfigSupported({codec:'mp4a.40.2',sampleRate:48000,numberOfChannels:2,bitrate:192000})).supported;}catch{}}
  const mp3Mime=nativeMime(['audio/mpeg','audio/mp3']),oggMime=nativeMime(['audio/ogg;codecs=opus','audio/webm;codecs=opus']);
  const setCard=(fmt,supported,mime,text)=>{const card=$(`[data-format-card="${fmt}"]`),input=card?.querySelector('input');if(!card||!input)return;card.dataset.unsupported=supported?'0':'1';if(mime)input.dataset.mime=mime;card.classList.toggle('unsupported',!supported);const span=card.querySelector('span');if(span)span.textContent=text;};
  setCard('wav',true,'audio/wav','Sans perte • recommandé');
  setCard('m4a',aac,'audio/mp4',aac?'Compact • AAC disponible':'AAC non disponible sur ce téléphone');
  setCard('mp3',!!mp3Mime,mp3Mime,mp3Mime?'Disponible • encodage en temps réel':'MP3 natif indisponible • utilise WAV/M4A');
  setCard('opus',!!oggMime,oggMime,oggMime?(oggMime.startsWith('audio/ogg')?'OGG/Opus disponible':'Opus disponible en .webm'):'Opus natif indisponible');
  $('#m4aSupportText').textContent=aac?'Compact • AAC disponible':'AAC non disponible sur ce téléphone';
  $('#mp3SupportText').textContent=mp3Mime?'Disponible • encodage en temps réel':'MP3 natif indisponible';
  $('#oggSupportText').textContent=oggMime?(oggMime.startsWith('audio/ogg')?'OGG/Opus disponible':'Opus disponible en WEBM'):'Opus natif indisponible';
  syncExportUiV08155();
}
function nativeMime(list){if(typeof MediaRecorder==='undefined'||!MediaRecorder.isTypeSupported)return'';return list.find(x=>MediaRecorder.isTypeSupported(x))||'';}
async function exportM4aV08155({mode='master'}={}){let target;try{const {opts,suffix}=exportRenderOptionsV08155(mode),name=safeName(state.projectName)+suffix+'.m4a';target=await requestSaveTargetV08155(name,'audio/mp4','m4a','Audio M4A / AAC');if(target.cancelled)return;setExportBusy(true);setExportProgress(.05,'Rendu audio…');const buf=await renderExportBuffer(opts);setExportProgress(.42,'Encodage AAC…');const cfg=exportSettings();const blob=await encodeM4a(buf,cfg.bitrate,p=>setExportProgress(.42+p*.45,'Encodage M4A…'));await saveBlobTargetV08155(blob,target,name,p=>setExportProgress(.87+p*.12,'Écriture du fichier…'));setExportProgress(1,'M4A enregistré');toast('M4A enregistré');}catch(e){await abortNativeSaveV08155(target);alert('Export M4A impossible : '+e.message);}finally{setTimeout(()=>setExportProgress(0,''),900);setExportBusy(false);detectExportSupport();}}
async function encodeM4a(buffer,bitrate,onProgress){
  if(typeof AudioEncoder==='undefined')throw new Error('AudioEncoder non disponible');const sr=buffer.sampleRate,channels=Math.min(2,buffer.numberOfChannels),config={codec:'mp4a.40.2',sampleRate:sr,numberOfChannels:channels,bitrate};const sup=await AudioEncoder.isConfigSupported(config);if(!sup.supported)throw new Error('AAC non pris en charge par ce téléphone');
  const chunks=[];let description=null;const encoder=new AudioEncoder({output:(chunk,meta)=>{const d=new Uint8Array(chunk.byteLength);chunk.copyTo(d);chunks.push({data:d,timestamp:chunk.timestamp,duration:chunk.duration||Math.round(1024e6/sr)});if(meta?.decoderConfig?.description)description=new Uint8Array(meta.decoderConfig.description);},error:e=>{throw e;}});encoder.configure(config);
  const frame=1024,total=buffer.length;for(let pos=0;pos<total;pos+=frame){const count=Math.min(frame,total-pos),data=new Float32Array(count*channels);for(let c=0;c<channels;c++)data.set(buffer.getChannelData(c).subarray(pos,pos+count),c*count);const ad=new AudioData({format:'f32-planar',sampleRate:sr,numberOfFrames:count,numberOfChannels:channels,timestamp:Math.round(pos*1e6/sr),data});encoder.encode(ad);ad.close();if(pos%(frame*40)===0){onProgress?.(pos/total);await new Promise(r=>setTimeout(r,0));}}
  await encoder.flush();encoder.close();onProgress?.(1);if(!chunks.length)throw new Error('Aucune donnée AAC produite');return new Blob([buildM4a(chunks,sr,channels,bitrate,description)],{type:'audio/mp4'});
}
function bcat(...parts){const len=parts.reduce((n,p)=>n+p.length,0),out=new Uint8Array(len);let o=0;for(const p of parts){out.set(p,o);o+=p.length;}return out;}
function bstr(s){return Uint8Array.from([...s].map(c=>c.charCodeAt(0)&255));}
function bu16(n){return Uint8Array.of((n>>>8)&255,n&255);}function bu24(n){return Uint8Array.of((n>>>16)&255,(n>>>8)&255,n&255);}function bu32(n){n=Math.floor(n)>>>0;return Uint8Array.of((n>>>24)&255,(n>>>16)&255,(n>>>8)&255,n&255);}function bz(n){return new Uint8Array(n);}
function box(type,...payload){const body=bcat(...payload);return bcat(bu32(body.length+8),bstr(type),body);}function fullbox(type,version,flags,...payload){return box(type,Uint8Array.of(version,(flags>>>16)&255,(flags>>>8)&255,flags&255),...payload);}
function descriptor(tag,payload){let n=payload.length,bytes=[n&127];n>>>=7;while(n){bytes.unshift((n&127)|128);n>>>=7;}return bcat(Uint8Array.of(tag,...bytes),payload);}
function aacAsc(sr,ch){const rates=[96000,88200,64000,48000,44100,32000,24000,22050,16000,12000,11025,8000,7350];let i=rates.indexOf(sr);if(i<0)i=3;const aot=2;return Uint8Array.of((aot<<3)|(i>>1),((i&1)<<7)|(ch<<3));}
function buildM4a(chunks,sr,ch,bitrate,desc){const data=bcat(...chunks.map(c=>c.data)),ftyp=box('ftyp',bstr('M4A '),bu32(0),bstr('M4A '),bstr('mp42'),bstr('isom'));const mdat=box('mdat',data),offset=ftyp.length+8;const durations=chunks.map(c=>Math.max(1,Math.round((c.duration||1024e6/sr)*sr/1e6)));const totalSamples=durations.reduce((a,b)=>a+b,0),movieDur=Math.round(totalSamples*1000/sr);const sttsEntries=[];for(const d of durations){const last=sttsEntries.at(-1);if(last&&last[1]===d)last[0]++;else sttsEntries.push([1,d]);}const stts=fullbox('stts',0,0,bu32(sttsEntries.length),...sttsEntries.flatMap(([c,d])=>[bu32(c),bu32(d)]));const stsc=fullbox('stsc',0,0,bu32(1),bu32(1),bu32(chunks.length),bu32(1));const stsz=fullbox('stsz',0,0,bu32(0),bu32(chunks.length),...chunks.map(c=>bu32(c.data.length)));const stco=fullbox('stco',0,0,bu32(1),bu32(offset));const asc=desc&&desc.length?desc:aacAsc(sr,ch);const dsi=descriptor(0x05,asc);const dec=descriptor(0x04,bcat(Uint8Array.of(0x40,0x15),bu24(0),bu32(bitrate),bu32(bitrate),dsi));const sl=descriptor(0x06,Uint8Array.of(0x02));const es=descriptor(0x03,bcat(bu16(1),Uint8Array.of(0),dec,sl));const esds=fullbox('esds',0,0,es);const mp4a=box('mp4a',bz(6),bu16(1),bz(8),bu16(ch),bu16(16),bu16(0),bu16(0),bu32(sr<<16),esds);const stsd=fullbox('stsd',0,0,bu32(1),mp4a);const stbl=box('stbl',stsd,stts,stsc,stsz,stco);const url=fullbox('url ',0,1),dref=fullbox('dref',0,0,bu32(1),url),dinf=box('dinf',dref),smhd=fullbox('smhd',0,0,bu16(0),bu16(0)),minf=box('minf',smhd,dinf,stbl);const mdhd=fullbox('mdhd',0,0,bu32(0),bu32(0),bu32(sr),bu32(totalSamples),bu16(0x55c4),bu16(0));const hdlr=fullbox('hdlr',0,0,bu32(0),bstr('soun'),bz(12),bstr('SoundHandler\0'));const mdia=box('mdia',mdhd,hdlr,minf);const matrix=bcat(bu32(0x00010000),bu32(0),bu32(0),bu32(0),bu32(0x00010000),bu32(0),bu32(0),bu32(0),bu32(0x40000000));const tkhd=fullbox('tkhd',0,7,bu32(0),bu32(0),bu32(1),bu32(0),bu32(movieDur),bz(8),bu16(0),bu16(0),bu16(0x0100),bu16(0),matrix,bu32(0),bu32(0));const trak=box('trak',tkhd,mdia);const mvhd=fullbox('mvhd',0,0,bu32(0),bu32(0),bu32(1000),bu32(movieDur),bu32(0x00010000),bu16(0x0100),bu16(0),bz(8),matrix,bz(24),bu32(2));const moov=box('moov',mvhd,trak);return bcat(ftyp,mdat,moov);}

async function exportNativeCompressedV08155(kind,{mode='master'}={}){const input=$(`input[name="exportFormat"][value="${kind==='mp3'?'mp3':'opus'}"]`),mime=input?.dataset.mime;if(!mime)return alert('Ce format n’est pas encodable par ce téléphone. Utilise M4A ou WAV.');const ext=kind==='mp3'?'mp3':(mime.startsWith('audio/ogg')?'ogg':'webm'),{opts,suffix}=exportRenderOptionsV08155(mode),name=safeName(state.projectName)+suffix+'.'+ext;let target;try{target=await requestSaveTargetV08155(name,mime,ext,'Audio '+ext.toUpperCase());if(target.cancelled)return;setExportBusy(true);setExportProgress(.03,'Rendu audio…');const buf=await renderExportBuffer(opts);const blob=await recordBufferNative(buf,mime,p=>setExportProgress(.15+p*.70,'Encodage '+ext.toUpperCase()+' en temps réel…'));await saveBlobTargetV08155(blob,target,name,p=>setExportProgress(.86+p*.13,'Écriture du fichier…'));setExportProgress(1,ext.toUpperCase()+' enregistré');toast(ext.toUpperCase()+' enregistré');}catch(e){await abortNativeSaveV08155(target);alert('Export impossible : '+e.message);}finally{setTimeout(()=>setExportProgress(0,''),900);setExportBusy(false);detectExportSupport();}}
async function recordBufferNative(buffer,mime,onProgress){const ctx=new (window.AudioContext||window.webkitAudioContext)({sampleRate:buffer.sampleRate});await ctx.resume();const dest=ctx.createMediaStreamDestination(),src=ctx.createBufferSource();src.buffer=buffer;src.connect(dest);const rec=new MediaRecorder(dest.stream,{mimeType:mime,audioBitsPerSecond:exportSettings().bitrate});const parts=[];rec.ondataavailable=e=>{if(e.data.size)parts.push(e.data);};const done=new Promise((res,rej)=>{rec.onerror=e=>rej(e.error||new Error('MediaRecorder'));rec.onstop=()=>res(new Blob(parts,{type:mime}));});rec.start(1000);const started=performance.now(),timer=setInterval(()=>onProgress?.(Math.min(1,(performance.now()-started)/(buffer.duration*1000))),250);src.onended=()=>rec.state!=='inactive'&&rec.stop();src.start();const blob=await done;clearInterval(timer);await ctx.close();onProgress?.(1);return blob;}
async function checkLoopSeam(){try{setExportBusy(true);els.loopCheckResult.textContent='Analyse…';const cfg=exportSettings(),oldNorm=cfg.normalize,oldFade=cfg.fade;const len=Math.ceil(tempoActualDurationV073()*44100),ctx=new OfflineAudioContext(2,len,44100);await preloadProjectSamples(ctx);scheduleProject(ctx,0,true);const buf=await ctx.startRendering(),win=Math.min(Math.floor(.25*buf.sampleRate),Math.floor(buf.length/4));let diff=0,sig=0,count=0;for(let c=0;c<buf.numberOfChannels;c++){const d=buf.getChannelData(c);for(let i=0;i<win;i++){const a=d[i],b=d[d.length-win+i];diff+=(a-b)*(a-b);sig+=(a*a+b*b)*.5;count++;}}const ratio=Math.sqrt(diff/count)/(Math.sqrt(sig/count)+1e-9),db=20*Math.log10(ratio+1e-9);let label=db<-28?'Excellent':db<-20?'Bon':db<-13?'Moyen':'Raccord audible';els.loopCheckResult.textContent=label+' • écart '+db.toFixed(1)+' dB';els.loopCheckResult.className='loop-result '+(db<-20?'good':db<-13?'warn':'bad');}catch(e){els.loopCheckResult.textContent='Erreur : '+e.message;}finally{setExportBusy(false);detectExportSupport();}}

const LIB_KEY='ltcMusicStudioLibraryV040', AUTO_KEY='ltcMusicStudioAutosaveV040', OLD_LIB_KEY='ltcMusicStudioLibraryV03', OLD_AUTO_KEY='ltcMusicStudioAutosaveV03';
function markDirty(){state.dirty=true;updateAutosaveStatus('Modifié');}
function updateAutosaveStatus(txt){if(els.autosaveStatus)els.autosaveStatus.textContent=txt;}
function library(){try{let raw=localStorage.getItem(LIB_KEY);if(!raw){raw=localStorage.getItem(OLD_LIB_KEY);if(raw)localStorage.setItem(LIB_KEY,raw);}return JSON.parse(raw||'[]');}catch{return [];}}
function writeLibrary(items){localStorage.setItem(LIB_KEY,JSON.stringify(items));}
function autosave(){if(!state.dirty)return;localStorage.setItem(AUTO_KEY,snapshot());if(state.projectId){const items=library(),i=items.findIndex(x=>x.id===state.projectId);if(i>=0){items[i].project=snapshot();items[i].updatedAt=Date.now();items[i].name=state.projectName;items[i].tag=state.projectTag;writeLibrary(items);}}state.dirty=false;updateAutosaveStatus('Autosauvé');}
function restoreAutosave(){let s=localStorage.getItem(AUTO_KEY);if(!s){s=localStorage.getItem(OLD_AUTO_KEY);if(s)localStorage.setItem(AUTO_KEY,s);}if(!s)return;try{restore(s);updateAutosaveStatus('Autosave restauré');}catch{}}
function saveToLibrary(){let items=library();if(!state.projectId)state.projectId=uid();const now=Date.now(),i=items.findIndex(x=>x.id===state.projectId),project=snapshot();if(i>=0){const old=items[i];const revisions=old.revisions||[];if(old.project&&old.project!==project)revisions.unshift({savedAt:old.updatedAt||now,project:old.project});items[i]={...old,name:state.projectName||'Sans titre',tag:state.projectTag,updatedAt:now,project,revisions:revisions.slice(0,5)};}else{items.unshift({id:state.projectId,name:state.projectName||'Sans titre',tag:state.projectTag,createdAt:now,updatedAt:now,project,revisions:[]});}writeLibrary(items);localStorage.setItem(AUTO_KEY,project);state.dirty=false;updateAutosaveStatus('Sauvegardé');toast('Composition sauvegardée');renderLibrary();}
function saveCopyToLibrary(){const oldId=state.projectId,oldName=state.projectName;state.projectId=null;state.projectName=(oldName||'Composition')+' - copie';els.projectName.value=state.projectName;saveToLibrary();closeLibrary();toast('Copie créée');}
function newComposition(){if(state.dirty&&!confirm('Créer une nouvelle composition ? Le travail actuel non sauvegardé restera seulement dans l’autosave.'))return;stop();const fresh=[mkTrack('Guitare','🎸 Guitare classique sèche HQ',0),mkTrack('Rhodes','🎹 Rhodes HQ',1),mkTrack('Pad','🌫 Pad chaud HQ',2),mkTrack('Basse','🎸 Basse ronde HQ',3)];const d=10*4*60/76;state.projectId=null;state.projectName='Nouvelle composition';state.projectTag='Autre';state.bpm=76;state.key=0;state.bars=10;state.duration=d;state.grid=.5;state.zoom=58;state.tracks=fresh;state.selectedTrackId=fresh[0].id;state.selectedNoteId=null;measureEditV08157.active=false;measureEditV08157.startBar=null;measureEditV08157.endBar=null;measureEditV08157.dragging=false;measureEditV08157.pointerId=null;measureEditV08157.clipboard=null;state.chords=[];state.arrangements={};state.rhythmIntensityAutomation={enabled:false,curve:'soft',points:[{sec:0,value:1},{sec:d,value:1}]};state.rhythmDensityAutomation={enabled:false,curve:'soft',points:[{sec:0,value:1},{sec:d,value:1}]};state.tempoAutomation={enabled:false,curve:'soft',points:[{sec:0,bpm:76},{sec:d,bpm:76}]};state.automationGroups=[];state.masterBusAutomation={volumeAutomation:{enabled:false,curve:'soft',points:[{sec:0,value:1},{sec:d,value:1}]},filterAutomation:{enabled:false,curve:'soft',points:[{sec:0,value:1},{sec:d,value:1}]},reverbAutomation:{enabled:false,curve:'soft',points:[{sec:0,value:0},{sec:d,value:0}]}};state.automationEditor={zoom:1,snap:1};state.automationSafety={enabled:true,smoothingMs:150};state.ltcMode=normalizeLtcModeV082(null);normalizeAutomationGroupsV077();invalidateTempoMapV073();state.drums={'🥁 Hand drum HQ':new Set([0,8]),'🪵 Percussion bois HQ':new Set([4,12]),'✨ Shaker doux HQ':new Set([2,6,10,14]),'🔺 Triangle doux HQ':new Set()};state.history=[];state.future=[];state.dirty=true;els.bpm.value=76;els.key.value=0;updateDurationUiV0811();els.grid.value=.5;els.zoom.value=58;els.projectName.value=state.projectName;els.projectTag.value='Autre';renderAll();updateAutosaveStatus('Nouveau');}
function openLibrary(){renderLibrary();els.libraryModal.classList.remove('hidden');}
function closeLibrary(){els.libraryModal.classList.add('hidden');}
function renderLibrary(){if(!els.libraryList)return;const q=(els.librarySearch.value||'').trim().toLowerCase(),tag=els.libraryFilter.value;const items=library().filter(x=>(!tag||x.tag===tag)&&(!q||(x.name||'').toLowerCase().includes(q)));els.libraryList.innerHTML='';if(!items.length){els.libraryList.innerHTML='<div class="empty-library">Aucune composition ici pour le moment.<br>Crée un morceau puis touche <b>Sauvegarder</b>.</div>';return;}items.sort((a,b)=>(b.updatedAt||0)-(a.updatedAt||0)).forEach(item=>{let p={};try{p=JSON.parse(item.project||'{}');}catch{}const notes=(p.tracks||[]).reduce((n,t)=>n+(t.notes||[]).length,0);const d=document.createElement('div');d.className='composition-card'+(item.id===state.projectId?' current':'');d.innerHTML=`<h3>${esc(item.name||'Sans titre')}</h3><div class="composition-meta"><span class="tag-pill">${esc(item.tag||'Autre')}</span><span>${p.bpm||'?'} BPM</span><span>${p.bars||inferredBarsV0811(p.duration||0,p.bpm||76)} mesures</span><span>${p.duration?Math.round(p.duration)+' s':'?'}</span><span>${notes} notes</span><span>${formatDate(item.updatedAt)}</span></div><div class="composition-actions"><button class="open">Ouvrir</button><button class="dup">Dupliquer</button><button class="rename">Renommer</button>${(item.revisions||[]).length?'<button class="rev">Version -1</button>':''}<button class="del danger-ghost">Supprimer</button></div>`;d.querySelector('.open').onclick=()=>{restore(item.project);state.projectId=item.id;state.projectName=item.name;state.projectTag=item.tag||'Autre';els.projectName.value=state.projectName;els.projectTag.value=state.projectTag;localStorage.setItem(AUTO_KEY,snapshot());closeLibrary();toast('Composition ouverte');};d.querySelector('.dup').onclick=()=>duplicateLibraryItem(item.id);d.querySelector('.rename').onclick=()=>renameLibraryItem(item.id);d.querySelector('.del').onclick=()=>deleteLibraryItem(item.id);d.querySelector('.rev')?.addEventListener('click',()=>restorePreviousVersion(item.id));els.libraryList.appendChild(d);});}
function duplicateLibraryItem(id){const items=library(),src=items.find(x=>x.id===id);if(!src)return;const copy=typeof structuredClone==='function'?structuredClone(src):JSON.parse(JSON.stringify(src));copy.id=uid();copy.name=(src.name||'Composition')+' - copie';copy.createdAt=copy.updatedAt=Date.now();try{const p=JSON.parse(copy.project);p.projectId=copy.id;p.projectName=copy.name;copy.project=JSON.stringify(p);}catch{}items.unshift(copy);writeLibrary(items);renderLibrary();toast('Composition dupliquée');}
function renameLibraryItem(id){const items=library(),it=items.find(x=>x.id===id);if(!it)return;const n=prompt('Nouveau nom',it.name);if(!n)return;it.name=n;it.updatedAt=Date.now();try{const p=JSON.parse(it.project);p.projectName=n;it.project=JSON.stringify(p);}catch{}if(state.projectId===id){state.projectName=n;els.projectName.value=n;}writeLibrary(items);renderLibrary();}
function deleteLibraryItem(id){if(!confirm('Supprimer cette composition de cet appareil ?'))return;let items=library().filter(x=>x.id!==id);writeLibrary(items);if(state.projectId===id)state.projectId=null;renderLibrary();toast('Composition supprimée');}
function restorePreviousVersion(id){const items=library(),it=items.find(x=>x.id===id),rev=it?.revisions?.[0];if(!rev)return;if(!confirm('Restaurer la version précédente ? La version actuelle restera dans l’historique après la prochaine sauvegarde.'))return;restore(rev.project);state.projectId=id;state.projectName=it.name;state.projectTag=it.tag||'Autre';els.projectName.value=state.projectName;els.projectTag.value=state.projectTag;closeLibrary();markDirty();toast('Version précédente restaurée');}
async function exportProject(){let target;try{const name=safeName(state.projectName)+'.ltcmusic';target=await requestSaveTargetV08155(name,'application/octet-stream','ltcmusic','Projet LTC Music');if(target.cancelled)return;const p=JSON.parse(snapshot()),ids=customSampleIdsInProject();if(ids.length&&window.LTCCustomSamples)p.customAssets=await window.LTCCustomSamples.exportAssets(ids);await saveBlobTargetV08155(new Blob([JSON.stringify(p)],{type:'application/json'}),target,name);toast(ids.length?'Projet + sons personnels enregistré':'Projet enregistré');}catch(e){await abortNativeSaveV08155(target);alert('Export projet impossible : '+e.message);}}
function safeName(s){return String(s||'LTC_Music').trim().replace(/[^a-zA-Z0-9À-ÿ_-]+/g,'_').replace(/^_+|_+$/g,'')||'LTC_Music';}
function formatDate(ts){if(!ts)return'';return new Date(ts).toLocaleString('fr-FR',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'});}
function renderVirtualPiano(){if(!els.virtualPiano)return;els.virtualPiano.innerHTML='';const oct=+els.pianoOctave.value||4;const notes=[0,2,4,5,7,9,11,12];notes.forEach((semi,i)=>{const midi=(oct+1)*12+semi;const b=document.createElement('button');b.className='vkey';b.textContent=NOTE_NAMES[midi%12]+(Math.floor(midi/12)-1);const on=async e=>{e.preventDefault();b.classList.add('pressed');await previewMidi(midi);};const off=()=>b.classList.remove('pressed');b.addEventListener('pointerdown',on);b.addEventListener('pointerup',off);b.addEventListener('pointercancel',off);b.addEventListener('pointerleave',off);els.virtualPiano.appendChild(b);});}
async function previewMidi(midi){const ctx=ensureAudio();await ctx.resume();const t=currentTrack();if(!t)return;await preloadTrackSamples(t,ctx,null,midi,.72);renderSampleStatus(t);const g=ctx.createGain(),p=PRESETS[t.instrument]||{};g.gain.value=Math.max(.15,t.volume)*(p.mixTrim??1);let dest=g;const pan=ctx.createStereoPanner?ctx.createStereoPanner():null;if(pan){pan.pan.value=t.pan;g.connect(pan);connectSafePreviewV0813(ctx,pan);dest=g;}else connectSafePreviewV0813(ctx,g);scheduleVoice(ctx,dest,ctx.currentTime+.01,.45,midi,.72,t);}
function importProject(e){const f=e.target.files?.[0];if(!f)return;const r=new FileReader();r.onload=async()=>{try{const p=JSON.parse(r.result),assetCount=p.customAssets?.length||0;if(assetCount&&window.LTCCustomSamples){await window.LTCCustomSamples.importAssets(p.customAssets);delete p.customAssets;await syncCustomPresets();}restore(p);state.projectId=null;state.projectName=(f.name||'Projet').replace(/\.ltcmusic$/i,'');els.projectName.value=state.projectName;markDirty();toast('Projet importé'+(assetCount?' avec '+assetCount+' son(s) personnel(s)':''));}catch(err){console.error(err);alert('Projet invalide');}};r.readAsText(f);e.target.value='';}
function exportTypeV08155(mime,ext,label){return [{description:label||ext.toUpperCase()+' fichier',accept:{[mime]:['.'+ext]}}];}
function isNativeCapacitorV08155(){return !!(window.Capacitor&&typeof window.Capacitor.isNativePlatform==='function'&&window.Capacitor.isNativePlatform());}
function hasNativeSavePluginV08155(){return !!(isNativeCapacitorV08155()&&typeof window.Capacitor.nativePromise==='function'&&window.Capacitor.isPluginAvailable?.('LTCNativeSave'));}
async function requestSaveTargetV08155(name,mime,ext,label){
  if(isNativeCapacitorV08155()){
    if(!hasNativeSavePluginV08155())throw new Error('Module Android « Enregistrer sous… » non chargé. Vérifie que le build GitHub a bien compilé le plugin LTCNativeSave.');
    const result=await window.Capacitor.nativePromise('LTCNativeSave','beginSave',{name,mime});
    if(result?.cancelled)return {cancelled:true};
    return {native:true,name,mime,uri:result?.uri||''};
  }
  if(typeof window.showSaveFilePicker==='function'){
    try{const handle=await window.showSaveFilePicker({suggestedName:name,types:exportTypeV08155(mime,ext,label),excludeAcceptAllOption:false,id:'ltc-music-'+ext});return {handle,name};}
    catch(e){if(e?.name==='AbortError')return {cancelled:true};console.warn('Save picker indisponible',e);}
  }
  return {fallback:true,name};
}
function bytesToBase64V08155(bytes){let binary='';const step=0x8000;for(let i=0;i<bytes.length;i+=step)binary+=String.fromCharCode.apply(null,bytes.subarray(i,Math.min(bytes.length,i+step)));return btoa(binary);}
async function writeBlobNativeV08155(blob,onProgress){
  const chunkSize=192*1024,total=Math.max(1,blob.size);let offset=0;
  try{
    while(offset<blob.size){const end=Math.min(blob.size,offset+chunkSize),buf=await blob.slice(offset,end).arrayBuffer(),data=bytesToBase64V08155(new Uint8Array(buf));await window.Capacitor.nativePromise('LTCNativeSave','appendChunk',{data});offset=end;onProgress?.(offset/total);await new Promise(r=>setTimeout(r,0));}
    await window.Capacitor.nativePromise('LTCNativeSave','finishSave',{});onProgress?.(1);return true;
  }catch(e){try{await window.Capacitor.nativePromise('LTCNativeSave','abortSave',{});}catch{}throw e;}
}
async function saveBlobTargetV08155(blob,target,name,onProgress){
  if(target?.cancelled)return false;
  if(target?.native)return writeBlobNativeV08155(blob,onProgress);
  if(target?.handle){const w=await target.handle.createWritable();await w.write(blob);await w.close();onProgress?.(1);return true;}
  downloadBlob(blob,name);onProgress?.(1);return true;
}
async function abortNativeSaveV08155(target){if(!target?.native||!hasNativeSavePluginV08155())return;try{await window.Capacitor.nativePromise('LTCNativeSave','abortSave',{});}catch{}}
function downloadBlob(blob,name){const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);}
function toast(msg){const d=document.createElement('div');d.className='toast';d.textContent=msg;document.body.appendChild(d);setTimeout(()=>d.remove(),1800);}
function esc(s){return String(s).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));}



// ===== V0.6.6 — Arrangement : génération + transitions + boucle finale =====
let arrangementDragV061=null;
const ARR_TRANSITIONS_V062 = {
  auto:'AUTO DOUCE', legato:'LIER', bridge:'NOTE-PONT', fade:'FONDU', none:'AUCUNE'
};
function normalizeArrangementV061(a){
  if(!a)return null;
  a.blocks=Array.isArray(a.blocks)?a.blocks:[];
  a.loop=(a.loop&&typeof a.loop==='object')?a.loop:{};
  a.loop.mode=['auto','legato','bridge','fade','none'].includes(a.loop.mode)?a.loop.mode:'auto';
  a.loop.crossfade=[0,.5,1,2].includes(+a.loop.crossfade)?+a.loop.crossfade:1;
  a.loop.optimized=!!a.loop.optimized;
  const known=new Set(a.blocks.map(b=>b.id));
  a.sequence=(Array.isArray(a.sequence)?a.sequence:[]).map(x=>{
    if(typeof x==='string')return {id:uid(),blockId:x,bars:null,transition:'auto'};
    if(!x||typeof x!=='object')return null;
    const blockId=x.blockId || (known.has(x.id)?x.id:null);
    if(!blockId)return null;
    const transition=ARR_TRANSITIONS_V062[x.transition]?x.transition:'auto';
    return {id:(x.blockId?x.id:null)||uid(),blockId,bars:[2,4,8].includes(+x.bars)?+x.bars:null,transition};
  }).filter(x=>known.has(x.blockId));
  return a;
}
function currentArrangementV061(create=true){
  const t=currentTrack();if(!t)return null;state.arrangements=state.arrangements||{};
  if(!state.arrangements[t.id]&&create)state.arrangements[t.id]={blocks:[],sequence:[],loop:{mode:'auto',crossfade:1,optimized:false}};
  return normalizeArrangementV061(state.arrangements[t.id]);
}
function initArrangementV061(){
  $('#arrCaptureBtn')?.addEventListener('click',captureArrangementBlockV061);
  $('#arrPreviewBtn')?.addEventListener('click',previewArrangementV061);
  $('#arrApplyBtn')?.addEventListener('click',applyArrangementV061);
  $('#arrClearSeqBtn')?.addEventListener('click',()=>{const a=currentArrangementV061(false);if(!a||!a.sequence.length)return;mutate(()=>{a.sequence=[];});renderArrangementV061();toast('Suite d’arrangement effacée');});
  $('#arrAutoTransitionsBtn')?.addEventListener('click',()=>{const a=currentArrangementV061(false);if(!a||a.sequence.length<2)return;mutate(()=>a.sequence.forEach((x,i)=>{if(i<a.sequence.length-1)x.transition='auto';}));renderArrangementV061();toast('Transitions AUTO appliquées');});
  $('#arrGenerateBtn')?.addEventListener('click',generateAutomaticArrangementV063);
  $('#arrAutoDuration')?.addEventListener('change',updateAutoArrangementEstimateV063);
  $('#arrAutoMood')?.addEventListener('change',updateAutoArrangementEstimateV063);
  $('#arrLoopAnalyzeBtn')?.addEventListener('click',()=>analyzeAndRenderArrangementLoopV066(true));
  $('#arrLoopPreviewBtn')?.addEventListener('click',previewArrangementLoopJoinV066);
  $('#arrLoopOptimizeBtn')?.addEventListener('click',optimizeArrangementLoopV066);
  $('#arrLoopPlaceEndsBtn')?.addEventListener('click',placeIntroOutroV066);
  $('#arrLoopMode')?.addEventListener('change',e=>updateLoopSettingV066('mode',e.target.value));
  $('#arrLoopCrossfade')?.addEventListener('change',e=>updateLoopSettingV066('crossfade',+e.target.value));
  renderArrangementV061();updateAutoArrangementEstimateV063();
}
function autoTargetBarsV063(seconds){
  const raw=(Math.max(10,+seconds||90)*state.bpm/60)/4;
  return Math.max(2,Math.round(raw/2)*2);
}
function autoDurationTextV063(bars){
  const sec=bars*4*60/state.bpm;
  return `${bars} mesures • ${sec.toFixed(sec<60?1:0)} s`;
}
function updateAutoArrangementEstimateV063(){
  const el=$('#arrAutoActual');if(!el)return;
  const seconds=+($('#arrAutoDuration')?.value||90),bars=autoTargetBarsV063(seconds);
  el.textContent=autoDurationTextV063(bars);
}
function autoBlockRoleV063(block){
  const raw=String(block?.label||'').trim().toUpperCase();
  if(raw==='INTRO')return 'intro';if(raw==='OUTRO')return 'outro';
  if(raw==='A')return 'a';if(/^A[′']+/.test(raw))return 'av';if(raw==='B')return 'b';if(raw==='C')return 'c';return 'other';
}
function autoPickBlockV063(a,mood,step,lastId){
  const main=(a.blocks||[]).filter(b=>!['intro','outro'].includes(autoBlockRoleV063(b)));
  if(!main.length)return null;
  const role=r=>main.filter(b=>autoBlockRoleV063(b)===r);
  const A=role('a'),AV=role('av'),B=role('b'),C=role('c'),O=role('other');
  let pools=[];
  if(mood==='calm') pools=(step%3===0?[A,AV,B,C,O]:[A,AV,B,C,O]);
  else if(mood==='varied') pools=[step%4===0?A:[],step%4===1?B:[],step%4===2?C:[],AV,O,A,B,C];
  else pools=[step%4===0?A:[],step%4===1?AV:[],step%4===2?B:[],step%4===3?A:[],C,O,A,AV,B];
  let candidates=[];for(const p of pools){if(p?.length){candidates=p;break;}}
  if(!candidates.length)candidates=main;
  const nonRepeat=candidates.filter(b=>b.id!==lastId);if(nonRepeat.length)candidates=nonRepeat;
  if(mood==='varied'&&candidates.length>1)return candidates[Math.floor(Math.random()*candidates.length)];
  return candidates[step%candidates.length];
}
function autoOccurrenceBarsV063(block,mood,remaining,step){
  const source=[2,4,8].includes(+block?.bars)?+block.bars:4;
  let preferred=source;
  if(mood==='calm')preferred=remaining>=8&&step%3===1?8:Math.max(4,source);
  else if(mood==='varied')preferred=[2,4,4,8][step%4];
  else preferred=source;
  const options=[preferred,4,2,8].filter((x,i,a)=>[2,4,8].includes(x)&&a.indexOf(x)===i&&x<=remaining);
  return options[0]||2;
}
function generateAutomaticArrangementV063(){
  const a=currentArrangementV061(false),t=currentTrack();if(!t||!a)return toast('Choisis une piste');
  if(!(a.blocks||[]).length)return toast('Capture d’abord au moins un bloc A, B ou C');
  const seconds=+($('#arrAutoDuration')?.value||90),mood=$('#arrAutoMood')?.value||'balanced',targetBars=autoTargetBarsV063(seconds);
  const intro=(a.blocks||[]).find(b=>autoBlockRoleV063(b)==='intro'),outro=(a.blocks||[]).find(b=>autoBlockRoleV063(b)==='outro');
  const main=(a.blocks||[]).filter(b=>!['intro','outro'].includes(autoBlockRoleV063(b)));
  if(!main.length&&!intro&&!outro)return toast('Aucun bloc utilisable');
  const next=[];let used=0;
  const push=(b,bars)=>{if(!b||bars<2)return;next.push({id:uid(),blockId:b.id,bars,transition:'auto'});used+=bars;};
  let outroBars=outro?Math.min(occurrenceBarsV061(null,outro),Math.max(2,targetBars-2)):0;
  let introBars=intro?Math.min(occurrenceBarsV061(null,intro),Math.max(2,targetBars-outroBars-2)):0;
  if(intro&&introBars>=2)push(intro,introBars);
  let step=0,lastId=intro?.id||null,available=Math.max(0,targetBars-used-outroBars);
  while(available>=2){
    const b=autoPickBlockV063(a,mood,step,lastId)||main[0]||intro||outro;if(!b)break;
    let bars=autoOccurrenceBarsV063(b,mood,available,step);if(bars>available)bars=available>=4?4:2;
    push(b,bars);available=targetBars-used-outroBars;lastId=b.id;step++;if(step>128)break;
  }
  if(outro&&outroBars>=2){const room=targetBars-used;if(room>=2)push(outro,Math.min(outroBars,room));}
  // If rounding or INTRO/OUTRO constraints left a small even gap, extend the final occurrence safely.
  let gap=targetBars-used;
  while(gap>=2&&next.length){const last=next[next.length-1];const candidate=[8,4,2].find(x=>x>last.bars&&x-last.bars<=gap);if(candidate){gap-=candidate-last.bars;last.bars=candidate;}else{const b=autoPickBlockV063(a,mood,step++,last.blockId)||main[0];if(!b)break;const bars=gap>=4?4:2;next.push({id:uid(),blockId:b.id,bars,transition:'auto'});gap-=bars;}}
  if(!next.length)return toast('Impossible de construire une suite avec ces blocs');
  mutate(()=>{a.sequence=next;});renderArrangementV061();
  const actual=a.sequence.reduce((s,o)=>s+occurrenceBarsV061(o,blockByIdV061(a,o.blockId)),0),actualSec=actual*4*60/state.bpm;
  toast(`Suite auto • ${actual} mesures • ${actualSec.toFixed(0)} s`);
}

function arrangementSourceWindowV061(bars){
  const t=currentTrack(),span=bars*4;if(!t||!t.notes.length)return {start:0,span,notes:[]};
  const sel=currentNote();let start=0;
  if(sel)start=Math.max(0,Math.floor(sel.beat/span)*span);
  else {const end=Math.max(...t.notes.map(n=>n.beat+n.dur));start=Math.max(0,Math.floor(Math.max(0,end-span)/4)*4);}
  let notes=t.notes.filter(n=>n.beat<start+span&&n.beat+n.dur>start).map(n=>({midi:n.midi,velocity:n.velocity,beat:Math.max(0,n.beat-start),dur:Math.min(n.beat+n.dur,start+span)-Math.max(n.beat,start)})).filter(n=>n.dur>.04&&n.beat<span);
  return {start,span,notes:notes.sort((a,b)=>a.beat-b.beat)};
}
function captureArrangementBlockV061(){
  const t=currentTrack();if(!t)return toast('Choisis une piste');const bars=+($('#arrBars')?.value||4),label=$('#arrBlockType')?.value||'A',src=arrangementSourceWindowV061(bars);
  if(!src.notes.length)return toast('Aucune note à capturer dans ces mesures');const a=currentArrangementV061();
  const existing=a.blocks.find(b=>b.label===label);const block={id:existing?.id||uid(),label,bars,lengthBeats:bars*4,notes:src.notes,sourceStart:src.start,instrument:t.instrument,createdAt:Date.now()};
  if(existing&&!confirm(`Remplacer le bloc ${label} déjà enregistré pour cette piste ?`))return;
  mutate(()=>{const i=a.blocks.findIndex(b=>b.id===block.id);if(i>=0)a.blocks[i]=block;else a.blocks.push(block);});renderArrangementV061();toast(`${label} capturé • ${src.notes.length} notes`);
}
function blockByIdV061(a,id){return a?.blocks?.find(b=>b.id===id)||null;}
function occurrenceBarsV061(occ,b){return [2,4,8].includes(+occ?.bars)?+occ.bars:(b?.bars||Math.max(1,Math.round((b?.lengthBeats||16)/4)));}
function compileOccurrenceNotesV062(b,occ,startBeat){
  const targetBeats=occurrenceBarsV061(occ,b)*4,sourceBeats=Math.max(1,b.lengthBeats||((b.bars||4)*4)),notes=[];
  for(let rep=0;rep<targetBeats;rep+=sourceBeats){
    for(const n of b.notes||[]){const beat=rep+n.beat;if(beat>=targetBeats)continue;notes.push({...n,id:uid(),beat:startBeat+beat,dur:Math.min(n.dur,Math.max(.05,targetBeats-beat)),arrRole:'source'});}
  }
  return {notes:notes.sort((a,b)=>a.beat-b.beat),start:startBeat,end:startBeat+targetBeats,targetBeats};
}
function transitionResolvedTypeV062(type,prevTail,nextHead){
  if(type!=='auto')return type;
  if(!prevTail||!nextHead)return 'none';
  const interval=Math.abs(prevTail.midi-nextHead.midi);
  const prevEnd=prevTail.beat+prevTail.dur, gap=Math.max(0,nextHead.beat-prevEnd);
  if(interval<=2 && gap<.75)return 'legato';
  if(interval<=7)return 'bridge';
  return 'fade';
}
function applyBoundaryTransitionV062(prevSeg,nextSeg,type,out,meta){
  const prev=(prevSeg?.notes||[]).filter(n=>n.beat<prevSeg.end+.001).sort((a,b)=>(a.beat+a.dur)-(b.beat+b.dur));
  const next=(nextSeg?.notes||[]).sort((a,b)=>a.beat-b.beat);
  const prevTail=prev[prev.length-1], nextHead=next[0];
  const resolved=transitionResolvedTypeV062(type,prevTail,nextHead),boundary=prevSeg?.end??0;
  if(!prevTail||!nextHead||resolved==='none'){meta.push({beat:boundary,type:'none',requested:type});return;}
  if(resolved==='legato'){
    const desired=Math.max(prevTail.dur,boundary-prevTail.beat+.18);
    prevTail.dur=Math.min(desired,boundary-prevTail.beat+.35);
    nextHead.velocity=clamp((nextHead.velocity??.75)*.96,.05,1);
  } else if(resolved==='bridge'){
    // Anticipate the first stable note of the next block instead of inventing a risky new pitch.
    const bridgeBeat=Math.max(prevSeg.start,boundary-.38);
    const vel=clamp(Math.min(prevTail.velocity??.7,nextHead.velocity??.7)*.68,.18,.72);
    out.push({id:uid(),midi:nextHead.midi,velocity:vel,beat:bridgeBeat,dur:.46,arrRole:'transition-bridge'});
    prevTail.velocity=clamp((prevTail.velocity??.75)*.90,.05,1);
  } else if(resolved==='fade'){
    const tails=prev.filter(n=>n.beat>=boundary-2.5).slice(-3);
    tails.forEach((n,i)=>n.velocity=clamp((n.velocity??.75)*(.86-i*.07),.05,1));
    const heads=next.filter(n=>n.beat<=boundary+2.5).slice(0,3);
    heads.forEach((n,i)=>n.velocity=clamp((n.velocity??.75)*(.78+i*.08),.05,1));
    prevTail.dur=Math.min(Math.max(prevTail.dur,boundary-prevTail.beat+.08),boundary-prevTail.beat+.18);
  }
  meta.push({beat:boundary,type:resolved,requested:type,from:prevTail.midi,to:nextHead.midi});
}
function arrangementCompiledV061(opts={}){
  const a=currentArrangementV061(false);if(!a)return {notes:[],endBeat:0,transitions:[],loopMeta:null};let off=0,out=[],segments=[];
  for(const occ of a.sequence){const b=blockByIdV061(a,occ.blockId);if(!b)continue;const seg=compileOccurrenceNotesV062(b,occ,off);segments.push({...seg,occ,block:b});out.push(...seg.notes);off=seg.end;}
  const transitions=[];
  for(let i=0;i<segments.length-1;i++)applyBoundaryTransitionV062(segments[i],segments[i+1],segments[i].occ.transition||'auto',out,transitions);
  out.sort((x,y)=>x.beat-y.beat||x.midi-y.midi);
  let loopMeta=null;if(opts.loop!==false&&a.loop?.optimized&&out.length)loopMeta=applyLoopTreatmentV066(out,off,a.loop);
  out.sort((x,y)=>x.beat-y.beat||x.midi-y.midi);
  return {notes:out,endBeat:off,transitions,loopMeta};
}
function addArrangementBlockToSequenceV061(blockId){const a=currentArrangementV061();const b=blockByIdV061(a,blockId);if(!b)return;mutate(()=>a.sequence.push({id:uid(),blockId,bars:null,transition:'auto'}));renderArrangementV061();}
function duplicateArrangementBlockV061(blockId){const a=currentArrangementV061(false),b=blockByIdV061(a,blockId);if(!a||!b)return;const labels=new Set(a.blocks.map(x=>x.label));let base=b.label, label=base.endsWith('′')?base+'′':base+'′';while(labels.has(label))label+='′';const copy={...b,id:uid(),label,notes:(b.notes||[]).map(n=>({...n})),createdAt:Date.now()};mutate(()=>a.blocks.push(copy));renderArrangementV061();toast(`${b.label} dupliqué en ${label}`);}
function duplicateArrangementOccurrenceV061(index){const a=currentArrangementV061(false),occ=a?.sequence?.[index];if(!occ)return;mutate(()=>a.sequence.splice(index+1,0,{...occ,id:uid()}));renderArrangementV061();}
function removeArrangementSequenceItemV061(index){const a=currentArrangementV061(false);if(!a)return;mutate(()=>a.sequence.splice(index,1));renderArrangementV061();}
function moveArrangementOccurrenceV061(index,delta){const a=currentArrangementV061(false);if(!a)return;const j=index+delta;if(j<0||j>=a.sequence.length)return;mutate(()=>{const [x]=a.sequence.splice(index,1);a.sequence.splice(j,0,x);});renderArrangementV061();}
function setArrangementOccurrenceBarsV061(index,bars){const a=currentArrangementV061(false),occ=a?.sequence?.[index];if(!occ)return;bars=+bars;if(![2,4,8].includes(bars))return;mutate(()=>{occ.bars=bars;});renderArrangementV061();}
function setArrangementTransitionV062(index,type){const a=currentArrangementV061(false),occ=a?.sequence?.[index];if(!occ||!ARR_TRANSITIONS_V062[type])return;mutate(()=>occ.transition=type);renderArrangementV061();}
function deleteArrangementBlockV061(id){const a=currentArrangementV061(false),b=blockByIdV061(a,id);if(!a||!b)return;if(!confirm(`Supprimer le bloc ${b.label} ? Il sera aussi retiré de la suite.`))return;mutate(()=>{a.blocks=a.blocks.filter(x=>x.id!==id);a.sequence=a.sequence.filter(x=>x.blockId!==id);});renderArrangementV061();}
function sequenceOrderFromDomV061(seqEl,a){return [...seqEl.querySelectorAll('.arr-seq-item')].map(el=>a.sequence.find(x=>x.id===el.dataset.occId)).filter(Boolean);}
function beginArrangementDragV061(e,index){
  if(e.button!==undefined&&e.button!==0)return;const a=currentArrangementV061(false),seq=$('#arrSequenceTimeline');if(!a||!seq||a.sequence.length<2)return;
  const item=e.currentTarget.closest('.arr-seq-item');if(!item)return;e.preventDefault();
  arrangementDragV061={pointerId:e.pointerId,item,seq,a,before:snapshot(),startIndex:index,changed:false};item.classList.add('dragging');document.body.classList.add('arr-dragging');
  try{e.currentTarget.setPointerCapture(e.pointerId);}catch{}
  const move=ev=>{if(!arrangementDragV061||ev.pointerId!==arrangementDragV061.pointerId)return;ev.preventDefault();const target=document.elementFromPoint(ev.clientX,ev.clientY)?.closest('.arr-seq-item');if(!target||target===item||target.parentElement!==seq)return;const r=target.getBoundingClientRect();if(ev.clientX<r.left+r.width/2)seq.insertBefore(item,target);else seq.insertBefore(item,target.nextSibling);arrangementDragV061.changed=true;};
  const up=ev=>{if(!arrangementDragV061||ev.pointerId!==arrangementDragV061.pointerId)return;window.removeEventListener('pointermove',move,true);window.removeEventListener('pointerup',up,true);window.removeEventListener('pointercancel',up,true);item.classList.remove('dragging');document.body.classList.remove('arr-dragging');if(arrangementDragV061.changed){const order=sequenceOrderFromDomV061(seq,a);state.history.push(arrangementDragV061.before);if(state.history.length>60)state.history.shift();state.future=[];a.sequence=order;markDirty();toast('Blocs réorganisés');}arrangementDragV061=null;renderArrangementV061();};
  window.addEventListener('pointermove',move,true);window.addEventListener('pointerup',up,true);window.addEventListener('pointercancel',up,true);
}
function renderArrangementV061(){
  const lib=$('#arrBlockLibrary'),seq=$('#arrSequenceTimeline'),sum=$('#arrSequenceSummary'),count=$('#arrBlockCount'),trackLabel=$('#arrTrackLabel');if(!lib||!seq)return;const t=currentTrack();
  if(trackLabel)trackLabel.textContent=t?`${t.name} • ${t.instrument.replace(/^\S+\s/,'')}`:'Aucune piste';const a=currentArrangementV061(!!t);const blocks=a?.blocks||[],sequence=a?.sequence||[];
  if(count)count.textContent=`${blocks.length} bloc${blocks.length>1?'s':''}`;lib.innerHTML='';
  if(!blocks.length)lib.innerHTML='<div class="arr-empty">Aucun bloc. Choisis A / B / C puis capture 2, 4 ou 8 mesures depuis la piste.</div>';
  else blocks.forEach(b=>{const d=document.createElement('div');d.className='arr-block-card';d.innerHTML=`<div class="arr-block-top"><span class="arr-block-badge">${esc(b.label)}</span><span>${b.bars||Math.round((b.lengthBeats||16)/4)} mesures</span></div><div class="arr-block-meta">${(b.notes||[]).length} notes • source mesure ${Math.floor((b.sourceStart||0)/4)+1}</div><div class="arr-block-actions"><button class="add accent-soft">＋ Ajouter</button><button class="duplicate" title="Dupliquer le bloc">⧉</button><button class="remove danger-ghost" title="Supprimer">✕</button></div>`;d.querySelector('.add').onclick=()=>addArrangementBlockToSequenceV061(b.id);d.querySelector('.duplicate').onclick=()=>duplicateArrangementBlockV061(b.id);d.querySelector('.remove').onclick=()=>deleteArrangementBlockV061(b.id);lib.appendChild(d);});
  seq.innerHTML='';let total=0;if(!sequence.length)seq.innerHTML='<div class="arr-empty" style="min-width:100%">La suite est vide. Ajoute par exemple A → A′ → B → A.</div>';
  else sequence.forEach((occ,i)=>{const b=blockByIdV061(a,occ.blockId);if(!b)return;const bars=occurrenceBarsV061(occ,b),hasNext=i<sequence.length-1,type=ARR_TRANSITIONS_V062[occ.transition]?occ.transition:'auto';const item=document.createElement('div');item.className='arr-seq-item';item.dataset.index=i;item.dataset.occId=occ.id;item.style.width=Math.max(148,Math.min(250,bars*36))+'px';item.innerHTML=`<div class="arr-seq-top"><button class="arr-drag-handle" title="Glisser pour déplacer" aria-label="Glisser pour déplacer">☰</button><b>${esc(b.label)}</b><button class="arr-seq-remove" title="Retirer">✕</button></div><label class="arr-length-label">Longueur<select class="arr-length"><option value="2" ${bars===2?'selected':''}>2 mesures</option><option value="4" ${bars===4?'selected':''}>4 mesures</option><option value="8" ${bars===8?'selected':''}>8 mesures</option></select></label>${hasNext?`<label class="arr-transition-label">Vers le suivant<select class="arr-transition"><option value="auto" ${type==='auto'?'selected':''}>AUTO DOUCE</option><option value="legato" ${type==='legato'?'selected':''}>LIER</option><option value="bridge" ${type==='bridge'?'selected':''}>NOTE-PONT</option><option value="fade" ${type==='fade'?'selected':''}>FONDU</option><option value="none" ${type==='none'?'selected':''}>AUCUNE</option></select></label>`:'<div class="arr-transition-end">FIN</div>'}<div class="arr-seq-tools"><button class="left" ${i===0?'disabled':''} title="Déplacer à gauche">←</button><button class="dup" title="Dupliquer cette occurrence">⧉</button><button class="right" ${i===sequence.length-1?'disabled':''} title="Déplacer à droite">→</button></div>`;
    item.querySelector('.arr-seq-remove').onclick=()=>removeArrangementSequenceItemV061(i);item.querySelector('.left').onclick=()=>moveArrangementOccurrenceV061(i,-1);item.querySelector('.right').onclick=()=>moveArrangementOccurrenceV061(i,1);item.querySelector('.dup').onclick=()=>duplicateArrangementOccurrenceV061(i);item.querySelector('.arr-length').onchange=e=>setArrangementOccurrenceBarsV061(i,e.target.value);item.querySelector('.arr-transition')&&(item.querySelector('.arr-transition').onchange=e=>setArrangementTransitionV062(i,e.target.value));item.querySelector('.arr-drag-handle').onpointerdown=e=>beginArrangementDragV061(e,i);seq.appendChild(item);total+=bars;});
  const sec=total*4*60/state.bpm,transitionCount=Math.max(0,sequence.length-1);updateAutoArrangementEstimateV063();if(sum)sum.textContent=`${total} mesure${total>1?'s':''} • ${sequence.length} bloc${sequence.length>1?'s':''} • ${transitionCount} transition${transitionCount>1?'s':''} • ${sec.toFixed(sec<60?1:0)} s`;const has=sequence.length>0;$('#arrPreviewBtn')&&( $('#arrPreviewBtn').disabled=!has );$('#arrApplyBtn')&&( $('#arrApplyBtn').disabled=!has );$('#arrClearSeqBtn')&&( $('#arrClearSeqBtn').disabled=!has );$('#arrAutoTransitionsBtn')&&( $('#arrAutoTransitionsBtn').disabled=transitionCount<1 );
  const loop=a?.loop||{mode:'auto',crossfade:1,optimized:false};if($('#arrLoopMode'))$('#arrLoopMode').value=loop.mode||'auto';if($('#arrLoopCrossfade'))$('#arrLoopCrossfade').value=String(loop.crossfade??1);['#arrLoopAnalyzeBtn','#arrLoopPreviewBtn','#arrLoopOptimizeBtn'].forEach(sel=>{$(sel)&&($(sel).disabled=!has);});const intro=blocks.find(b=>autoBlockRoleV063(b)==='intro'),outro=blocks.find(b=>autoBlockRoleV063(b)==='outro');if($('#arrLoopPlaceEndsBtn'))$('#arrLoopPlaceEndsBtn').disabled=!has||(!intro&&!outro);
  if(has)analyzeAndRenderArrangementLoopV066(false);else resetLoopAnalysisV066();
}
function stopArrangementPreviewV061(){if(arrangementPreviewTimer){clearTimeout(arrangementPreviewTimer);arrangementPreviewTimer=null;}if(!state.playing){state.nodes.forEach(n=>{try{n.stop()}catch{}});state.nodes=[];}}
async function previewArrangementV061(){
  const t=currentTrack(),c=arrangementCompiledV061();if(!t||!c.notes.length)return toast('Ajoute des blocs à la suite');stop();stopArrangementPreviewV061();const ctx=ensureAudio();await ctx.resume();const pack=multisamplePackForTrack(t);if(pack&&window.LTCSampleEngine?.preloadUsage)await window.LTCSampleEngine.preloadUsage(pack,ctx,c.notes.map(n=>({midi:n.midi,velocity:n.velocity})));
  const g=ctx.createGain(),p=PRESETS[t.instrument]||{};g.gain.value=t.volume*(p.mixTrim??1);let dest=g;const pan=ctx.createStereoPanner?ctx.createStereoPanner():null;if(pan){pan.pan.value=t.pan;g.connect(pan);connectSafePreviewV0813(ctx,pan);}else connectSafePreviewV0813(ctx,g);const now=ctx.currentTime+.05,spb=60/state.bpm;c.notes.forEach(n=>scheduleVoice(ctx,dest,now+n.beat*spb,n.dur*spb,n.midi,n.velocity,t));const sec=c.endBeat*spb+.5;arrangementPreviewTimer=setTimeout(()=>stopArrangementPreviewV061(),sec*1000);const used=c.transitions.filter(x=>x.type!=='none');toast(`Pré-écoute • ${used.length} transition${used.length>1?'s':''} active${used.length>1?'s':''}`);
}
function applyArrangementV061(){
  const t=currentTrack(),c=arrangementCompiledV061();if(!t||!c.notes.length)return;const measures=Math.round(c.endBeat/4),seconds=c.endBeat*60/state.bpm,bridges=c.notes.filter(n=>n.arrRole==='transition-bridge').length;
  if(!confirm(`Appliquer ${measures} mesures sur le début de « ${t.name} » ?${bridges?` ${bridges} note(s)-pont seront ajoutées.`:''} Les notes placées après cette zone seront conservées.`))return;
  mutate(()=>{const keep=t.notes.filter(n=>n.beat>=c.endBeat);t.notes=[...c.notes.map(n=>({...n,id:uid(),arrRole:undefined})),...keep].sort((a,b)=>a.beat-b.beat);if(c.endBeat>totalBeats()){state.bars=Math.max(state.bars,Math.ceil(c.endBeat/4));state.duration=barsToSecondsV0811(state.bars);}});normalizeDurationDependentsV0811();updateDurationUiV0811();renderAll();switchMode('notes');toast('Arrangement + transitions appliqués');
}


// ===== V0.6.6 — Boucle finale / INTRO-OUTRO =====
let arrangementLoopPreviewTimerV066=null;
function updateLoopSettingV066(key,value){const a=currentArrangementV061(false);if(!a)return;mutate(()=>{a.loop=a.loop||{};a.loop[key]=value;a.loop.optimized=false;});renderArrangementV061();}
function resetLoopAnalysisV066(){const s=$('#arrLoopScore'),d=$('#arrLoopDetails');if(s){s.textContent='Non analysée';s.className='';}if(d){d.className='arr-loop-details';d.textContent='Ajoute des blocs à la suite pour analyser le raccord fin → début.';}}
function loopCoreAnalysisV066(c){
  const notes=(c?.notes||[]).filter(n=>n.arrRole!=='transition-bridge');if(!notes.length||!c.endBeat)return null;
  const firstBeat=Math.min(...notes.map(n=>n.beat)),firstCandidates=notes.filter(n=>n.beat<=firstBeat+1.25).sort((a,b)=>a.beat-b.beat||b.velocity-a.velocity),head=firstCandidates[0];
  const tail=[...notes].sort((a,b)=>(b.beat+b.dur)-(a.beat+a.dur))[0],lastEnd=tail.beat+tail.dur;
  const startGap=Math.max(0,firstBeat),endGap=Math.max(0,c.endBeat-lastEnd),interval=Math.abs((tail?.midi??60)-(head?.midi??60)),pcInterval=Math.min(interval%12,12-(interval%12)),velDiff=Math.abs((tail?.velocity??.7)-(head?.velocity??.7));
  let score=100;score-=Math.min(36,pcInterval*5);score-=Math.min(24,Math.abs(endGap-startGap)*18);score-=Math.min(16,velDiff*28);if(endGap>1.5)score-=12;if(startGap>1.5)score-=8;score=Math.round(clamp(score,0,100));
  const cls=score>=82?'good':score>=62?'warn':'bad',label=score>=88?'Excellent':score>=75?'Bon':score>=60?'Correct':'Raccord visible';
  return {score,cls,label,head,tail,startGap,endGap,interval,pcInterval,velDiff};
}
function resolvedLoopModeV066(mode,analysis){if(mode&&mode!=='auto')return mode;if(!analysis)return'none';if(analysis.pcInterval<=2&&analysis.endGap<1)return'legato';if(analysis.pcInterval<=7)return'bridge';return'fade';}
function analyzeAndRenderArrangementLoopV066(showToast=false){
  const a=currentArrangementV061(false),c=arrangementCompiledV061({loop:!!a?.loop?.optimized}),r=loopCoreAnalysisV066(c),score=$('#arrLoopScore'),details=$('#arrLoopDetails');if(!a||!r){resetLoopAnalysisV066();return null;}
  const mode=resolvedLoopModeV066(a.loop?.mode||'auto',r),names={legato:'LIER',bridge:'NOTE-PONT',fade:'FONDU',none:'AUCUNE'};
  if(score){score.textContent=`${r.label} • ${r.score}/100`;score.className=r.cls;}
  if(details){details.className='arr-loop-details '+r.cls;details.innerHTML=`Fin → début : <b>${NOTE_NAMES[r.tail.midi%12]}${Math.floor(r.tail.midi/12)-1} → ${NOTE_NAMES[r.head.midi%12]}${Math.floor(r.head.midi/12)-1}</b> • écart ${r.pcInterval} demi-ton${r.pcInterval>1?'s':''} • silence fin ${r.endGap.toFixed(2)} beat • stratégie conseillée : <b>${names[mode]||mode}</b>${a.loop?.optimized?' • ✓ optimisation active':''}.`; }
  if(showToast)toast(`Raccord ${r.label.toLowerCase()} • ${r.score}/100`);return r;
}
function applyLoopTreatmentV066(notes,endBeat,loop){
  const analysis=loopCoreAnalysisV066({notes,endBeat});if(!analysis)return null;const mode=resolvedLoopModeV066(loop?.mode||'auto',analysis),crossSec=Math.max(0,+loop?.crossfade||0),crossBeats=crossSec*state.bpm/60;
  const tailWindow=Math.max(.75,crossBeats||1),headWindow=Math.max(.75,crossBeats||1);
  const tails=notes.filter(n=>n.beat+n.dur>=endBeat-tailWindow),heads=notes.filter(n=>n.beat<=headWindow);
  if(crossBeats>0){tails.forEach(n=>{const pos=clamp((n.beat-(endBeat-tailWindow))/tailWindow,0,1);n.velocity=clamp((n.velocity??.7)*(1-.32*pos),.05,1);});heads.forEach(n=>{const pos=clamp(n.beat/headWindow,0,1);n.velocity=clamp((n.velocity??.7)*(.70+.30*pos),.05,1);});}
  const tail=[...notes].sort((a,b)=>(b.beat+b.dur)-(a.beat+a.dur))[0],head=[...notes].sort((a,b)=>a.beat-b.beat)[0];
  if(mode==='legato'&&tail&&head){if((tail.midi%12)===(head.midi%12)){tail.dur=Math.max(tail.dur,endBeat-tail.beat+.08);}else{notes.push({id:uid(),midi:head.midi,velocity:clamp(Math.min(tail.velocity??.7,head.velocity??.7)*.55,.15,.62),beat:Math.max(0,endBeat-.32),dur:.38,arrRole:'loop-bridge'});}}
  else if(mode==='bridge'&&head){notes.push({id:uid(),midi:head.midi,velocity:clamp((head.velocity??.7)*.48,.14,.58),beat:Math.max(0,endBeat-.42),dur:.46,arrRole:'loop-bridge'});}
  else if(mode==='fade'){tails.forEach(n=>n.velocity=clamp((n.velocity??.7)*.82,.05,1));heads.forEach(n=>n.velocity=clamp((n.velocity??.7)*.84,.05,1));}
  return {mode,crossfade:crossSec,analysis};
}
function optimizeArrangementLoopV066(){const a=currentArrangementV061(false);if(!a||!a.sequence.length)return toast('Ajoute des blocs à la suite');const r=analyzeAndRenderArrangementLoopV066(false);if(!r)return;mutate(()=>{a.loop=a.loop||{};a.loop.mode=$('#arrLoopMode')?.value||'auto';a.loop.crossfade=+($('#arrLoopCrossfade')?.value||1);a.loop.optimized=true;});renderArrangementV061();const rr=analyzeAndRenderArrangementLoopV066(false);toast(`Boucle préparée • ${rr?.score??r.score}/100`);}
function placeIntroOutroV066(){const a=currentArrangementV061(false);if(!a)return;const intro=a.blocks.find(b=>autoBlockRoleV063(b)==='intro'),outro=a.blocks.find(b=>autoBlockRoleV063(b)==='outro');if(!intro&&!outro)return toast('Aucun bloc INTRO / OUTRO enregistré');mutate(()=>{let seq=a.sequence.filter(o=>{const b=blockByIdV061(a,o.blockId),role=autoBlockRoleV063(b);return role!=='intro'&&role!=='outro';});if(intro)seq.unshift({id:uid(),blockId:intro.id,bars:null,transition:'auto'});if(outro)seq.push({id:uid(),blockId:outro.id,bars:null,transition:'auto'});a.sequence=seq;a.loop.optimized=false;});renderArrangementV061();toast('INTRO / OUTRO replacés');}
function stopArrangementLoopPreviewV066(){if(arrangementLoopPreviewTimerV066){clearTimeout(arrangementLoopPreviewTimerV066);arrangementLoopPreviewTimerV066=null;}if(!state.playing){state.nodes.forEach(n=>{try{n.stop()}catch{}});state.nodes=[];}}
async function previewArrangementLoopJoinV066(){
  const t=currentTrack(),a=currentArrangementV061(false),c=arrangementCompiledV061();if(!t||!a||!c.notes.length)return toast('Ajoute des blocs à la suite');stop();stopArrangementLoopPreviewV066();const ctx=ensureAudio();await ctx.resume();const previewSec=5,crossSec=Math.min(+($('#arrLoopCrossfade')?.value||0),2),spb=60/state.bpm,tailStartBeat=Math.max(0,c.endBeat-previewSec/spb);
  const usage=c.notes.filter(n=>n.beat+n.dur>=tailStartBeat||n.beat<=previewSec/spb).map(n=>({midi:n.midi,velocity:n.velocity})),pack=multisamplePackForTrack(t);if(pack&&window.LTCSampleEngine?.preloadUsage)await window.LTCSampleEngine.preloadUsage(pack,ctx,usage);
  const master=ctx.createGain();master.gain.value=t.volume*((PRESETS[t.instrument]||{}).mixTrim??1);const pan=ctx.createStereoPanner?ctx.createStereoPanner():null;if(pan){pan.pan.value=t.pan;master.connect(pan);connectSafePreviewV0813(ctx,pan);}else connectSafePreviewV0813(ctx,master);
  const tailG=ctx.createGain(),headG=ctx.createGain();tailG.connect(master);headG.connect(master);const now=ctx.currentTime+.06,joinAt=previewSec,headAt=joinAt-crossSec;tailG.gain.setValueAtTime(1,now);headG.gain.setValueAtTime(crossSec>0?.0001:1,now+headAt);if(crossSec>0){tailG.gain.setValueAtTime(1,now+joinAt-crossSec);tailG.gain.linearRampToValueAtTime(.0001,now+joinAt);headG.gain.linearRampToValueAtTime(1,now+joinAt);}
  c.notes.filter(n=>n.beat+n.dur>=tailStartBeat).forEach(n=>{const local=Math.max(0,n.beat-tailStartBeat),cut=Math.max(0,tailStartBeat-n.beat),dur=Math.max(.05,n.dur-cut);if(local<=previewSec+.2)scheduleVoice(ctx,tailG,now+local*spb,dur*spb,n.midi,n.velocity,t);});
  c.notes.filter(n=>n.beat<=previewSec/spb).forEach(n=>scheduleVoice(ctx,headG,now+headAt+n.beat*spb,n.dur*spb,n.midi,n.velocity,t));
  arrangementLoopPreviewTimerV066=setTimeout(()=>stopArrangementLoopPreviewV066(),(previewSec*2-crossSec+.8)*1000);toast(`Pré-écoute fin → début • crossfade ${crossSec.toFixed(1)} s`);
}

// ===== V0.5.5 — stabilisation + UX débutant (conservé en V0.6.6) =====
const EASY_PRESETS = {
  night:{label:'Nuit 00–06',tag:'00-06',bpm:60,scale:'pentaMajor',density:'low',register:'mid',length:'long',direction:'wave',instrument:'🎹 Piano feutré HQ'},
  morning:{label:'Réveil 06–12',tag:'06-12',bpm:74,scale:'major',density:'low',register:'mid',length:'long',direction:'rise',instrument:'🎸 Guitare nylon douce HQ'},
  day:{label:'Balade 12–18',tag:'12-18',bpm:84,scale:'pentaMajor',density:'medium',register:'mid',length:'mixed',direction:'wave',instrument:'🎸 Guitare classique sèche HQ'},
  evening:{label:'Soir 18–00',tag:'18-00',bpm:76,scale:'major',density:'low',register:'mid',length:'mixed',direction:'fall',instrument:'🎹 Rhodes HQ'}
};
let easyPresetKey=null, easyLastCheck=null;
function initV055UX(){
  const open=()=>{document.querySelector('#easyModeModal')?.classList.remove('hidden');updateV055TrackHealth();};
  const close=()=>document.querySelector('#easyModeModal')?.classList.add('hidden');
  document.querySelector('#easyModeBtn')?.addEventListener('click',open);
  document.querySelector('#closeEasyModeBtn')?.addEventListener('click',close);
  document.querySelectorAll('.easy-preset').forEach(b=>b.addEventListener('click',()=>applyEasyPreset(b.dataset.easy)));
  document.querySelectorAll('.easy-instruments button').forEach(b=>b.addEventListener('click',()=>selectEasyInstrument(b.dataset.inst,b)));
  document.querySelector('#easyGenerateBtn')?.addEventListener('click',easyGenerateMotif);
  document.querySelector('#easyCheckBtn')?.addEventListener('click',()=>runEasyTrackCheck(true));
  document.querySelector('#easyFixBtn')?.addEventListener('click',fixOutOfKeyNotes);
  updateV055HistoryUI();updateV055TrackHealth();
}
function applyEasyPreset(key){
  const p=EASY_PRESETS[key];if(!p)return;easyPresetKey=key;
  document.querySelectorAll('.easy-preset').forEach(b=>b.classList.toggle('active',b.dataset.easy===key));
  const t=currentTrack(),addChords=document.querySelector('#easyAddChords')?.checked;
  mutate(()=>{state.bpm=p.bpm;state.projectTag=p.tag;if(t&&PRESETS[p.instrument]){t.instrument=p.instrument;const ip=PRESETS[p.instrument];t.attack=ip.attack;t.release=ip.release;t.filter=ip.filter;}if(addChords){const k=state.key||0;state.chords=[{id:uid(),beat:0,root:k,type:'maj7'},{id:uid(),beat:4,root:(k+9)%12,type:'min7'},{id:uid(),beat:8,root:(k+5)%12,type:'maj7'},{id:uid(),beat:12,root:(k+7)%12,type:'sus2'}];}});
  els.bpm.value=p.bpm;els.projectTag.value=p.tag;
  const set=(id,val)=>{const e=document.querySelector(id);if(e)e.value=val;};
  set('#motifScale',p.scale);set('#motifDensity',p.density);set('#motifRegister',p.register);set('#motifNoteLength',p.length);set('#motifDirection',p.direction);set('#motifBars','4');
  const status=document.querySelector('#easyPresetStatus');if(status)status.textContent=`${p.label} préparé • ${p.bpm} BPM • ${p.instrument.replace(/^\S+\s/,'')}`;
  document.querySelectorAll('.easy-instruments button').forEach(b=>b.classList.toggle('active',b.dataset.inst===p.instrument));
  renderAll();toast(`${p.label} préparé`);
}
function selectEasyInstrument(name,btn){
  const t=currentTrack();if(!t)return toast('Choisis d’abord une piste');if(!PRESETS[name])return;
  mutate(()=>{t.instrument=name;const p=PRESETS[name];t.attack=p.attack;t.release=p.release;t.filter=p.filter;});
  document.querySelectorAll('.easy-instruments button').forEach(b=>b.classList.toggle('active',b===btn));renderAll();toast(name.replace(/^\S+\s/,'')+' sélectionné');
}
function setEasyChordProgression(){
  const k=state.key||0;
  state.chords=[
    {id:uid(),beat:0,root:k,type:'maj7'},
    {id:uid(),beat:4,root:(k+9)%12,type:'min7'},
    {id:uid(),beat:8,root:(k+5)%12,type:'maj7'},
    {id:uid(),beat:12,root:(k+7)%12,type:'sus2'}
  ];
}
function easyGenerateMotif(){
  if(!easyPresetKey)applyEasyPreset('morning');
  document.querySelector('#easyModeModal')?.classList.add('hidden');openMotifGenerator();
  // Re-apply because openMotifGenerator resets only candidate/source, not settings.
  const p=EASY_PRESETS[easyPresetKey||'morning'];
  const set=(id,val)=>{const e=document.querySelector(id);if(e)e.value=val;};
  set('#motifScale',p.scale);set('#motifDensity',p.density);set('#motifRegister',p.register);set('#motifNoteLength',p.length);set('#motifDirection',p.direction);set('#motifBars','4');
  generateMotifCandidate();toast('Proposition générée • écoute-la avant insertion');
}
function majorPitchClasses(){return new Set(SCALE_MAJOR.map(x=>((state.key||0)+x)%12));}
function analyzeEasyTrack(){
  const t=currentTrack();if(!t)return {notes:0,out:0,short:0,overlap:0};
  const pcs=majorPitchClasses(),notes=[...(t.notes||[])].sort((a,b)=>a.beat-b.beat),out=notes.filter(n=>!pcs.has(((n.midi%12)+12)%12)).length,short=notes.filter(n=>n.dur<.25).length;
  let overlap=0;for(let i=1;i<notes.length;i++)if(notes[i].beat<notes[i-1].beat+notes[i-1].dur-.03)overlap++;
  return {notes:notes.length,out,short,overlap};
}
function runEasyTrackCheck(showText=false){
  easyLastCheck=analyzeEasyTrack();const r=easyLastCheck,el=document.querySelector('#easyCheckResult'),fix=document.querySelector('#easyFixBtn');if(fix)fix.disabled=!r.out;
  let txt=r.notes?`${r.notes} notes • ${r.out} hors tonalité • ${r.short} très courtes • ${r.overlap} chevauchements`:'Cette piste ne contient pas encore de notes.';
  if(el)el.innerHTML=r.notes?(r.out?`<b>À vérifier :</b> ${txt}. Les notes hors tonalité ne sont pas forcément mauvaises : corrige-les seulement si elles sonnent faux.`:`<b>Rien d’évidemment faux.</b> ${txt}.`):txt;
  if(showText)toast(r.out?`${r.out} note(s) hors tonalité détectée(s)`:'Piste tonalement cohérente');updateV055TrackHealth();return r;
}
function nearestMajorMidi(midi){
  const pcs=majorPitchClasses();let best=midi,bd=99;for(let d=-6;d<=6;d++){const m=midi+d;if(pcs.has(((m%12)+12)%12)&&Math.abs(d)<bd){best=m;bd=Math.abs(d);}}return best;
}
function fixOutOfKeyNotes(){
  const t=currentTrack();if(!t)return;const r=analyzeEasyTrack();if(!r.out)return toast('Aucune note hors tonalité');
  if(!confirm(`Déplacer ${r.out} note(s) vers la note la plus proche de ${keyNames[state.key||0]} majeur ?`))return;
  mutate(()=>{for(const n of t.notes)if(!majorPitchClasses().has(((n.midi%12)+12)%12))n.midi=nearestMajorMidi(n.midi);});renderAll();runEasyTrackCheck(false);toast('Notes hors tonalité corrigées');
}
function updateV055TrackHealth(){
  const chip=document.querySelector('#trackHealthChip');if(!chip)return;const r=analyzeEasyTrack();chip.classList.remove('warn','bad');
  if(!r.notes){chip.textContent='Piste vide';return;}if(r.out){chip.textContent=`⚠ ${r.out} hors tonalité`;chip.classList.add('bad');}
  else if(r.short>2){chip.textContent=`△ ${r.short} notes courtes`;chip.classList.add('warn');}else chip.textContent='✓ Piste OK';
}
function updateV055HistoryUI(){
  const u=document.querySelector('#undoBtn'),r=document.querySelector('#redoBtn');if(u){u.disabled=!state.history.length;u.classList.toggle('history-empty',!state.history.length);u.title=state.history.length?`Annuler (${state.history.length})`:'Rien à annuler';}if(r){r.disabled=!state.future.length;r.classList.toggle('history-empty',!state.future.length);r.title=state.future.length?`Rétablir (${state.future.length})`:'Rien à rétablir';}
}


// V0.8.0–V0.8.7 — Mode LTC / règles / simulateur / export config
const LTC_LAYERS_V082=['BASE','ETAT','SUPRA','CIVILISATION','GUERRE','COMMERCE','AMBIANCE'];
const LTC_SLOTS_V082=['00-06','06-12','12-18','18-00'];
function normalizeLtcLayerV082(v){v=String(v||'BASE').toUpperCase().replace('É','E');return LTC_LAYERS_V082.includes(v)?v:'BASE';}
function normalizeLtcModeV082(v){const x=(v&&typeof v==='object')?v:{};const sim=/^\d{2}:\d{2}$/.test(x.simTime||'')?x.simTime:'14:00';const curve=['linear','soft','early','late'].includes(x.civilisationCurve)?x.civilisationCurve:'soft';return {enabled:!!x.enabled,simTime:sim,colonies:clamp(Number.isFinite(+x.colonies)?+x.colonies:1,0,999),states:clamp(+x.states||0,0,999),supras:clamp(+x.supras||0,0,999),civilisation:clamp(Number.isFinite(+x.civilisation)?+x.civilisation:100,0,100),civilisationAuto:x.civilisationAuto!==false,civilisationDrums:x.civilisationDrums!==false,civilisationCurve:curve,war:!!x.war,warAuto:!!x.warAuto,commerce:clamp(+x.commerce||0,0,100),commerceAuto:!!x.commerceAuto,ambiance:clamp(Number.isFinite(+x.ambiance)?+x.ambiance:100,0,100),ambianceAuto:!!x.ambianceAuto,ruleEngineEnabled:x.ruleEngineEnabled!==false,stabilitySec:[0,1,2,5,10].includes(+x.stabilitySec)?+x.stabilitySec:2,hysteresisPct:[0,2,5,10].includes(+x.hysteresisPct)?+x.hysteresisPct:5,stateThreshold:clamp(+x.stateThreshold||1,1,999),supraThreshold:clamp(+x.supraThreshold||1,1,999),customRules:normalizeLtcCustomRulesV085(x.customRules),transitionSec:[.5,1,2,4].includes(+x.transitionSec)?+x.transitionSec:2,autoFamily:x.autoFamily!==false,lastSlot:LTC_SLOTS_V082.includes(x.lastSlot)?x.lastSlot:ltcSlotForTimeV082(sim)};}
function ltcSlotForTimeV082(t){const h=clamp(parseInt(String(t||'00:00').split(':')[0],10)||0,0,23);return h<6?'00-06':h<12?'06-12':h<18?'12-18':'18-00';}
function ltcSlotLabelV082(s){return {'00-06':'00–06 Nuit','06-12':'06–12 Réveil','12-18':'12–18 Balade','18-00':'18–00 Soir'}[s]||s;}
function ltcResponseV084(percent,curve='soft'){const x=clamp((+percent||0)/100,0,1);if(curve==='linear')return x;if(curve==='early')return Math.sqrt(x);if(curve==='late')return x*x;return x*x*(3-2*x);}
const LTC_RULE_SOURCES_V085=['states','supras','civilisation','war','commerce','ambiance'];
const LTC_RULE_TARGETS_V085=['ETAT','SUPRA','CIVILISATION','GUERRE','COMMERCE','AMBIANCE','PERCUSSIONS'];
let ltcRuleRuntimeV085={items:new Map(),timers:new Map(),log:[]};
function normalizeLtcCustomRulesV085(arr){return (Array.isArray(arr)?arr:[]).map(r=>({id:String(r?.id||uid()),enabled:r?.enabled!==false,source:LTC_RULE_SOURCES_V085.includes(r?.source)?r.source:'civilisation',op:['>=','<=','on','off'].includes(r?.op)?r.op:'>=',value:clamp(+r?.value||0,0,999),target:LTC_RULE_TARGETS_V085.includes(r?.target)?r.target:'CIVILISATION',mode:r?.mode==='mute'?'mute':'require'})).slice(0,24);}
function ltcRuleSourceValueV085(source,m=state.ltcMode){if(source==='states')return +m.states||0;if(source==='supras')return +m.supras||0;if(source==='civilisation')return +m.civilisation||0;if(source==='war')return !!m.war;if(source==='commerce')return +m.commerce||0;if(source==='ambiance')return +m.ambiance||0;return 0;}
function ltcRawRuleV085(rule,prev=false,m=state.ltcMode){const v=ltcRuleSourceValueV085(rule.source,m);if(rule.op==='on')return !!v;if(rule.op==='off')return !v;const isPct=['civilisation','commerce','ambiance'].includes(rule.source),h=isPct?(+m.hysteresisPct||0):0,th=+rule.value||0;if(rule.op==='>=')return +v >= th+(prev?-h:h);return +v <= th+(prev?h:-h);}
function ltcLogV085(msg){const t=new Date().toLocaleTimeString([], {hour:'2-digit',minute:'2-digit',second:'2-digit'});ltcRuleRuntimeV085.log.unshift(`${t}  ${msg}`);ltcRuleRuntimeV085.log=ltcRuleRuntimeV085.log.slice(0,24);}
function ltcStableRuleV085(key,rule,m=state.ltcMode){const rawNow=ltcRawRuleV085(rule,ltcRuleRuntimeV085.items.get(key)?.value??false,m);if(!m.ruleEngineEnabled||(+m.stabilitySec||0)<=0){const old=ltcRuleRuntimeV085.items.get(key)?.value;ltcRuleRuntimeV085.items.set(key,{value:rawNow,pending:null});if(old!==undefined&&old!==rawNow)ltcLogV085(`${key} → ${rawNow?'ON':'OFF'}`);return rawNow;}let e=ltcRuleRuntimeV085.items.get(key);if(!e){e={value:rawNow,pending:null};ltcRuleRuntimeV085.items.set(key,e);return rawNow;}if(rawNow===e.value){e.pending=null;const tm=ltcRuleRuntimeV085.timers.get(key);if(tm){clearTimeout(tm);ltcRuleRuntimeV085.timers.delete(key);}return e.value;}if(e.pending!==rawNow){e.pending=rawNow;const old=ltcRuleRuntimeV085.timers.get(key);if(old)clearTimeout(old);const tm=setTimeout(()=>{const cur=state.ltcMode||normalizeLtcModeV082(null),entry=ltcRuleRuntimeV085.items.get(key);if(!entry)return;const again=ltcRawRuleV085(rule,entry.value,cur);if(again===entry.pending){entry.value=again;entry.pending=null;ltcLogV085(`${key} stable → ${again?'ON':'OFF'}`);renderLtcModeV082();ltcRestartIfPlayingV084();}ltcRuleRuntimeV085.timers.delete(key);},(+m.stabilitySec||0)*1000);ltcRuleRuntimeV085.timers.set(key,tm);}return e.value;}
function ltcBuiltinConditionV085(name,m=state.ltcMode){if(name==='ETAT')return ltcStableRuleV085('builtin:ETAT',{source:'states',op:'>=',value:m.stateThreshold},m);if(name==='SUPRA')return ltcStableRuleV085('builtin:SUPRA',{source:'supras',op:'>=',value:m.supraThreshold},m);if(name==='GUERRE')return ltcStableRuleV085('builtin:GUERRE',{source:'war',op:'on',value:0},m);return true;}
function ltcCustomRuleAllowsV085(target,m=state.ltcMode){if(!m.ruleEngineEnabled)return true;let allowed=true;for(const r of m.customRules||[]){if(!r.enabled||r.target!==target)continue;const cond=ltcStableRuleV085(`custom:${r.id}`,r,m);if(r.mode==='require'&&!cond)allowed=false;if(r.mode==='mute'&&cond)allowed=false;}return allowed;}
function ltcForceRulesNowV085(){for(const tm of ltcRuleRuntimeV085.timers.values())clearTimeout(tm);ltcRuleRuntimeV085.timers.clear();ltcRuleRuntimeV085.items.clear();const m=state.ltcMode;ltcBuiltinConditionV085('ETAT',m);ltcBuiltinConditionV085('SUPRA',m);ltcBuiltinConditionV085('GUERRE',m);for(const r of m.customRules||[])ltcStableRuleV085(`custom:${r.id}`,r,m);ltcLogV085('Règles appliquées immédiatement');}
function ltcCustomRuleLabelV085(r){const src={states:'États',supras:'Supra',civilisation:'Civilisation',war:'Guerre',commerce:'Commerce',ambiance:'Ambiance'}[r.source]||r.source;const cond=['on','off'].includes(r.op)?r.op.toUpperCase():`${r.op} ${r.value}`;return `${src} ${cond} → ${r.target} ${r.mode==='mute'?'MUET':'AUDIBLE'}`;}
function ltcLayerGainV084(layer){const m=state.ltcMode||normalizeLtcModeV082(null);if(!m.enabled)return 1;layer=normalizeLtcLayerV082(layer);let g=1;if(layer==='ETAT')g=ltcBuiltinConditionV085('ETAT',m)?1:0;else if(layer==='SUPRA')g=ltcBuiltinConditionV085('SUPRA',m)?1:0;else if(layer==='CIVILISATION'&&m.civilisationAuto)g=ltcResponseV084(m.civilisation,m.civilisationCurve);else if(layer==='GUERRE'&&m.warAuto)g=ltcBuiltinConditionV085('GUERRE',m)?1:0;else if(layer==='COMMERCE'&&m.commerceAuto)g=ltcResponseV084(m.commerce,'soft');else if(layer==='AMBIANCE'&&m.ambianceAuto)g=ltcResponseV084(m.ambiance,'soft');if(!ltcCustomRuleAllowsV085(layer,m))g=0;return clamp(g,0,1);}
function ltcLayerIsOnV082(layer){return ltcLayerGainV084(layer)>.001;}
function ltcTrackGainV082(t){return ltcLayerGainV084(t?.ltcLayer);}
function ltcLayerIsControlledV084(layer){const m=state.ltcMode||normalizeLtcModeV082(null);layer=normalizeLtcLayerV082(layer);return layer==='ETAT'||layer==='SUPRA'||(layer==='CIVILISATION'&&m.civilisationAuto)||(layer==='GUERRE'&&m.warAuto)||(layer==='COMMERCE'&&m.commerceAuto)||(layer==='AMBIANCE'&&m.ambianceAuto);}
function scheduleLtcTrackGateV082(param,t,when){const m=state.ltcMode||normalizeLtcModeV082(null),layer=normalizeLtcLayerV082(t?.ltcLayer),target=ltcTrackGainV082(t);try{param.cancelScheduledValues(when);}catch{}if(!m.enabled||!ltcLayerIsControlledV084(layer)){param.setValueAtTime(target,when);return;}const d=clamp(+m.transitionSec||2,.05,8);param.setValueAtTime(target>0?Math.min(.0001,target):0,when);if(target>0)param.linearRampToValueAtTime(target,when+d);}
function ltcCivilisationDrumFactorV084(){const m=state.ltcMode||normalizeLtcModeV082(null);let g=m.enabled&&m.civilisationDrums?ltcResponseV084(m.civilisation,m.civilisationCurve):1;if(m.enabled&&!ltcCustomRuleAllowsV085('PERCUSSIONS',m))g=0;return g;}
function scheduleLtcCivilisationDrumGainV084(param,when){const m=state.ltcMode||normalizeLtcModeV082(null),target=ltcCivilisationDrumFactorV084();try{param.cancelScheduledValues(when);}catch{}if(!m.enabled||!m.civilisationDrums){param.setValueAtTime(1,when);return;}const d=clamp(+m.transitionSec||2,.05,8);param.setValueAtTime(target>0?Math.min(.0001,target):0,when);if(target>0)param.linearRampToValueAtTime(target,when+d);}
function ltcFamilyItemsV082(slot){return library().filter(x=>x.tag===slot);}
function ltcFamilyCountsV082(){return Object.fromEntries(LTC_SLOTS_V082.map(s=>[s,ltcFamilyItemsV082(s).length]));}
function ltcLoadFamilyItemV082(item,preserveSim=true){if(!item)return false;let p;try{p=JSON.parse(item.project||'{}');}catch{return false;}const sim=preserveSim?normalizeLtcModeV082(state.ltcMode):null;restore(p);state.projectId=item.id;state.projectName=item.name||p.projectName||'Sans titre';state.projectTag=item.tag||p.projectTag||'Autre';els.projectName.value=state.projectName;els.projectTag.value=state.projectTag;if(sim)state.ltcMode=sim;localStorage.setItem(AUTO_KEY,snapshot());state.dirty=false;renderAll();return true;}
function ltcLoadRandomFamilyV082(slot,manual=true){slot=slot||ltcSlotForTimeV082(state.ltcMode?.simTime);const items=ltcFamilyItemsV082(slot);if(!items.length){toast(`Aucune composition sauvegardée dans ${ltcSlotLabelV082(slot)}`);return false;}if(state.dirty){toast('Sauvegarde d’abord la composition actuelle avant de changer de boucle');return false;}let choices=items.filter(x=>x.id!==state.projectId);if(!choices.length)choices=items;const item=choices[Math.floor(Math.random()*choices.length)];const ok=ltcLoadFamilyItemV082(item,true);if(ok)toast(`${ltcSlotLabelV082(slot)} • ${item.name}`);return ok;}
function ltcMaybeAutoFamilyV082(oldSlot,newSlot){const m=state.ltcMode;if(!m?.enabled||!m.autoFamily||oldSlot===newSlot)return;if(state.projectTag===newSlot)return;ltcLoadRandomFamilyV082(newSlot,false);}
function ltcLayerRuleTextV082(layer){const m=state.ltcMode||normalizeLtcModeV082(null);layer=normalizeLtcLayerV082(layer);if(layer==='ETAT')return 'ÉTAT : audible si le simulateur contient au moins 1 État.';if(layer==='SUPRA')return 'SUPRA : audible si le simulateur contient au moins 1 Supra.';if(layer==='CIVILISATION')return m.civilisationAuto?`CIVILISATION : niveau piloté par ${Math.round(m.civilisation)} % (${m.civilisationCurve}).`:'CIVILISATION : pilotage auto OFF, couche manuelle.';if(layer==='GUERRE')return m.warAuto?`GUERRE : ${m.war?'active':'inactive'} dans le simulateur.`:'GUERRE : pilotage auto OFF, couche manuelle.';if(layer==='COMMERCE')return m.commerceAuto?`COMMERCE : niveau piloté par ${Math.round(m.commerce)} %.`:'COMMERCE : pilotage auto OFF, couche manuelle.';if(layer==='AMBIANCE')return m.ambianceAuto?`AMBIANCE : niveau piloté par ${Math.round(m.ambiance)} %.`:'AMBIANCE : pilotage auto OFF, couche manuelle.';return 'BASE : musique principale de la composition courante.';}
function ltcScenarioV086(name){const m=state.ltcMode;if(name==='colonies')Object.assign(m,{colonies:8,states:0,supras:0,civilisation:20,war:false,commerce:15,ambiance:85});if(name==='state')Object.assign(m,{colonies:12,states:3,supras:0,civilisation:40,war:false,commerce:35,ambiance:90});if(name==='supra')Object.assign(m,{colonies:18,states:6,supras:1,civilisation:65,war:false,commerce:55,ambiance:90});if(name==='civilisation')Object.assign(m,{colonies:20,states:7,supras:1,civilisation:100,war:false,commerce:70,ambiance:100});if(name==='war')Object.assign(m,{colonies:18,states:5,supras:1,civilisation:72,war:true,commerce:35,ambiance:65});if(name==='full')Object.assign(m,{colonies:24,states:8,supras:2,civilisation:100,war:true,commerce:100,ambiance:100});ltcForceRulesNowV085();markDirty();renderLtcModeV082();ltcRestartIfPlayingV084();}
function ltcConfigObjectV087(){const m=normalizeLtcModeV082(state.ltcMode),counts=ltcFamilyCountsV082();return {schema:'ltc-music-config',version:'0.8.15.8',generatedAt:new Date().toISOString(),project:{name:state.projectName,tag:state.projectTag,bpm:state.bpm,key:state.key,duration:state.duration},simulatorDefaults:{simTime:m.simTime,colonies:m.colonies,states:m.states,supras:m.supras,civilisation:m.civilisation,war:m.war,commerce:m.commerce,ambiance:m.ambiance},engine:{transitionSec:m.transitionSec,autoFamily:m.autoFamily,ruleEngineEnabled:m.ruleEngineEnabled,stabilitySec:m.stabilitySec,hysteresisPct:m.hysteresisPct,stateThreshold:m.stateThreshold,supraThreshold:m.supraThreshold,civilisationAuto:m.civilisationAuto,civilisationDrums:m.civilisationDrums,civilisationCurve:m.civilisationCurve,warAuto:m.warAuto,commerceAuto:m.commerceAuto,ambianceAuto:m.ambianceAuto,customRules:m.customRules},tracks:state.tracks.map((t,i)=>({index:i,id:t.id,name:t.name,instrument:t.instrument,layer:normalizeLtcLayerV082(t.ltcLayer)})),families:Object.fromEntries(LTC_SLOTS_V082.map(s=>[s,ltcFamilyItemsV082(s).map(x=>({id:x.id,name:x.name,tag:x.tag}))])),familyCounts:counts,contract:{inputs:['time','colonies','states','supras','civilisation','war','commerce','ambiance'],outputs:['family','BASE','ETAT','SUPRA','CIVILISATION','GUERRE','COMMERCE','AMBIANCE','PERCUSSIONS']}};}
function exportLtcConfigV087(){const obj=ltcConfigObjectV087();downloadBlob(new Blob([JSON.stringify(obj,null,2)],{type:'application/json'}),safeName(state.projectName)+'.ltcconfig.json');toast('Configuration LTC exportée');}
async function copyLtcConfigV087(){const txt=JSON.stringify(ltcConfigObjectV087(),null,2);try{await navigator.clipboard.writeText(txt);toast('JSON LTC copié');}catch{toast('Copie impossible sur ce navigateur');}}
function importLtcConfigV087(file){if(!file)return;const rd=new FileReader();rd.onload=()=>{try{const o=JSON.parse(rd.result);if(o.schema!=='ltc-music-config')throw new Error('Format LTC inconnu');const e=o.engine||{},d=o.simulatorDefaults||{};state.ltcMode=normalizeLtcModeV082({...state.ltcMode,...d,...e,customRules:e.customRules});if(Array.isArray(o.tracks))for(const x of o.tracks){const t=state.tracks[x.index]||state.tracks.find(t=>t.id===x.id)||state.tracks.find(t=>t.name===x.name);if(t)t.ltcLayer=normalizeLtcLayerV082(x.layer);}ltcForceRulesNowV085();markDirty();renderAll();toast('Configuration LTC importée');}catch(err){alert('Import LTC impossible : '+err.message);}};rd.readAsText(file);}
function renderLtcModeV082(){const root=document.querySelector('#ltcView');if(!root)return;state.ltcMode=normalizeLtcModeV082(state.ltcMode);state.tracks.forEach(t=>t.ltcLayer=normalizeLtcLayerV082(t.ltcLayer));const m=state.ltcMode,slot=ltcSlotForTimeV082(m.simTime),t=currentTrack();
  const q=(sel)=>document.querySelector(sel);if(q('#ltcModeEnabled'))q('#ltcModeEnabled').checked=m.enabled;if(q('#ltcSimTime'))q('#ltcSimTime').value=m.simTime;if(q('#ltcColonies'))q('#ltcColonies').value=m.colonies;if(q('#ltcStates'))q('#ltcStates').value=m.states;if(q('#ltcSupras'))q('#ltcSupras').value=m.supras;if(q('#ltcTransitionSec'))q('#ltcTransitionSec').value=String(m.transitionSec);if(q('#ltcAutoFamily'))q('#ltcAutoFamily').checked=m.autoFamily;
  if(q('#ltcRuleEngineEnabled'))q('#ltcRuleEngineEnabled').checked=m.ruleEngineEnabled;if(q('#ltcStabilitySec'))q('#ltcStabilitySec').value=String(m.stabilitySec);if(q('#ltcHysteresisPct'))q('#ltcHysteresisPct').value=String(m.hysteresisPct);if(q('#ltcStateThreshold'))q('#ltcStateThreshold').value=m.stateThreshold;if(q('#ltcSupraThreshold'))q('#ltcSupraThreshold').value=m.supraThreshold;
  if(q('#ltcCivilisation'))q('#ltcCivilisation').value=m.civilisation;if(q('#ltcCivilisationAuto'))q('#ltcCivilisationAuto').checked=m.civilisationAuto;if(q('#ltcCivilisationDrums'))q('#ltcCivilisationDrums').checked=m.civilisationDrums;if(q('#ltcCivilisationCurve'))q('#ltcCivilisationCurve').value=m.civilisationCurve;if(q('#ltcWarActive'))q('#ltcWarActive').checked=m.war;if(q('#ltcWarAuto'))q('#ltcWarAuto').checked=m.warAuto;if(q('#ltcCommerce'))q('#ltcCommerce').value=m.commerce;if(q('#ltcCommerceAuto'))q('#ltcCommerceAuto').checked=m.commerceAuto;if(q('#ltcAmbiance'))q('#ltcAmbiance').value=m.ambiance;if(q('#ltcAmbianceAuto'))q('#ltcAmbianceAuto').checked=m.ambianceAuto;
  const civGain=ltcResponseV084(m.civilisation,m.civilisationCurve);if(q('#ltcCivilisationValuePill'))q('#ltcCivilisationValuePill').textContent=`${Math.round(m.civilisation)} %`;if(q('#ltcCivilisationMeter'))q('#ltcCivilisationMeter').style.width=`${Math.round(civGain*100)}%`;if(q('#ltcCivilisationSummary'))q('#ltcCivilisationSummary').innerHTML=`Valeur jeu <b>${Math.round(m.civilisation)} %</b> → réponse musicale <b>${Math.round(civGain*100)} %</b>. Couche : <b>${m.civilisationAuto?'AUTO':'MANUELLE'}</b> • cœur/percussions : <b>${m.civilisationDrums?'PILOTÉ':'LIBRE'}</b>.`;
  if(q('#ltcCommerceValue'))q('#ltcCommerceValue').textContent=`${Math.round(m.commerce)} %`;if(q('#ltcAmbianceValue'))q('#ltcAmbianceValue').textContent=`${Math.round(m.ambiance)} %`;if(q('#ltcContextSummary'))q('#ltcContextSummary').innerHTML=`GUERRE <b>${m.warAuto?(m.war?'ON':'OFF'):'MANUELLE'}</b> • COMMERCE <b>${m.commerceAuto?Math.round(ltcResponseV084(m.commerce,'soft')*100)+' %':'MANUEL'}</b> • AMBIANCE <b>${m.ambianceAuto?Math.round(ltcResponseV084(m.ambiance,'soft')*100)+' %':'MANUELLE'}</b>.`;
  const st=q('#ltcModeStatus');if(st){st.className=m.enabled?'ltc-on-pill':'ltc-off-pill';st.textContent=m.enabled?'ON • SIMULATION LTC':'OFF • COMPOSITION NORMALE';}if(q('#ltcCurrentSlot'))q('#ltcCurrentSlot').textContent=ltcSlotLabelV082(slot);if(q('#ltcTrackName'))q('#ltcTrackName').textContent=t?.name||'—';if(q('#ltcTrackLayer')&&t)q('#ltcTrackLayer').value=t.ltcLayer;if(q('#ltcTrackRule'))q('#ltcTrackRule').textContent=ltcLayerRuleTextV082(t?.ltcLayer||'BASE');
  const etat=m.states>=1,supra=m.supras>=1;if(q('#ltcRuleSummary'))q('#ltcRuleSummary').innerHTML=`Tranche <b>${ltcSlotLabelV082(slot)}</b> • ${m.colonies} colonie(s) • ÉTAT <b>${etat?'ON':'OFF'}</b> (${m.states}) • SUPRA <b>${supra?'ON':'OFF'}</b> (${m.supras}) • CIV <b>${Math.round(m.civilisation)} %</b> • transition ${m.transitionSec.toFixed(1).replace('.0','')} s.`;
  const grid=q('#ltcFamilyGrid');if(grid){const counts=ltcFamilyCountsV082();grid.innerHTML=LTC_SLOTS_V082.map(s=>`<div class="ltc-family-card ${s===slot?'active':''}"><strong>${ltcSlotLabelV082(s)}</strong><span><b>${counts[s]}</b> composition${counts[s]===1?'':'s'} sauvegardée${counts[s]===1?'':'s'}</span><span>${state.projectTag===s?'Composition actuelle dans cette famille':' '}</span></div>`).join('');}
  const chips=q('#ltcLayerStatus');if(chips)chips.innerHTML=LTC_LAYERS_V082.map(l=>{const g=ltcLayerGainV084(l),partial=g>.001&&g<.999;return `<span class="ltc-layer-chip ${g<=.001?'off':partial?'partial':'on'}">${l} ${g<=.001?'OFF':partial?Math.round(g*100)+'%':'ON'}</span>`}).join('');
  const list=q('#ltcTrackLayerList');if(list)list.innerHTML=state.tracks.map(x=>`<div class="ltc-track-layer-row ${x.id===state.selectedTrackId?'active':''}" data-ltc-track="${x.id}"><span class="dot" style="background:${x.color}"></span><div class="name"><b>${esc(x.name)}</b><small>${esc(x.instrument)}</small></div><span class="layer">${normalizeLtcLayerV082(x.ltcLayer)}</span></div>`).join('');
  root.querySelectorAll('[data-ltc-track]').forEach(el=>el.onclick=()=>{state.selectedTrackId=el.dataset.ltcTrack;state.selectedNoteId=null;renderAll();});
  const eng=q('#ltcRuleEngineStatus');if(eng)eng.textContent=m.ruleEngineEnabled?'ACTIF':'OFF';if(q('#ltcRuleEngineSummary'))q('#ltcRuleEngineSummary').innerHTML=`Seuils : État ≥ <b>${m.stateThreshold}</b>, Supra ≥ <b>${m.supraThreshold}</b> • stabilité <b>${m.stabilitySec}s</b> • hystérésis <b>${m.hysteresisPct}%</b> • ${m.customRules.length} règle(s) perso.`;
  const cr=q('#ltcCustomRulesList');if(cr){cr.innerHTML=m.customRules.length?m.customRules.map(r=>{const e=ltcRuleRuntimeV085.items.get(`custom:${r.id}`),pending=!!e?.pending;return `<div class="ltc-custom-rule ${pending?'pending':''}" data-rule-id="${r.id}"><input data-rule-toggle="${r.id}" type="checkbox" ${r.enabled?'checked':''}><div><b>${esc(ltcCustomRuleLabelV085(r))}</b><small>${pending?'changement en attente de stabilité':(e?'état stable : '+(e.value?'VRAI':'FAUX'):'non évaluée')}</small></div><span class="rule-state">${e?(e.value?'ON':'OFF'):'—'}</span><button data-rule-del="${r.id}" class="danger-ghost">✕</button></div>`}).join(''):'<div class="ltc-hint">Aucune règle personnalisée. Les règles État/Supra restent actives.</div>';cr.querySelectorAll('[data-rule-toggle]').forEach(el=>el.onchange=()=>{const r=m.customRules.find(x=>x.id===el.dataset.ruleToggle);if(r)r.enabled=el.checked;markDirty();ltcForceRulesNowV085();renderLtcModeV082();});cr.querySelectorAll('[data-rule-del]').forEach(el=>el.onclick=()=>{m.customRules=m.customRules.filter(x=>x.id!==el.dataset.ruleDel);markDirty();ltcForceRulesNowV085();renderLtcModeV082();});}
  const sim=q('#ltcSimulatorSnapshot');if(sim)sim.innerHTML=`${m.simTime} • Colonies <b>${m.colonies}</b> • États <b>${m.states}</b> • Supra <b>${m.supras}</b> • Civ <b>${Math.round(m.civilisation)}%</b> • Guerre <b>${m.war?'ON':'OFF'}</b> • Commerce <b>${Math.round(m.commerce)}%</b> • Ambiance <b>${Math.round(m.ambiance)}%</b>`;
  const sl=q('#ltcSimulatorLayers');if(sl){const layers=[...LTC_LAYERS_V082,'PERCUSSIONS'];sl.innerHTML=layers.map(l=>{const g=l==='PERCUSSIONS'?ltcCivilisationDrumFactorV084():ltcLayerGainV084(l);return `<div class="ltc-sim-layer"><b>${l}</b><span>${Math.round(g*100)}%</span></div>`}).join('');}
  const log=q('#ltcEventLog');if(log)log.innerHTML=ltcRuleRuntimeV085.log.length?ltcRuleRuntimeV085.log.map(x=>`<div>${esc(x)}</div>`).join(''):'<div>Aucun changement de règle enregistré.</div>';if(q('#ltcSimulatorPill'))q('#ltcSimulatorPill').textContent=m.ruleEngineEnabled?'RÈGLES ON':'RÈGLES OFF';
  if(q('#ltcConfigSummary')){const c=ltcConfigObjectV087();q('#ltcConfigSummary').textContent=`${c.tracks.length} piste(s) • ${m.customRules.length} règle(s) perso • familles : ${LTC_SLOTS_V082.map(s=>c.familyCounts[s]).join(' / ')}`;}
  root.querySelectorAll('[data-ltc-scenario]').forEach(el=>el.onclick=()=>ltcScenarioV086(el.dataset.ltcScenario));
  m.lastSlot=slot;
}
let ltcRestartTimerV084=null;
function ltcRestartIfPlayingV084(){if(!state.playing||!state.ltcMode?.enabled)return;clearTimeout(ltcRestartTimerV084);ltcRestartTimerV084=setTimeout(()=>{stop(false);play();},90);}
function bindLtcModeV082(){const q=s=>document.querySelector(s);if(!q('#ltcModeEnabled'))return;q('#ltcModeEnabled').onchange=e=>{mutate(()=>state.ltcMode.enabled=e.target.checked);renderAll();toast(e.target.checked?'Mode LTC activé':'Mode LTC désactivé • son statique normal');};q('#ltcSimTime').onchange=e=>{const wasDirty=state.dirty,old=ltcSlotForTimeV082(state.ltcMode.simTime);state.ltcMode.simTime=e.target.value||'14:00';const now=ltcSlotForTimeV082(state.ltcMode.simTime);renderLtcModeV082();if(!wasDirty)ltcMaybeAutoFamilyV082(old,now);markDirty();};for(const [id,key] of [['#ltcColonies','colonies'],['#ltcStates','states'],['#ltcSupras','supras']])q(id).onchange=e=>{state.ltcMode[key]=clamp(+e.target.value||0,0,999);markDirty();renderLtcModeV082();ltcRestartIfPlayingV084();};q('#ltcTransitionSec').onchange=e=>{state.ltcMode.transitionSec=+e.target.value||2;markDirty();renderLtcModeV082();};q('#ltcAutoFamily').onchange=e=>{state.ltcMode.autoFamily=e.target.checked;markDirty();renderLtcModeV082();};q('#ltcLoadFamilyBtn').onclick=()=>ltcLoadRandomFamilyV082(ltcSlotForTimeV082(state.ltcMode.simTime),true);q('#ltcTestBtn').onclick=()=>{if(!state.ltcMode.enabled){mutate(()=>state.ltcMode.enabled=true);renderAll();}stop(false);setTimeout(()=>play(),30);toast('Lecture avec règles LTC');};q('#ltcTrackLayer').onchange=e=>{const t=currentTrack();if(!t)return;mutate(()=>t.ltcLayer=normalizeLtcLayerV082(e.target.value));renderAll();};
  const rangeBind=(id,key)=>{const el=q(id);if(!el)return;el.oninput=e=>{state.ltcMode[key]=clamp(+e.target.value||0,0,100);markDirty();renderLtcModeV082();ltcRestartIfPlayingV084();};};rangeBind('#ltcCivilisation','civilisation');rangeBind('#ltcCommerce','commerce');rangeBind('#ltcAmbiance','ambiance');
  const checkBind=(id,key)=>{const el=q(id);if(!el)return;el.onchange=e=>{state.ltcMode[key]=!!e.target.checked;markDirty();renderLtcModeV082();ltcRestartIfPlayingV084();};};checkBind('#ltcCivilisationAuto','civilisationAuto');checkBind('#ltcCivilisationDrums','civilisationDrums');checkBind('#ltcWarAuto','warAuto');checkBind('#ltcWarActive','war');checkBind('#ltcCommerceAuto','commerceAuto');checkBind('#ltcAmbianceAuto','ambianceAuto');
  q('#ltcCivilisationCurve').onchange=e=>{state.ltcMode.civilisationCurve=['linear','soft','early','late'].includes(e.target.value)?e.target.value:'soft';markDirty();renderLtcModeV082();ltcRestartIfPlayingV084();};
  const ruleCheck=q('#ltcRuleEngineEnabled');if(ruleCheck)ruleCheck.onchange=e=>{state.ltcMode.ruleEngineEnabled=e.target.checked;ltcForceRulesNowV085();markDirty();renderLtcModeV082();ltcRestartIfPlayingV084();};for(const [id,key,vals] of [['#ltcStabilitySec','stabilitySec',[0,1,2,5,10]],['#ltcHysteresisPct','hysteresisPct',[0,2,5,10]]]){const el=q(id);if(el)el.onchange=e=>{const v=+e.target.value;state.ltcMode[key]=vals.includes(v)?v:vals[0];markDirty();renderLtcModeV082();};}for(const [id,key] of [['#ltcStateThreshold','stateThreshold'],['#ltcSupraThreshold','supraThreshold']]){const el=q(id);if(el)el.onchange=e=>{state.ltcMode[key]=clamp(+e.target.value||1,1,999);ltcForceRulesNowV085();markDirty();renderLtcModeV082();ltcRestartIfPlayingV084();};}
  if(q('#ltcApplyRulesNowBtn'))q('#ltcApplyRulesNowBtn').onclick=()=>{ltcForceRulesNowV085();renderLtcModeV082();ltcRestartIfPlayingV084();toast('Règles LTC appliquées');};if(q('#ltcAddRuleBtn'))q('#ltcAddRuleBtn').onclick=()=>{const source=q('#ltcRuleSource').value,op=q('#ltcRuleOp').value,target=q('#ltcRuleTarget').value,mode=q('#ltcRuleMode').value,value=clamp(+q('#ltcRuleValue').value||0,0,999);state.ltcMode.customRules.push({id:uid(),enabled:true,source,op,value,target,mode});state.ltcMode.customRules=normalizeLtcCustomRulesV085(state.ltcMode.customRules);markDirty();ltcForceRulesNowV085();renderLtcModeV082();};
  if(q('#ltcSimulatorPlayBtn'))q('#ltcSimulatorPlayBtn').onclick=()=>{if(!state.ltcMode.enabled)state.ltcMode.enabled=true;ltcForceRulesNowV085();renderAll();stop(false);setTimeout(()=>play(),30);};if(q('#ltcClearEventLogBtn'))q('#ltcClearEventLogBtn').onclick=()=>{ltcRuleRuntimeV085.log=[];renderLtcModeV082();};
  if(q('#ltcExportConfigBtn'))q('#ltcExportConfigBtn').onclick=exportLtcConfigV087;if(q('#ltcCopyConfigBtn'))q('#ltcCopyConfigBtn').onclick=copyLtcConfigV087;if(q('#ltcImportConfigBtn'))q('#ltcImportConfigBtn').onclick=()=>q('#ltcConfigFile').click();if(q('#ltcConfigFile'))q('#ltcConfigFile').onchange=e=>{importLtcConfigV087(e.target.files?.[0]);e.target.value='';};
}
function initLtcModeV082(){state.ltcMode=normalizeLtcModeV082(state.ltcMode);state.tracks.forEach(t=>t.ltcLayer=normalizeLtcLayerV082(t.ltcLayer));ltcForceRulesNowV085();bindLtcModeV082();renderLtcModeV082();}


// V0.8.8 — navigation mobile/Fold, panneaux escamotables, zoom/pan tactile
const UX_PREFS_KEY_V088='ltc_ux_v088';
let uxPrefsV088={leftVisible:true,rightVisible:true,followPlayhead:false,zooms:{drums:1,mix:1,arrange:1,automation:1,ltc:1}};
function loadUxPrefsV088(){try{const x=JSON.parse(localStorage.getItem(UX_PREFS_KEY_V088)||'{}');if(x&&typeof x==='object')uxPrefsV088={...uxPrefsV088,...x,zooms:{...uxPrefsV088.zooms,...(x.zooms||{})}};}catch{}}
function saveUxPrefsV088(){try{localStorage.setItem(UX_PREFS_KEY_V088,JSON.stringify(uxPrefsV088));}catch{}}
function uxCompactV088(){return window.innerWidth<=1050;}
function uxModeV088(){return document.querySelector('.mode.active')?.dataset.mode||'notes';}
function uxScrollerV088(mode=uxModeV088()){if(mode==='notes')return els.rollScroller;if(mode==='drums')return els.drums;if(mode==='mix')return els.mixer;if(mode==='arrange')return $('#arrangeView');if(mode==='automation')return $('#automationView');if(mode==='ltc')return $('#ltcView');return $('.editor');}
function uxContentV088(mode=uxModeV088()){if(mode==='drums')return els.drums;if(mode==='mix')return els.mixer;if(mode==='arrange')return $('#arrangeView .arrange-shell');if(mode==='automation')return $('#automationView .automation-shell');if(mode==='ltc')return $('#ltcView .ltc-shell');return null;}
function applyUxPanelsV088(){const w=els.workspace;if(!w)return;if(uxCompactV088()){w.classList.remove('ux-left-hidden','ux-right-hidden');}else{w.classList.toggle('ux-left-hidden',!uxPrefsV088.leftVisible);w.classList.toggle('ux-right-hidden',!uxPrefsV088.rightVisible);w.classList.remove('show-tracks','show-inspector');}const l=$('#uxToggleLeftBtn'),r=$('#uxToggleRightBtn');if(l)l.classList.toggle('active',uxCompactV088()?w.classList.contains('show-tracks'):uxPrefsV088.leftVisible);if(r)r.classList.toggle('active',uxCompactV088()?w.classList.contains('show-inspector'):uxPrefsV088.rightVisible);requestAnimationFrame(()=>{renderRoll();});}
function closeUxDrawerV088(side){if(side==='left')els.workspace.classList.remove('show-tracks');else els.workspace.classList.remove('show-inspector');$$('.mobile-tabs button').forEach(x=>x.classList.toggle('active',x.dataset.mobile==='editor'));applyUxPanelsV088();}
function toggleUxSideV088(side){if(uxCompactV088()){const cls=side==='left'?'show-tracks':'show-inspector',other=side==='left'?'show-inspector':'show-tracks',on=!els.workspace.classList.contains(cls);els.workspace.classList.remove(other);els.workspace.classList.toggle(cls,on);}else{if(side==='left')uxPrefsV088.leftVisible=!uxPrefsV088.leftVisible;else uxPrefsV088.rightVisible=!uxPrefsV088.rightVisible;saveUxPrefsV088();}applyUxPanelsV088();}
function applyUxZoomV088(mode=uxModeV088()){if(mode==='drums'){els.drums?.style.setProperty('--ux-drum-zoom',String(uxPrefsV088.zooms.drums||1));return;}const el=uxContentV088(mode);if(el&&mode!=='notes'){const z=Number(uxPrefsV088.zooms[mode]||1);el.style.zoom=String(z);}if(mode==='mix'&&els.mixer)els.mixer.style.setProperty('--ux-mixer-count',String(Math.max(1,state.tracks.length)));}
function uxZoomValueV088(mode=uxModeV088()){return mode==='notes'?state.zoom:Number(uxPrefsV088.zooms[mode]||1);}
function setUxZoomV088(mode,value,persist=true){if(mode==='notes'){state.zoom=clamp(Number(value)||58,8,180);if(els.zoom)els.zoom.value=String(state.zoom);renderRoll();}else{const min=mode==='drums'?.55:.7,max=mode==='drums'?2.6:1.8;uxPrefsV088.zooms[mode]=clamp(Number(value)||1,min,max);applyUxZoomV088(mode);if(persist)saveUxPrefsV088();}}
function zoomUxActiveV088(factor){const m=uxModeV088();if(m==='notes')setUxZoomV088(m,state.zoom*factor);else setUxZoomV088(m,uxZoomValueV088(m)*factor);}
function uxZoom100V088(){const m=uxModeV088();setUxZoomV088(m,m==='notes'?58:1);}
function uxFitV088(){const m=uxModeV088(),sc=uxScrollerV088(m);if(!sc)return;if(m==='notes'){const bw=clamp((Math.max(160,sc.clientWidth)-12)/Math.max(1,totalBeats()),8,180);setUxZoomV088(m,bw);sc.scrollLeft=0;return;}if(m==='drums'){const natural=110+16*34+15*4+20;setUxZoomV088(m,clamp((sc.clientWidth-12)/natural,.55,1.4));sc.scrollLeft=0;return;}setUxZoomV088(m,1);sc.scrollLeft=0;}
function uxCenterV088(){const m=uxModeV088(),sc=uxScrollerV088(m);if(!sc)return;if(m==='notes'){const n=currentNote();const x=n?(n.beat+n.dur/2)*beatWidth():state.playing?currentPlayBeat()*beatWidth():sc.scrollWidth/2;const y=n?(83-n.midi)*28+14:sc.scrollHeight/2;sc.scrollTo({left:Math.max(0,x-sc.clientWidth/2),top:Math.max(0,y-sc.clientHeight/2),behavior:'smooth'});return;}sc.scrollTo({left:Math.max(0,(sc.scrollWidth-sc.clientWidth)/2),top:Math.max(0,(sc.scrollHeight-sc.clientHeight)/2),behavior:'smooth'});}
function uxResetV088(){const m=uxModeV088(),sc=uxScrollerV088(m);uxZoom100V088();if(sc)sc.scrollTo({left:0,top:0,behavior:'smooth'});}
function updateUxViewHintV088(){const h=$('#uxViewHint');if(!h)return;const m=uxModeV088();h.textContent=m==='notes'?'Tap = note • 2 doigts = navigation sûre':m==='drums'?'1 doigt = rythme • 2 doigts = déplacer / pincer':'Glisser = naviguer • pincer = zoomer';applyUxZoomV088(m);}
function touchPairV088(touches){if(!touches||touches.length<2)return null;const a=touches[0],b=touches[1],cx=(a.clientX+b.clientX)/2,cy=(a.clientY+b.clientY)/2,dist=Math.hypot(a.clientX-b.clientX,a.clientY-b.clientY);return {cx,cy,dist};}
function uxRenderFollowV089(){const b=$('#uxFollowPlayheadBtn');if(!b)return;const on=uxPrefsV088.followPlayhead===true;b.textContent=on?'SUIVI ON':'SUIVI OFF';b.classList.toggle('active',on);b.title=on?'Le playhead peut déplacer la vue':'La lecture ne déplacera jamais ta vue';}
function uxSetFollowV089(on){uxPrefsV088.followPlayhead=!!on;saveUxPrefsV088();uxRenderFollowV089();}
function bindGlobalTouchGuardV089(){
  if(document.documentElement.dataset.uxTouchGuardV089)return;document.documentElement.dataset.uxTouchGuardV089='1';
  const editorSurface=el=>el?.closest?.('#rollScroller,#drumsView,#mixView,#arrangeView,#automationView,#ltcView');
  document.addEventListener('pointerdown',e=>{if(e.pointerType!=='touch')return;uxNavGestureV089.pointers.add(e.pointerId);if(uxNavGestureV089.pointers.size>=2){uxNavGestureV089.active=true;uxNavGestureV089.suppressUntil=performance.now()+500;cancelRollTouchEditV089(true);measureEditV08157.dragging=false;measureEditV08157.pointerId=null;if(gesture){clearTimeout(gesture.longTimer);gesture=null;}uxSetFollowV089(false);}},true);
  const end=e=>{if(e.pointerType!=='touch')return;uxNavGestureV089.pointers.delete(e.pointerId);if(uxNavGestureV089.pointers.size<2&&uxNavGestureV089.active){uxNavGestureV089.active=false;uxNavGestureV089.suppressUntil=performance.now()+500;cancelRollTouchEditV089(true);}};
  document.addEventListener('pointerup',end,true);document.addEventListener('pointercancel',end,true);
  document.addEventListener('click',e=>{if(performance.now()<uxNavGestureV089.suppressUntil&&editorSurface(e.target)){e.preventDefault();e.stopImmediatePropagation();}},true);
}
function bindTwoFingerSurfaceV088(el,mode){if(!el||el.dataset.uxTouchBound)return;el.dataset.uxTouchBound='1';let g=null;el.addEventListener('touchstart',e=>{if(e.touches.length<2)return;const p=touchPairV088(e.touches);if(!p)return;uxNavGestureV089.active=true;uxNavGestureV089.suppressUntil=performance.now()+500;cancelRollTouchEditV089(true);if(gesture){clearTimeout(gesture.longTimer);gesture=null;}uxSetFollowV089(false);const z=uxZoomValueV088(mode);g={p0:p,z0:z,anchorX:(el.scrollLeft+p.cx)/(mode==='notes'?Math.max(.01,state.zoom):Math.max(.01,z)),anchorY:(el.scrollTop+p.cy)/(mode==='notes'?1:Math.max(.01,z))};e.preventDefault();e.stopPropagation();},{passive:false,capture:true});el.addEventListener('touchmove',e=>{if(!g||e.touches.length<2)return;const p=touchPairV088(e.touches);if(!p)return;uxNavGestureV089.active=true;uxNavGestureV089.suppressUntil=performance.now()+500;const ratio=clamp(p.dist/Math.max(20,g.p0.dist),.45,2.4);setUxZoomV088(mode,g.z0*ratio,false);const z=uxZoomValueV088(mode);requestAnimationFrame(()=>{if(mode==='notes'){el.scrollLeft=Math.max(0,g.anchorX*state.zoom-p.cx);el.scrollTop=Math.max(0,g.anchorY-p.cy);}else{el.scrollLeft=Math.max(0,g.anchorX*z-p.cx);el.scrollTop=Math.max(0,g.anchorY*z-p.cy);}});e.preventDefault();e.stopPropagation();},{passive:false,capture:true});const end=e=>{if(g&&e.touches.length<2){g=null;uxNavGestureV089.active=false;uxNavGestureV089.suppressUntil=performance.now()+500;saveUxPrefsV088();}};el.addEventListener('touchend',end,{passive:true,capture:true});el.addEventListener('touchcancel',()=>{g=null;uxNavGestureV089.active=false;uxNavGestureV089.suppressUntil=performance.now()+500;},{passive:true,capture:true});}
function bindUxTouchSurfacesV088(){bindTwoFingerSurfaceV088(els.rollScroller,'notes');bindTwoFingerSurfaceV088(els.drums,'drums');bindTwoFingerSurfaceV088(els.mixer,'mix');bindTwoFingerSurfaceV088($('#arrangeView'),'arrange');bindTwoFingerSurfaceV088($('#automationView'),'automation');bindTwoFingerSurfaceV088($('#ltcView'),'ltc');}
function bindUxV088(){loadUxPrefsV088();bindGlobalTouchGuardV089();uxRenderFollowV089();$('#uxFollowPlayheadBtn')?.addEventListener('click',()=>uxSetFollowV089(!(uxPrefsV088.followPlayhead===true)));$('#uxUndoQuickBtn')?.addEventListener('click',()=>$('#undoBtn')?.click());$('#uxRedoQuickBtn')?.addEventListener('click',()=>$('#redoBtn')?.click());$('#uxDeleteQuickBtn')?.addEventListener('click',()=>{if(uxModeV088()==='notes')deleteSelectedNote();renderInspector();});$('#uxToggleLeftBtn')?.addEventListener('click',()=>toggleUxSideV088('left'));$('#uxToggleRightBtn')?.addEventListener('click',()=>toggleUxSideV088('right'));$('#uxCloseLeftBtn')?.addEventListener('click',()=>uxCompactV088()?closeUxDrawerV088('left'):(uxPrefsV088.leftVisible=false,saveUxPrefsV088(),applyUxPanelsV088()));$('#uxCloseRightBtn')?.addEventListener('click',()=>uxCompactV088()?closeUxDrawerV088('right'):(uxPrefsV088.rightVisible=false,saveUxPrefsV088(),applyUxPanelsV088()));$('#uxZoomOutBtn')?.addEventListener('click',()=>zoomUxActiveV088(.82));$('#uxZoomInBtn')?.addEventListener('click',()=>zoomUxActiveV088(1.22));$('#uxZoom100Btn')?.addEventListener('click',uxZoom100V088);$('#uxFitBtn')?.addEventListener('click',uxFitV088);$('#uxCenterBtn')?.addEventListener('click',uxCenterV088);$('#uxResetViewBtn')?.addEventListener('click',uxResetV088);$('#uxMoreActionsBtn')?.addEventListener('click',()=>$('.topbar')?.classList.toggle('ux-actions-open'));document.addEventListener('pointerdown',e=>{const tb=$('.topbar');if(tb?.classList.contains('ux-actions-open')&&!e.target.closest('.top-actions')&&!e.target.closest('#uxMoreActionsBtn'))tb.classList.remove('ux-actions-open');});window.addEventListener('resize',()=>{applyUxPanelsV088();updateUxViewHintV088();});window.visualViewport?.addEventListener('resize',()=>applyUxPanelsV088());$$('.mode').forEach(b=>b.addEventListener('click',()=>setTimeout(updateUxViewHintV088,0)));bindUxTouchSurfacesV088();applyUxPanelsV088();updateUxViewHintV088();}

init();
setTimeout(bindUxV088,0);
})();
