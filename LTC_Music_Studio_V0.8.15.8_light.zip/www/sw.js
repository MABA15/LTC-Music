const CACHE = 'ltc-music-studio-v0.8.15.8';
const SHELL = ['./','./index.html','./style.css','./sample-engine.js','./custom-samples.js','./app.js','./manifest.json','./icon-192.png','./icon-512.png','./sample-packs/index.json','./sample-packs/classical-guitar-hq/manifest.json','./sample-packs/nylon-guitar-hq/manifest.json','./sample-packs/dry-piano-hq/manifest.json','./sample-packs/felt-piano-hq/manifest.json','./sample-packs/rhodes-hq/manifest.json','./sample-packs/marimba-hq/manifest.json','./sample-packs/kalimba-hq/manifest.json','./sample-packs/mandolin-hq/manifest.json','./sample-packs/pizzicato-hq/manifest.json','./sample-packs/harp-hq/manifest.json','./sample-packs/hand-drum-hq/manifest.json','./sample-packs/wood-perc-hq/manifest.json','./sample-packs/shaker-hq/manifest.json','./sample-packs/triangle-hq/manifest.json','./sample-packs/round-bass-hq/manifest.json','./sample-packs/diagnostic/manifest.json'];

self.addEventListener('install', e => e.waitUntil(caches.open(CACHE).then(c=>c.addAll(SHELL))).then(()=>self.skipWaiting()));

self.addEventListener('activate', e => e.waitUntil((async()=>{
  // V0.8.7: retain only the most recent previous cache as a sample reservoir.
  // We do NOT duplicate 200+ MB of samples during upgrade.
  const old=(await caches.keys()).filter(k=>k!==CACHE&&k.startsWith('ltc-music-studio-'));
  for(const name of old.slice(0,-1)) await caches.delete(name);
  await self.clients.claim();
})()));

self.addEventListener('fetch', e => {
  const req=e.request;
  if(req.method!=='GET') return;
  e.respondWith((async()=>{
    const current=await caches.open(CACHE);
    const fresh=await current.match(req);
    if(fresh) return fresh;
    const u=new URL(req.url);
    const isAudio=u.pathname.includes('/sample-packs/') && /\.(wav|ogg)$/i.test(u.pathname);
    // Audio may be reused from the immediately previous release cache.
    if(isAudio){const old=await caches.match(req);if(old)return old;}
    const net=await fetch(req);
    if(net.ok && u.origin===location.origin) await current.put(req,net.clone());
    return net;
  })());
});
