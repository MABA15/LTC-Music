(() => {
'use strict';

const DB_NAME='ltc-music-studio-custom-audio-v1';
const DB_VERSION=1;
const STORE='samples';
const cache=new Map();
let dbPromise=null;
let draft=null;
let draftRawBuffer=null;
let previewNodes=[];
let recorder=null, recorderStream=null, recorderChunks=[];
const $=s=>document.querySelector(s);
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const uid=()=> 'cs_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,7);

function openDB(){
  if(dbPromise)return dbPromise;
  dbPromise=new Promise((resolve,reject)=>{
    const r=indexedDB.open(DB_NAME,DB_VERSION);
    r.onupgradeneeded=()=>{const db=r.result;if(!db.objectStoreNames.contains(STORE))db.createObjectStore(STORE,{keyPath:'id'});};
    r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);
  });
  return dbPromise;
}
async function tx(mode,fn){const db=await openDB();return new Promise((resolve,reject)=>{const t=db.transaction(STORE,mode),s=t.objectStore(STORE);let result;try{result=fn(s);}catch(e){reject(e);return;}t.oncomplete=()=>resolve(result);t.onerror=()=>reject(t.error);t.onabort=()=>reject(t.error);});}
async function list(){const db=await openDB();return new Promise((resolve,reject)=>{const r=db.transaction(STORE,'readonly').objectStore(STORE).getAll();r.onsuccess=()=>resolve((r.result||[]).sort((a,b)=>(b.updatedAt||0)-(a.updatedAt||0)));r.onerror=()=>reject(r.error);});}
async function get(id){const db=await openDB();return new Promise((resolve,reject)=>{const r=db.transaction(STORE,'readonly').objectStore(STORE).get(id);r.onsuccess=()=>resolve(r.result||null);r.onerror=()=>reject(r.error);});}
async function put(rec){rec.updatedAt=Date.now();if(!rec.createdAt)rec.createdAt=rec.updatedAt;await tx('readwrite',s=>s.put(rec));cache.delete(rec.id);emitChanged();return rec;}
async function remove(id){await tx('readwrite',s=>s.delete(id));cache.delete(id);emitChanged();}
function emitChanged(){window.dispatchEvent(new CustomEvent('ltc-custom-samples-changed'));renderLibrary().catch(()=>{});}

async function decodeBlob(ctx,blob){const ab=await blob.arrayBuffer();return ctx.decodeAudioData(ab.slice(0));}
function makeBuffer(ctx,channels,length,sampleRate){return ctx.createBuffer(channels,length,sampleRate);}
function processRawBuffer(ctx,raw,rec){
  const start=clamp(+rec.trimStart||0,0,raw.duration);
  const end=clamp(Number.isFinite(+rec.trimEnd)?+rec.trimEnd:raw.duration,start+.005,raw.duration);
  const a=Math.floor(start*raw.sampleRate),b=Math.max(a+1,Math.floor(end*raw.sampleRate)),len=b-a;
  const out=makeBuffer(ctx,Math.min(2,raw.numberOfChannels),len,raw.sampleRate);
  let peak=0;
  for(let c=0;c<out.numberOfChannels;c++){
    const src=raw.getChannelData(Math.min(c,raw.numberOfChannels-1)),dst=out.getChannelData(c);
    if(rec.reverse){for(let i=0;i<len;i++){const v=src[b-1-i]||0;dst[i]=v;peak=Math.max(peak,Math.abs(v));}}
    else{for(let i=0;i<len;i++){const v=src[a+i]||0;dst[i]=v;peak=Math.max(peak,Math.abs(v));}}
  }
  return {buffer:out,peak,duration:out.duration};
}
async function ensureProcessed(id,ctx){
  const rec=await get(id);if(!rec)throw new Error('Son personnel introuvable');
  const key=rec.updatedAt+'|'+(ctx.sampleRate||0);const old=cache.get(id);if(old?.key===key)return {...old,rec};
  const raw=await decodeBlob(ctx,rec.blob),proc=processRawBuffer(ctx,raw,rec);const item={key,raw,buffer:proc.buffer,peak:proc.peak,duration:proc.duration};cache.set(id,item);return {...item,rec};
}
async function preload(ids,ctx){for(const id of [...new Set(ids.filter(Boolean))])await ensureProcessed(id,ctx);}
function customIdFromInstrument(v){return String(v||'').startsWith('custom:')?String(v).slice(7):null;}
function dbGain(db){return Math.pow(10,(+db||0)/20);}
function schedule(id,ctx,dest,start,dur,vel,track,nodes=[]){
  const c=cache.get(id);if(!c)return false;
  get(id).then(()=>{}).catch(()=>{}); // keep DB alive on some mobile browsers
  const rec=c.recCache||null;
  // rec metadata is copied into cache on preloadCustomMetadata; fallback to current meta map.
  const meta=metadataCache.get(id);if(!meta)return false;
  const src=ctx.createBufferSource();src.buffer=c.buffer;src.playbackRate.setValueAtTime(clamp(+meta.speed||1,.25,2),start);src.loop=!!meta.loop;if(src.loop){src.loopStart=0;src.loopEnd=c.buffer.duration;}
  const filter=ctx.createBiquadFilter();filter.type='lowpass';filter.frequency.setValueAtTime(Math.min(+meta.lowpass||20000,+track?.filter||20000),start);filter.Q.value=.3;
  const g=ctx.createGain();let gain=dbGain(meta.gainDb)*(meta.normalize&&c.peak>1e-6?Math.min(8,.92/c.peak):1)*clamp(vel||.72,.02,1);
  const speed=clamp(+meta.speed||1,.25,2),natural=c.buffer.duration/speed;const playDur=meta.loop?Math.max(.03,dur):Math.min(Math.max(.03,dur),natural);
  const fi=Math.min(+meta.fadeIn||0,playDur*.45),fo=Math.min(+meta.fadeOut||0,playDur*.45);
  g.gain.setValueAtTime(fi?0:gain,start);if(fi)g.gain.linearRampToValueAtTime(gain,start+fi);if(fo){g.gain.setValueAtTime(gain,start+Math.max(fi,playDur-fo));g.gain.linearRampToValueAtTime(0,start+playDur);}else g.gain.setValueAtTime(gain,start+playDur);
  src.connect(filter);filter.connect(g);g.connect(dest);src.start(start);try{src.stop(start+playDur+.03);}catch{}
  nodes.push(src);return true;
}
const metadataCache=new Map();
async function refreshMetadata(){const rows=await list();metadataCache.clear();rows.forEach(r=>metadataCache.set(r.id,r));return rows;}
async function preloadUsed(ids,ctx){await refreshMetadata();await preload(ids,ctx);}
function metadata(id){return metadataCache.get(id)||null;}

function defaultRecord(blob,name,type,duration){return {id:uid(),name:(name||'Son personnel').replace(/\.[^.]+$/,''),type:type||blob.type||'audio/*',blob,duration,trimStart:0,trimEnd:duration,gainDb:0,normalize:false,fadeIn:.05,fadeOut:.10,reverse:false,lowpass:18000,speed:1,loop:false,createdAt:Date.now(),updatedAt:Date.now()};}
async function loadBlobAsDraft(blob,name,type){
  const ctx=getPreviewContext();await ctx.resume();const raw=await decodeBlob(ctx,blob);draft=defaultRecord(blob,name,type,raw.duration);draftRawBuffer=raw;syncEditorFromDraft();drawWaveform();openEditorTab();
}
async function editRecord(id){const rec=await get(id);if(!rec)return;const ctx=getPreviewContext();await ctx.resume();draft={...rec};draftRawBuffer=await decodeBlob(ctx,rec.blob);syncEditorFromDraft();drawWaveform();openEditorTab();}
function getPreviewContext(){if(!getPreviewContext.ctx)getPreviewContext.ctx=new (window.AudioContext||window.webkitAudioContext)();return getPreviewContext.ctx;}
function stopPreview(){previewNodes.forEach(n=>{try{n.stop?.()}catch{}});previewNodes=[];}
async function previewDraft(){if(!draft||!draftRawBuffer)return;stopPreview();pullDraftFromEditor();const ctx=getPreviewContext();await ctx.resume();const proc=processRawBuffer(ctx,draftRawBuffer,draft);const src=ctx.createBufferSource();src.buffer=proc.buffer;src.playbackRate.value=clamp(+draft.speed||1,.25,2);src.loop=!!draft.loop;const f=ctx.createBiquadFilter();f.type='lowpass';f.frequency.value=+draft.lowpass||18000;const g=ctx.createGain();let gain=dbGain(draft.gainDb)*(draft.normalize&&proc.peak>1e-6?Math.min(8,.92/proc.peak):1);const playDur=draft.loop?Math.min(20,Math.max(3,proc.duration/(+draft.speed||1)*2)):proc.duration/(+draft.speed||1);const fi=Math.min(+draft.fadeIn||0,playDur*.45),fo=Math.min(+draft.fadeOut||0,playDur*.45);g.gain.setValueAtTime(fi?0:gain,ctx.currentTime);if(fi)g.gain.linearRampToValueAtTime(gain,ctx.currentTime+fi);if(fo){g.gain.setValueAtTime(gain,ctx.currentTime+Math.max(fi,playDur-fo));g.gain.linearRampToValueAtTime(0,ctx.currentTime+playDur);}src.connect(f);f.connect(g);g.connect(ctx.destination);src.start();src.stop(ctx.currentTime+playDur+.03);previewNodes=[src];}

function syncEditorFromDraft(){if(!draft)return;$('#customSampleName').value=draft.name;$('#customStart').max=draft.duration;$('#customEnd').max=draft.duration;$('#customStart').value=draft.trimStart;$('#customEnd').value=draft.trimEnd;$('#customGain').value=draft.gainDb;$('#customLowpass').value=draft.lowpass;$('#customSpeed').value=draft.speed;$('#customFadeIn').value=draft.fadeIn;$('#customFadeOut').value=draft.fadeOut;$('#customNormalize').checked=!!draft.normalize;$('#customReverse').checked=!!draft.reverse;$('#customLoop').checked=!!draft.loop;updateEditorLabels();}
function pullDraftFromEditor(){if(!draft)return;draft.name=$('#customSampleName').value.trim()||'Son personnel';draft.trimStart=Math.min(+$ ('#customStart').value,+$('#customEnd').value-.005);draft.trimEnd=Math.max(+$('#customEnd').value,draft.trimStart+.005);draft.gainDb=+$('#customGain').value;draft.lowpass=+$('#customLowpass').value;draft.speed=+$('#customSpeed').value;draft.fadeIn=+$('#customFadeIn').value;draft.fadeOut=+$('#customFadeOut').value;draft.normalize=$('#customNormalize').checked;draft.reverse=$('#customReverse').checked;draft.loop=$('#customLoop').checked;}
function updateEditorLabels(){if(!draft)return;const s=+$('#customStart').value,e=+$('#customEnd').value;$('#customSelectionLabel').textContent=`${s.toFixed(2)} s → ${e.toFixed(2)} s • ${(e-s).toFixed(2)} s`;$('#customGainLabel').textContent=(+$('#customGain').value).toFixed(1)+' dB';$('#customFilterLabel').textContent=Math.round(+$('#customLowpass').value)+' Hz';$('#customSpeedLabel').textContent=(+$('#customSpeed').value).toFixed(2)+'×';$('#customFadeLabel').textContent=`${(+$('#customFadeIn').value).toFixed(2)} / ${(+$('#customFadeOut').value).toFixed(2)} s`;drawWaveform();}
function drawWaveform(){const c=$('#customWaveform');if(!c||!draftRawBuffer)return;const r=c.getBoundingClientRect(),w=Math.max(300,Math.floor(r.width||700)),h=180,dpr=devicePixelRatio||1;c.width=w*dpr;c.height=h*dpr;const x=c.getContext('2d');x.scale(dpr,dpr);x.fillStyle='#0e1217';x.fillRect(0,0,w,h);const data=draftRawBuffer.getChannelData(0),step=Math.max(1,Math.floor(data.length/w));x.strokeStyle='#75c996';x.lineWidth=1;x.beginPath();for(let px=0;px<w;px++){let mn=1,mx=-1;const a=px*step,b=Math.min(data.length,a+step);for(let i=a;i<b;i++){const v=data[i];if(v<mn)mn=v;if(v>mx)mx=v;}const y1=(1-mx)*h*.5,y2=(1-mn)*h*.5;x.moveTo(px,y1);x.lineTo(px,y2);}x.stroke();const s=+$('#customStart').value/draft.duration*w,e=+$('#customEnd').value/draft.duration*w;x.fillStyle='#0009';x.fillRect(0,0,s,h);x.fillRect(e,0,w-e,h);x.strokeStyle='#7ee787';x.lineWidth=2;x.strokeRect(s+.5,.5,Math.max(1,e-s-1),h-1);}
function waveformPointer(ev){if(!draft)return;const c=$('#customWaveform'),r=c.getBoundingClientRect(),t=clamp((ev.clientX-r.left)/r.width,0,1)*draft.duration;if(ev.shiftKey||ev.altKey)$('#customEnd').value=Math.max(t,+$('#customStart').value+.005);else{const ds=Math.abs(t-+$('#customStart').value),de=Math.abs(t-+$('#customEnd').value);if(ds<=de)$('#customStart').value=Math.min(t,+$('#customEnd').value-.005);else $('#customEnd').value=Math.max(t,+$('#customStart').value+.005);}updateEditorLabels();}

async function saveDraft(asNew=true){if(!draft)return;pullDraftFromEditor();const rec={...draft};if(asNew||!rec.id)rec.id=uid();await put(rec);draft={...rec};await refreshMetadata();await renderLibrary();window.dispatchEvent(new CustomEvent('ltc-custom-sample-saved',{detail:{sample:stripBlob(rec)}}));toastLocal(asNew?'Segment enregistré':'Son mis à jour');}
function stripBlob(r){const {blob,...m}=r;return m;}
async function addDraftToProject(){if(!draft)return;pullDraftFromEditor();let rec=draft;if(!await get(rec.id)){await put(rec);await refreshMetadata();}window.dispatchEvent(new CustomEvent('ltc-add-custom-sample',{detail:{sample:stripBlob(rec)}}));closeModal();}
async function addRecordToProject(id){const rec=await get(id);if(!rec)return;window.dispatchEvent(new CustomEvent('ltc-add-custom-sample',{detail:{sample:stripBlob(rec)}}));}
async function deleteRecord(id){if(!confirm('Supprimer ce son personnel de la bibliothèque ?'))return;await remove(id);}

async function renderLibrary(){const host=$('#customSampleList');if(!host)return;const rows=await list();metadataCache.clear();rows.forEach(r=>metadataCache.set(r.id,r));if(!rows.length){host.innerHTML='<div class="custom-empty">Aucun son personnel. Importe un fichier audio ou enregistre directement depuis le téléphone.</div>';return;}host.innerHTML='';for(const r of rows){const d=document.createElement('div');d.className='custom-sample-card';const seg=Math.max(.01,(r.trimEnd??r.duration)-(r.trimStart||0));d.innerHTML=`<div><strong>${esc(r.name)}</strong><small>${seg.toFixed(1)} s • ${r.loop?'boucle':'lecture unique'} • ${r.reverse?'inversé • ':''}${(+r.speed||1).toFixed(2)}×</small></div><div class="custom-sample-actions"><button data-a="add">＋ morceau</button><button data-a="edit">Modifier</button><button data-a="del" class="danger-ghost">Supprimer</button></div>`;d.querySelector('[data-a=add]').onclick=()=>addRecordToProject(r.id);d.querySelector('[data-a=edit]').onclick=()=>editRecord(r.id);d.querySelector('[data-a=del]').onclick=()=>deleteRecord(r.id);host.appendChild(d);}}
function esc(s){return String(s||'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));}
function toastLocal(msg){const d=document.createElement('div');d.className='toast';d.textContent=msg;document.body.appendChild(d);setTimeout(()=>d.remove(),1700);}
function openModal(){renderLibrary();$('#customSoundModal').classList.remove('hidden');showTab('library');}
function closeModal(){stopPreview();$('#customSoundModal').classList.add('hidden');}
function showTab(name){document.querySelectorAll('.custom-tab-btn').forEach(b=>b.classList.toggle('active',b.dataset.customTab===name));document.querySelectorAll('.custom-tab').forEach(v=>v.classList.toggle('active',v.id==='customTab_'+name));}
function openEditorTab(){showTab('editor');}

async function startRecording(){if(!navigator.mediaDevices?.getUserMedia||typeof MediaRecorder==='undefined'){alert('Enregistrement direct non disponible dans ce navigateur. Tu peux importer un fichier audio enregistré avec le téléphone.');return;}try{recorderStream=await navigator.mediaDevices.getUserMedia({audio:true});let opts={};for(const mt of ['audio/webm;codecs=opus','audio/webm','audio/mp4']){if(MediaRecorder.isTypeSupported?.(mt)){opts={mimeType:mt};break;}}recorderChunks=[];recorder=new MediaRecorder(recorderStream,opts);recorder.ondataavailable=e=>{if(e.data?.size)recorderChunks.push(e.data);};recorder.onstop=async()=>{const blob=new Blob(recorderChunks,{type:recorder.mimeType||'audio/webm'});recorderStream?.getTracks().forEach(t=>t.stop());recorderStream=null;$('#customRecordBtn').classList.remove('recording');$('#customRecordBtn').textContent='● Enregistrer au micro';await loadBlobAsDraft(blob,'Enregistrement '+new Date().toLocaleTimeString('fr-FR',{hour:'2-digit',minute:'2-digit'}),blob.type);};recorder.start();$('#customRecordBtn').classList.add('recording');$('#customRecordBtn').textContent='■ Arrêter l’enregistrement';}catch(e){alert('Micro : '+e.message);}}
function toggleRecording(){if(recorder?.state==='recording')recorder.stop();else startRecording();}

async function blobToDataURL(blob){return new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=()=>reject(r.error);r.readAsDataURL(blob);});}
function dataURLToBlob(dataURL){const [head,data]=String(dataURL).split(',');const mime=(head.match(/data:([^;]+)/)||[])[1]||'application/octet-stream';const bin=atob(data),u=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)u[i]=bin.charCodeAt(i);return new Blob([u],{type:mime});}
async function exportAssets(ids){const out=[];for(const id of [...new Set(ids)]){const r=await get(id);if(!r)continue;const {blob,...meta}=r;out.push({...meta,dataUrl:await blobToDataURL(blob)});}return out;}
async function importAssets(items=[]){for(const a of items){if(!a?.id||!a.dataUrl)continue;const {dataUrl,...meta}=a;await put({...meta,blob:dataURLToBlob(dataUrl)});}await refreshMetadata();emitChanged();}

async function init(){
  await openDB();await refreshMetadata();
  $('#customSoundBtn')?.addEventListener('click',openModal);$('#customSoundInspectorBtn')?.addEventListener('click',openModal);$('#closeCustomSoundBtn')?.addEventListener('click',closeModal);
  document.querySelectorAll('.custom-tab-btn').forEach(b=>b.onclick=()=>showTab(b.dataset.customTab));
  $('#customAudioFile')?.addEventListener('change',e=>{const f=e.target.files?.[0];if(f)loadBlobAsDraft(f,f.name,f.type);e.target.value='';});
  $('#customImportBtn')?.addEventListener('click',()=>$('#customAudioFile').click());$('#customRecordBtn')?.addEventListener('click',toggleRecording);
  $('#customPreviewBtn')?.addEventListener('click',previewDraft);$('#customStopPreviewBtn')?.addEventListener('click',stopPreview);
  $('#customSaveNewBtn')?.addEventListener('click',()=>saveDraft(true));$('#customReplaceBtn')?.addEventListener('click',()=>saveDraft(false));$('#customAddProjectBtn')?.addEventListener('click',addDraftToProject);
  ['customStart','customEnd','customGain','customLowpass','customSpeed','customFadeIn','customFadeOut'].forEach(id=>$('#'+id)?.addEventListener('input',updateEditorLabels));
  ['customNormalize','customReverse','customLoop','customSampleName'].forEach(id=>$('#'+id)?.addEventListener('change',()=>{pullDraftFromEditor();drawWaveform();}));
  $('#customWaveform')?.addEventListener('pointerdown',waveformPointer);window.addEventListener('resize',()=>{if(!$('#customSoundModal')?.classList.contains('hidden'))drawWaveform();});
  await renderLibrary();emitChanged();
}

window.LTCCustomSamples={init,list,get,put,remove,preloadUsed,schedule,metadata,refreshMetadata,customIdFromInstrument,exportAssets,importAssets,open:openModal,edit:editRecord,renderLibrary};
})();
